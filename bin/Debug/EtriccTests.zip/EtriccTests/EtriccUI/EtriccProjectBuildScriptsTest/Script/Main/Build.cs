using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Egemin.EPIA.ComponentModel;
using Egemin.Etricc.Scripts.Core;

namespace Egemin.Etricc.Scripts.Main
{
    [Entry("Build", "Main")]
    [Include(@"..\Core\Script.cs")]
    public class Build : Script
    {
        public override void Run()
        {
            Project.Builder.BuildAll();
            Project.Router.RouteAll();
            Project.Finisher.FinishAll();
            Project.Validator.ValidateAll();

            Project.Agvs.CalculateSimTrunks();
        }
    } 
}