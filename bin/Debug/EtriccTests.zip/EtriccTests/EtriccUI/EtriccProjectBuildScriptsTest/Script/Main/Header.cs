﻿using Egemin.EPIA.ComponentModel;

namespace Egemin.Etricc.Scripts.Main
{
	[Entry("Header", "Main")]
	[Include(@"..\Core\Script.cs")]
	[Include(@"..\Main\Build.cs")]
	[Include(@"..\Main\Create.cs")]
	[Include(@"..\Main\Full.cs")]
	[Include(@"..\Main\Header.cs")]
	[Include(@"..\Detail\Agvs.cs")]
	[Include(@"..\Detail\AgvTypes.cs")]
	[Include(@"..\Detail\Applications.cs")]
	[Include(@"..\Detail\FieldFunctions.cs")]
	[Include(@"..\Detail\FieldPorts.cs")]
	[Include(@"..\Detail\HostPorts.cs")]
	[Include(@"..\Detail\ImportStatusDefs.cs")]
	[Include(@"..\Detail\Layouts.cs")]
	[Include(@"..\Detail\LoadTypes.cs")]
	[Include(@"..\Detail\LocationTypes.cs")]
	[Include(@"..\Detail\Schedules.cs")]
	[Include(@"..\Detail\Statuses.cs")]
	public class Header { }
}