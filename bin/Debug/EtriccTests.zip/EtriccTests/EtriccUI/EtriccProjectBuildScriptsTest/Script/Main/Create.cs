using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Egemin.EPIA.ComponentModel;
using Egemin.EPIA.WCS.Scheduling;
using Egemin.Etricc.Scripts.Core;
using Egemin.Etricc.Scripts.Detail;

namespace Egemin.Etricc.Scripts.Main
{
    [Entry("Create", "Main")]
    [Include(@"..\Core\Script.cs")]
    public class Create : Script
    {
        public override void Run()
        {
            // create a new project
            Project.Create("Sample", "Sample", "Created at " + DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"));

            // define basic behaviour
            Project.Scheduler.Parameters[Scheduler.DYNAMIC].ValueAsBool = true;

            // run other scripts
            Run<Statuses>();
            Run<Layouts>();
            Run<AgvTypes>();
            Run<LoadTypes>();
            Run<Agvs>();
            //Run<Applications>();
            Run<FieldFunctions>();
        }
    }
}