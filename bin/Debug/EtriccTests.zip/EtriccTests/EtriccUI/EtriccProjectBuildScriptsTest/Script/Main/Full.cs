﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Egemin.EPIA.ComponentModel;
using System.Windows.Forms;
using Egemin.Etricc.Scripts.Core;

namespace Egemin.Etricc.Scripts.Main
{
    [Entry("Full", "Main")]
    [Include(@"..\Core\Script.cs")]
    public class Full : Script
    {
        public override void Run()
        {
            ScriptContext.RootDirectory = @"C:\EtriccTests\EtriccUI\EtriccProjectBuildScriptsTest\";
            ScriptContext.Version = null;

            // run scripts
            Run<Create>();
            Run<Build>();

            // set simulation
            Project.SetSimulation();

            // save normal xml
            Project.SaveXmlWithDefaultName();

            Project = null;
        }
    }
}