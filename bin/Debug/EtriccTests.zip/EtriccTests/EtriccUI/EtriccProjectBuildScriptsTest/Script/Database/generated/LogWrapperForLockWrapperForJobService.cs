public class LogWrapperForLockWrapperForJobService : Egemin.Epia.Foundation.ComponentManagement.WrapperGeneration.LogWrapper<Egemin.Epia.Foundation.ComponentManagement.DynamicWrappers.LockWrapperForJobService>, Egemin.Etricc.Components.Interfaces.IJobService {
    
    public LogWrapperForLockWrapperForJobService(Egemin.Epia.Foundation.ComponentManagement.DynamicWrappers.LockWrapperForJobService wrappee) : 
            base(wrappee) {
    }
    
    System.Collections.Generic.IDictionary<string, System.Collections.Generic.List<string>> Egemin.Etricc.Components.Interfaces.IJobService.GetJobIds() {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IDictionary`2[System.String,System.Collections.Generic" +
                    ".List`1[System.String]] GetJobIds()", base.MakeSecondPartOfLogMessage());
            beforeLogEntry.Log();
        }
        System.Collections.Generic.IDictionary<string, System.Collections.Generic.List<string>> result = ((Egemin.Etricc.Components.Interfaces.IJobService)(this.Wrappee)).GetJobIds();
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IDictionary`2[System.String,System.Collections.Generic" +
                    ".List`1[System.String]] GetJobIds()", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    System.Collections.Generic.IDictionary<string, System.Collections.Generic.List<string>> Egemin.Etricc.Components.Interfaces.IJobService.GetJobIdsForAgvs(System.Collections.Generic.IEnumerable<string> agvIds) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IDictionary`2[System.String,System.Collections.Generic" +
                    ".List`1[System.String]] GetJobIdsForAgvs(System.Collections.Generic.IEnumerable`" +
                    "1[System.String])", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(agvIds));
            beforeLogEntry.Log();
        }
        System.Collections.Generic.IDictionary<string, System.Collections.Generic.List<string>> result = ((Egemin.Etricc.Components.Interfaces.IJobService)(this.Wrappee)).GetJobIdsForAgvs(agvIds);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IDictionary`2[System.String,System.Collections.Generic" +
                    ".List`1[System.String]] GetJobIdsForAgvs(System.Collections.Generic.IEnumerable`" +
                    "1[System.String])", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    System.Collections.Generic.IDictionary<string, System.Collections.Generic.List<Egemin.Etricc.Components.Interfaces.JobInfo>> Egemin.Etricc.Components.Interfaces.IJobService.GetJobInfos() {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IDictionary`2[System.String,System.Collections.Generic" +
                    ".List`1[Egemin.Etricc.Components.Interfaces.JobInfo]] GetJobInfos()", base.MakeSecondPartOfLogMessage());
            beforeLogEntry.Log();
        }
        System.Collections.Generic.IDictionary<string, System.Collections.Generic.List<Egemin.Etricc.Components.Interfaces.JobInfo>> result = ((Egemin.Etricc.Components.Interfaces.IJobService)(this.Wrappee)).GetJobInfos();
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IDictionary`2[System.String,System.Collections.Generic" +
                    ".List`1[Egemin.Etricc.Components.Interfaces.JobInfo]] GetJobInfos()", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    System.Collections.Generic.IDictionary<string, System.Collections.Generic.List<Egemin.Etricc.Components.Interfaces.JobInfo>> Egemin.Etricc.Components.Interfaces.IJobService.GetJobInfosForAgvs(System.Collections.Generic.IEnumerable<string> agvIds) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IDictionary`2[System.String,System.Collections.Generic" +
                    ".List`1[Egemin.Etricc.Components.Interfaces.JobInfo]] GetJobInfosForAgvs(System." +
                    "Collections.Generic.IEnumerable`1[System.String])", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(agvIds));
            beforeLogEntry.Log();
        }
        System.Collections.Generic.IDictionary<string, System.Collections.Generic.List<Egemin.Etricc.Components.Interfaces.JobInfo>> result = ((Egemin.Etricc.Components.Interfaces.IJobService)(this.Wrappee)).GetJobInfosForAgvs(agvIds);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IDictionary`2[System.String,System.Collections.Generic" +
                    ".List`1[Egemin.Etricc.Components.Interfaces.JobInfo]] GetJobInfosForAgvs(System." +
                    "Collections.Generic.IEnumerable`1[System.String])", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.JobInfo> Egemin.Etricc.Components.Interfaces.IJobService.GetDetailedJobInfos(string agvId, System.Collections.Generic.IEnumerable<string> jobIds) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[Egemin.Etricc.Components.Interfaces.JobInfo] G" +
                    "etDetailedJobInfos(System.String, System.Collections.Generic.IEnumerable`1[Syste" +
                    "m.String])", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(agvId), ", ", base.CallToString(jobIds));
            beforeLogEntry.Log();
        }
        System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.JobInfo> result = ((Egemin.Etricc.Components.Interfaces.IJobService)(this.Wrappee)).GetDetailedJobInfos(agvId, jobIds);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[Egemin.Etricc.Components.Interfaces.JobInfo] G" +
                    "etDetailedJobInfos(System.String, System.Collections.Generic.IEnumerable`1[Syste" +
                    "m.String])", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    System.Collections.Generic.IDictionary<string, Egemin.Epia.Foundation.ServiceModel.Polling.ChangeSet<string, Egemin.Etricc.Components.Interfaces.JobInfo>> Egemin.Etricc.Components.Interfaces.IJobService.Poll(System.Collections.Generic.IEnumerable<Egemin.Etricc.Components.Interfaces.VersionedId> versionedAgvIds) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), @"System.Collections.Generic.IDictionary`2[System.String,Egemin.Epia.Foundation.ServiceModel.Polling.ChangeSet`2[System.String,Egemin.Etricc.Components.Interfaces.JobInfo]] Poll(System.Collections.Generic.IEnumerable`1[Egemin.Etricc.Components.Interfaces.VersionedId])", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(versionedAgvIds));
            beforeLogEntry.Log();
        }
        System.Collections.Generic.IDictionary<string, Egemin.Epia.Foundation.ServiceModel.Polling.ChangeSet<string, Egemin.Etricc.Components.Interfaces.JobInfo>> result = ((Egemin.Etricc.Components.Interfaces.IJobService)(this.Wrappee)).Poll(versionedAgvIds);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), @"System.Collections.Generic.IDictionary`2[System.String,Egemin.Epia.Foundation.ServiceModel.Polling.ChangeSet`2[System.String,Egemin.Etricc.Components.Interfaces.JobInfo]] Poll(System.Collections.Generic.IEnumerable`1[Egemin.Etricc.Components.Interfaces.VersionedId])", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    void Egemin.Etricc.Components.Interfaces.IJobService.Abort(string agvId, System.Collections.Generic.IEnumerable<string> jobIds) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Void Abort(System.String, System.Collections.Generic.IEnumerable`1[System.String]" +
                    ")", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(agvId), ", ", base.CallToString(jobIds));
            beforeLogEntry.Log();
        }
        ((Egemin.Etricc.Components.Interfaces.IJobService)(this.Wrappee)).Abort(agvId, jobIds);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Void Abort(System.String, System.Collections.Generic.IEnumerable`1[System.String]" +
                    ")", base.MakeSecondPartOfLogMessage());
            afterLogEntry.Log();
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.IJobService.Cancel(string agvId, System.Collections.Generic.IEnumerable<string> jobIds) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Void Cancel(System.String, System.Collections.Generic.IEnumerable`1[System.String" +
                    "])", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(agvId), ", ", base.CallToString(jobIds));
            beforeLogEntry.Log();
        }
        ((Egemin.Etricc.Components.Interfaces.IJobService)(this.Wrappee)).Cancel(agvId, jobIds);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Void Cancel(System.String, System.Collections.Generic.IEnumerable`1[System.String" +
                    "])", base.MakeSecondPartOfLogMessage());
            afterLogEntry.Log();
        }
    }
    
    string Egemin.Etricc.Components.Interfaces.IJobService.CreateJob(string agvId, Egemin.Etricc.Components.Interfaces.JobType jobType, string originatorId, string locationId, string carrierId, bool suspended, string viaLocationStation) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "System.String CreateJob(System.String, Egemin.Etricc.Components.Interfaces.JobTyp" +
                    "e, System.String, System.String, System.String, Boolean, System.String)", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(agvId), ", ", base.CallToString(jobType), ", ", base.CallToString(originatorId), ", ", base.CallToString(locationId), ", ", base.CallToString(carrierId), ", ", base.CallToString(suspended), ", ", base.CallToString(viaLocationStation));
            beforeLogEntry.Log();
        }
        string result = ((Egemin.Etricc.Components.Interfaces.IJobService)(this.Wrappee)).CreateJob(agvId, jobType, originatorId, locationId, carrierId, suspended, viaLocationStation);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "System.String CreateJob(System.String, Egemin.Etricc.Components.Interfaces.JobTyp" +
                    "e, System.String, System.String, System.String, Boolean, System.String)", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    void Egemin.Etricc.Components.Interfaces.IJobService.FlushAll(string agvId) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Void FlushAll(System.String)", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(agvId));
            beforeLogEntry.Log();
        }
        ((Egemin.Etricc.Components.Interfaces.IJobService)(this.Wrappee)).FlushAll(agvId);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Void FlushAll(System.String)", base.MakeSecondPartOfLogMessage());
            afterLogEntry.Log();
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.IJobService.Flush(string agvId, System.Collections.Generic.IEnumerable<string> jobIds) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Void Flush(System.String, System.Collections.Generic.IEnumerable`1[System.String]" +
                    ")", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(agvId), ", ", base.CallToString(jobIds));
            beforeLogEntry.Log();
        }
        ((Egemin.Etricc.Components.Interfaces.IJobService)(this.Wrappee)).Flush(agvId, jobIds);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Void Flush(System.String, System.Collections.Generic.IEnumerable`1[System.String]" +
                    ")", base.MakeSecondPartOfLogMessage());
            afterLogEntry.Log();
        }
    }
}
