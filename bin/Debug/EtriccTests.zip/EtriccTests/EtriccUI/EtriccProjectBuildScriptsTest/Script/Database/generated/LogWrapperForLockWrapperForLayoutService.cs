public class LogWrapperForLockWrapperForLayoutService : Egemin.Epia.Foundation.ComponentManagement.WrapperGeneration.LogWrapper<Egemin.Epia.Foundation.ComponentManagement.DynamicWrappers.LockWrapperForLayoutService>, Egemin.Etricc.Components.Interfaces.ILayoutService {
    
    public LogWrapperForLockWrapperForLayoutService(Egemin.Epia.Foundation.ComponentManagement.DynamicWrappers.LockWrapperForLayoutService wrappee) : 
            base(wrappee) {
    }
    
    System.Collections.Generic.IList<string> Egemin.Etricc.Components.Interfaces.ILayoutService.GetLayoutIds() {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[System.String] GetLayoutIds()", base.MakeSecondPartOfLogMessage());
            beforeLogEntry.Log();
        }
        System.Collections.Generic.IList<string> result = ((Egemin.Etricc.Components.Interfaces.ILayoutService)(this.Wrappee)).GetLayoutIds();
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[System.String] GetLayoutIds()", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    Egemin.Etricc.Components.Interfaces.Layout Egemin.Etricc.Components.Interfaces.ILayoutService.GetLayout(string layoutId) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Egemin.Etricc.Components.Interfaces.Layout GetLayout(System.String)", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(layoutId));
            beforeLogEntry.Log();
        }
        Egemin.Etricc.Components.Interfaces.Layout result = ((Egemin.Etricc.Components.Interfaces.ILayoutService)(this.Wrappee)).GetLayout(layoutId);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Egemin.Etricc.Components.Interfaces.Layout GetLayout(System.String)", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.Layout> Egemin.Etricc.Components.Interfaces.ILayoutService.GetLayouts() {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[Egemin.Etricc.Components.Interfaces.Layout] Ge" +
                    "tLayouts()", base.MakeSecondPartOfLogMessage());
            beforeLogEntry.Log();
        }
        System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.Layout> result = ((Egemin.Etricc.Components.Interfaces.ILayoutService)(this.Wrappee)).GetLayouts();
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[Egemin.Etricc.Components.Interfaces.Layout] Ge" +
                    "tLayouts()", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.Layout> Egemin.Etricc.Components.Interfaces.ILayoutService.GetLayoutsById(System.Collections.Generic.IEnumerable<string> layoutIds) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[Egemin.Etricc.Components.Interfaces.Layout] Ge" +
                    "tLayoutsById(System.Collections.Generic.IEnumerable`1[System.String])", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(layoutIds));
            beforeLogEntry.Log();
        }
        System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.Layout> result = ((Egemin.Etricc.Components.Interfaces.ILayoutService)(this.Wrappee)).GetLayoutsById(layoutIds);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[Egemin.Etricc.Components.Interfaces.Layout] Ge" +
                    "tLayoutsById(System.Collections.Generic.IEnumerable`1[System.String])", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    bool Egemin.Etricc.Components.Interfaces.ILayoutService.CalculateRoute(string LayoutId, string fromNodeId, string toNodeId, bool dynamic, ref double cost, ref System.Collections.Generic.IList<string> nodeIds, ref System.Collections.Generic.IList<string> pathSegmentIds) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Boolean CalculateRoute(System.String, System.String, System.String, Boolean, Doub" +
                    "le ByRef, System.Collections.Generic.IList`1[System.String] ByRef, System.Collec" +
                    "tions.Generic.IList`1[System.String] ByRef)", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(LayoutId), ", ", base.CallToString(fromNodeId), ", ", base.CallToString(toNodeId), ", ", base.CallToString(dynamic), ", ", base.CallToString(cost), ", ", base.CallToString(nodeIds), ", ", base.CallToString(pathSegmentIds));
            beforeLogEntry.Log();
        }
        bool result = ((Egemin.Etricc.Components.Interfaces.ILayoutService)(this.Wrappee)).CalculateRoute(LayoutId, fromNodeId, toNodeId, dynamic, ref cost, ref nodeIds, ref pathSegmentIds);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Boolean CalculateRoute(System.String, System.String, System.String, Boolean, Doub" +
                    "le ByRef, System.Collections.Generic.IList`1[System.String] ByRef, System.Collec" +
                    "tions.Generic.IList`1[System.String] ByRef)", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.Position> Egemin.Etricc.Components.Interfaces.ILayoutService.Track(string moverId, string fromNodeId, string toNodeId) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[Egemin.Etricc.Components.Interfaces.Position] " +
                    "Track(System.String, System.String, System.String)", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(moverId), ", ", base.CallToString(fromNodeId), ", ", base.CallToString(toNodeId));
            beforeLogEntry.Log();
        }
        System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.Position> result = ((Egemin.Etricc.Components.Interfaces.ILayoutService)(this.Wrappee)).Track(moverId, fromNodeId, toNodeId);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[Egemin.Etricc.Components.Interfaces.Position] " +
                    "Track(System.String, System.String, System.String)", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    System.Collections.Generic.List<string> Egemin.Etricc.Components.Interfaces.ILayoutService.GetMutexes() {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.List`1[System.String] GetMutexes()", base.MakeSecondPartOfLogMessage());
            beforeLogEntry.Log();
        }
        System.Collections.Generic.List<string> result = ((Egemin.Etricc.Components.Interfaces.ILayoutService)(this.Wrappee)).GetMutexes();
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.List`1[System.String] GetMutexes()", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.LocationGroupInfo> Egemin.Etricc.Components.Interfaces.ILayoutService.GetLocationGroupsInfo() {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[Egemin.Etricc.Components.Interfaces.LocationGr" +
                    "oupInfo] GetLocationGroupsInfo()", base.MakeSecondPartOfLogMessage());
            beforeLogEntry.Log();
        }
        System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.LocationGroupInfo> result = ((Egemin.Etricc.Components.Interfaces.ILayoutService)(this.Wrappee)).GetLocationGroupsInfo();
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[Egemin.Etricc.Components.Interfaces.LocationGr" +
                    "oupInfo] GetLocationGroupsInfo()", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
}
