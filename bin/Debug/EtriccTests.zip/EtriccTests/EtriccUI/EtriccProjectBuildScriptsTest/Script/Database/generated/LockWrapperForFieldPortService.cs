public class LockWrapperForFieldPortService : Egemin.Epia.Foundation.ComponentManagement.WrapperGeneration.LockWrapper<Egemin.Etricc.Components.FieldPortService>, Egemin.Etricc.Components.Interfaces.IFieldPortService {
    
    public LockWrapperForFieldPortService(Egemin.Etricc.Components.FieldPortService wrappee) : 
            base(wrappee) {
    }
    
    System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.FieldPortInfo> Egemin.Etricc.Components.Interfaces.IFieldPortService.GetFieldPortInfos() {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.IFieldPortService)(this.Wrappee)).GetFieldPortInfos();
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    Egemin.Epia.Foundation.ServiceModel.Polling.ChangeSet<string, Egemin.Etricc.Components.Interfaces.FieldPortInfo> Egemin.Etricc.Components.Interfaces.IFieldPortService.Poll(int version) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.IFieldPortService)(this.Wrappee)).Poll(version);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
}
