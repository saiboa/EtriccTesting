public class LockWrapperForAgvService : Egemin.Epia.Foundation.ComponentManagement.WrapperGeneration.LockWrapper<Egemin.Etricc.Components.AgvService>, Egemin.Etricc.Components.Interfaces.IAgvService {
    
    public LockWrapperForAgvService(Egemin.Etricc.Components.AgvService wrappee) : 
            base(wrappee) {
    }
    
    void Egemin.Etricc.Components.Interfaces.IAgvService.Freeze(System.Collections.Generic.IEnumerable<string> agvIds) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).Freeze(agvIds);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.IAgvService.Thaw(System.Collections.Generic.IEnumerable<string> agvIds) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).Thaw(agvIds);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.IAgvService.StartAgvLogging(System.Collections.Generic.IEnumerable<string> agvIds, Egemin.Etricc.Components.Interfaces.AgvLoggingType loggingType) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).StartAgvLogging(agvIds, loggingType);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.IAgvService.HandleAgvTestSequence(System.Collections.Generic.IEnumerable<string> agvIds, Egemin.Etricc.Components.Interfaces.AgvTestSequenceRequest agvTestSequenceRequest) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).HandleAgvTestSequence(agvIds, agvTestSequenceRequest);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.IAgvService.SetBooleanProperty(System.Collections.Generic.IEnumerable<string> agvIds, string propertyName, bool value) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).SetBooleanProperty(agvIds, propertyName, value);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.IAgvService.SetTextProperty(System.Collections.Generic.IEnumerable<string> agvIds, string propertyName, string value) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).SetTextProperty(agvIds, propertyName, value);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.IAgvService.SetNumericProperty(System.Collections.Generic.IEnumerable<string> agvIds, string propertyName, int value) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).SetNumericProperty(agvIds, propertyName, value);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    System.Collections.Generic.List<string> Egemin.Etricc.Components.Interfaces.IAgvService.GetMaintenanceLocationIDs(string agvId) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).GetMaintenanceLocationIDs(agvId);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.IAgvService.Maintenance(string agvId, string maintenanceLocationId) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).Maintenance(agvId, maintenanceLocationId);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    System.Collections.Generic.IList<string> Egemin.Etricc.Components.Interfaces.IAgvService.GetAgvIds() {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).GetAgvIds();
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    System.Collections.Generic.IList<string> Egemin.Etricc.Components.Interfaces.IAgvService.GetAgvTypes() {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).GetAgvTypes();
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    string Egemin.Etricc.Components.Interfaces.IAgvService.GetAgvType(string agvId) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).GetAgvType(agvId);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    System.Collections.Generic.IList<string> Egemin.Etricc.Components.Interfaces.IAgvService.GetCarrierIds(string agvTypeId) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).GetCarrierIds(agvTypeId);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    Egemin.Etricc.Components.Interfaces.Position Egemin.Etricc.Components.Interfaces.IAgvService.GetCarrierPosition(string agvTypeId, string carrierId) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).GetCarrierPosition(agvTypeId, carrierId);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    Egemin.Etricc.Components.Interfaces.AgvImage Egemin.Etricc.Components.Interfaces.IAgvService.GetAgvImage(string type) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).GetAgvImage(type);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.AgvImage> Egemin.Etricc.Components.Interfaces.IAgvService.GetAgvImages() {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).GetAgvImages();
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.AgvInfo> Egemin.Etricc.Components.Interfaces.IAgvService.GetAgvInfos() {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).GetAgvInfos();
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    Egemin.Etricc.Components.Interfaces.AgvInfo Egemin.Etricc.Components.Interfaces.IAgvService.GetAgvInfo(string agvId) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).GetAgvInfo(agvId);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.AgvInfo> Egemin.Etricc.Components.Interfaces.IAgvService.GetDetailedAgvInfos(System.Collections.Generic.IEnumerable<string> agvIds) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).GetDetailedAgvInfos(agvIds);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    Egemin.Etricc.Components.Interfaces.AgvSystemOverviewInfo Egemin.Etricc.Components.Interfaces.IAgvService.GetAgvSystemOverviewInfo(string agvId) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).GetAgvSystemOverviewInfo(agvId);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.AgvSystemOverviewInfo> Egemin.Etricc.Components.Interfaces.IAgvService.GetAgvSystemOverviewInfos() {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).GetAgvSystemOverviewInfos();
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    Egemin.Etricc.Components.Interfaces.AgvSystemOverviewInfo Egemin.Etricc.Components.Interfaces.IAgvService.GetDetailedAgvSystemOverviewInfo(string agvId) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).GetDetailedAgvSystemOverviewInfo(agvId);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.AgvSystemOverviewInfo> Egemin.Etricc.Components.Interfaces.IAgvService.GetDetailedAgvSystemOverviewInfos() {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).GetDetailedAgvSystemOverviewInfos();
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.IAgvService.Restart(System.Collections.Generic.IEnumerable<string> agvIds) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).Restart(agvIds);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.IAgvService.Restart() {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).Restart();
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.IAgvService.Stop(System.Collections.Generic.IEnumerable<string> agvIds) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).Stop(agvIds);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.IAgvService.Stop() {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).Stop();
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.IAgvService.Retire(System.Collections.Generic.IEnumerable<string> agvIds) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).Retire(agvIds);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.IAgvService.Retire() {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).Retire();
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.IAgvService.Deploy(System.Collections.Generic.IEnumerable<string> agvIds) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).Deploy(agvIds);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.IAgvService.Deploy() {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).Deploy();
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.IAgvService.Suspend(System.Collections.Generic.IEnumerable<string> agvIds) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).Suspend(agvIds);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.IAgvService.Suspend() {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).Suspend();
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.IAgvService.Release(System.Collections.Generic.IEnumerable<string> agvIds) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).Release(agvIds);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.IAgvService.Release() {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).Release();
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.IAgvService.SetMode(System.Collections.Generic.IEnumerable<string> agvIds, Egemin.Etricc.Components.Interfaces.MoverMode mode) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).SetMode(agvIds, mode);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.IAgvService.CancelCurrentBatch() {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).CancelCurrentBatch();
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.IAgvService.CancelCurrentBatch(System.Collections.Generic.IEnumerable<string> agvIds) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).CancelCurrentBatch(agvIds);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    System.Collections.Generic.IList<string> Egemin.Etricc.Components.Interfaces.IAgvService.GetAgvIdsFromAgvType(string agvTypeId) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).GetAgvIdsFromAgvType(agvTypeId);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.IAgvService.StartDownload(System.Collections.Generic.IEnumerable<string> agvIds) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).StartDownload(agvIds);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.IAgvService.StopDownload(System.Collections.Generic.IEnumerable<string> agvIds) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).StopDownload(agvIds);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
}
