public class LockWrapperForWeekPlanService : Egemin.Epia.Foundation.ComponentManagement.WrapperGeneration.LockWrapper<Egemin.Etricc.Components.WeekPlanService>, Egemin.Etricc.Components.Interfaces.IWeekPlanService {
    
    public LockWrapperForWeekPlanService(Egemin.Etricc.Components.WeekPlanService wrappee) : 
            base(wrappee) {
    }
    
    string Egemin.Etricc.Components.Interfaces.IWeekPlanService.CreateWeekPlan(string agvId, string originatorId, string weekPlanId, System.DayOfWeek day, int startHour, int startMinute, int duration, string arguments, bool enabled) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.IWeekPlanService)(this.Wrappee)).CreateWeekPlan(agvId, originatorId, weekPlanId, day, startHour, startMinute, duration, arguments, enabled);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.IWeekPlanService.Delete(string agvId, System.Collections.Generic.IEnumerable<string> weekplanIds) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            ((Egemin.Etricc.Components.Interfaces.IWeekPlanService)(this.Wrappee)).Delete(agvId, weekplanIds);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.IWeekPlanService.Disable(string agvId, System.Collections.Generic.IEnumerable<string> weekplanIds) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            ((Egemin.Etricc.Components.Interfaces.IWeekPlanService)(this.Wrappee)).Disable(agvId, weekplanIds);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    string Egemin.Etricc.Components.Interfaces.IWeekPlanService.EditWeekPlan(string agvId, string originatorId, string weekPlanId, System.DayOfWeek day, int startHour, int startMinute, int duration, string arguments, bool enabled) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.IWeekPlanService)(this.Wrappee)).EditWeekPlan(agvId, originatorId, weekPlanId, day, startHour, startMinute, duration, arguments, enabled);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.IWeekPlanService.Enable(string agvId, System.Collections.Generic.IEnumerable<string> weekplanIds) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            ((Egemin.Etricc.Components.Interfaces.IWeekPlanService)(this.Wrappee)).Enable(agvId, weekplanIds);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    System.Collections.Generic.IDictionary<string, System.Collections.Generic.List<string>> Egemin.Etricc.Components.Interfaces.IWeekPlanService.GetWeekPlanIds() {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.IWeekPlanService)(this.Wrappee)).GetWeekPlanIds();
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    System.Collections.Generic.IDictionary<string, System.Collections.Generic.List<string>> Egemin.Etricc.Components.Interfaces.IWeekPlanService.GetWeekPlanIdsForAgvs(System.Collections.Generic.IEnumerable<string> agvIds) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.IWeekPlanService)(this.Wrappee)).GetWeekPlanIdsForAgvs(agvIds);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    System.Collections.Generic.IDictionary<string, System.Collections.Generic.List<Egemin.Etricc.Components.Interfaces.WeekPlanInfo>> Egemin.Etricc.Components.Interfaces.IWeekPlanService.GetWeekPlanInfos() {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.IWeekPlanService)(this.Wrappee)).GetWeekPlanInfos();
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    System.Collections.Generic.IDictionary<string, System.Collections.Generic.List<Egemin.Etricc.Components.Interfaces.WeekPlanInfo>> Egemin.Etricc.Components.Interfaces.IWeekPlanService.GetWeekPlanInfosForAgvs(System.Collections.Generic.IEnumerable<string> agvIds) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.IWeekPlanService)(this.Wrappee)).GetWeekPlanInfosForAgvs(agvIds);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    System.Collections.Generic.IDictionary<string, Egemin.Epia.Foundation.ServiceModel.Polling.ChangeSet<string, Egemin.Etricc.Components.Interfaces.WeekPlanInfo>> Egemin.Etricc.Components.Interfaces.IWeekPlanService.Poll(System.Collections.Generic.IEnumerable<Egemin.Etricc.Components.Interfaces.VersionedId> versionedAgvIds) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.IWeekPlanService)(this.Wrappee)).Poll(versionedAgvIds);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
}
