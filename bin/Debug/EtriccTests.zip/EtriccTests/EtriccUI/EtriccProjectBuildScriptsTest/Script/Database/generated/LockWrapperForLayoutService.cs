public class LockWrapperForLayoutService : Egemin.Epia.Foundation.ComponentManagement.WrapperGeneration.LockWrapper<Egemin.Etricc.Components.LayoutService>, Egemin.Etricc.Components.Interfaces.ILayoutService {
    
    public LockWrapperForLayoutService(Egemin.Etricc.Components.LayoutService wrappee) : 
            base(wrappee) {
    }
    
    System.Collections.Generic.IList<string> Egemin.Etricc.Components.Interfaces.ILayoutService.GetLayoutIds() {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.ILayoutService)(this.Wrappee)).GetLayoutIds();
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    Egemin.Etricc.Components.Interfaces.Layout Egemin.Etricc.Components.Interfaces.ILayoutService.GetLayout(string layoutId) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.ILayoutService)(this.Wrappee)).GetLayout(layoutId);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.Layout> Egemin.Etricc.Components.Interfaces.ILayoutService.GetLayouts() {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.ILayoutService)(this.Wrappee)).GetLayouts();
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.Layout> Egemin.Etricc.Components.Interfaces.ILayoutService.GetLayoutsById(System.Collections.Generic.IEnumerable<string> layoutIds) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.ILayoutService)(this.Wrappee)).GetLayoutsById(layoutIds);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    bool Egemin.Etricc.Components.Interfaces.ILayoutService.CalculateRoute(string LayoutId, string fromNodeId, string toNodeId, bool dynamic, ref double cost, ref System.Collections.Generic.IList<string> nodeIds, ref System.Collections.Generic.IList<string> pathSegmentIds) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.ILayoutService)(this.Wrappee)).CalculateRoute(LayoutId, fromNodeId, toNodeId, dynamic, ref cost, ref nodeIds, ref pathSegmentIds);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.Position> Egemin.Etricc.Components.Interfaces.ILayoutService.Track(string moverId, string fromNodeId, string toNodeId) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.ILayoutService)(this.Wrappee)).Track(moverId, fromNodeId, toNodeId);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    System.Collections.Generic.List<string> Egemin.Etricc.Components.Interfaces.ILayoutService.GetMutexes() {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.ILayoutService)(this.Wrappee)).GetMutexes();
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.LocationGroupInfo> Egemin.Etricc.Components.Interfaces.ILayoutService.GetLocationGroupsInfo() {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.ILayoutService)(this.Wrappee)).GetLocationGroupsInfo();
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
}
