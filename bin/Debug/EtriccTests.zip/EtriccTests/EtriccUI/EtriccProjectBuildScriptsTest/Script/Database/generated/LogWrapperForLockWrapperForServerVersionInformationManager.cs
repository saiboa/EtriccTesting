public class LogWrapperForLockWrapperForServerVersionInformationManager : Egemin.Epia.Foundation.ComponentManagement.WrapperGeneration.LogWrapper<Egemin.Epia.Foundation.ComponentManagement.DynamicWrappers.LockWrapperForServerVersionInformationManager>, Egemin.Epia.Foundation.VersionInformation.Interfaces.IServerVersionInformation {
    
    public LogWrapperForLockWrapperForServerVersionInformationManager(Egemin.Epia.Foundation.ComponentManagement.DynamicWrappers.LockWrapperForServerVersionInformationManager wrappee) : 
            base(wrappee) {
    }
    
    Egemin.Epia.Foundation.ServiceModel.Polling.ChangeSet<string, Egemin.Epia.Foundation.VersionInformation.AssemblyFileInformation> Egemin.Epia.Foundation.VersionInformation.Interfaces.IServerVersionInformation.PollAssemblyFileInformation(int version) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Egemin.Epia.Foundation.ServiceModel.Polling.ChangeSet`2[System.String,Egemin.Epia" +
                    ".Foundation.VersionInformation.AssemblyFileInformation] PollAssemblyFileInformat" +
                    "ion(Int32)", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(version));
            beforeLogEntry.Log();
        }
        Egemin.Epia.Foundation.ServiceModel.Polling.ChangeSet<string, Egemin.Epia.Foundation.VersionInformation.AssemblyFileInformation> result = ((Egemin.Epia.Foundation.VersionInformation.Interfaces.IServerVersionInformation)(this.Wrappee)).PollAssemblyFileInformation(version);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Egemin.Epia.Foundation.ServiceModel.Polling.ChangeSet`2[System.String,Egemin.Epia" +
                    ".Foundation.VersionInformation.AssemblyFileInformation] PollAssemblyFileInformat" +
                    "ion(Int32)", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
}
