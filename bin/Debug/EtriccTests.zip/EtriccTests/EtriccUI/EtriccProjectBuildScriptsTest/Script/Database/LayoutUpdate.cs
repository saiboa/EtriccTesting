﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Egemin.EPIA.ComponentModel;
using Egemin.EPIA;
using System.ServiceProcess;
using System.Windows.Forms;
using System.Threading;
using System.Diagnostics;
using Egemin.Etricc.Scripts.Core;
using Egemin.Etricc.Scripts.Main;

namespace Egemin.Etricc.Scripts.Database
{
    [Entry("LayoutUpdate", "Main")]
    [Reference("System.ServiceProcess")]
    [Include(@"..\Core\Script.cs")]
    public class LayoutUpdate : Script
    {
        /// <summary>Service stop timeout in seconds.</summary>
        const int TIMEOUT = 300;

        public override void Run()
        {
            Dialog.SetProgress("Layout Update", "Getting service controller");

            var service = GetEtriccService();

            if (!IsServiceStatusValidForUpdate(service, TIMEOUT))
            {
                Dialog.MessageBox.Show("The service does not exist or could not be stopped, please verify or stop it manually, and try again");
                return;
            }

            Dialog.SetProgress("Layout Update", "Getting dynamic project data from database");
            Run<LoadHybrid>();

            Dialog.SetProgress("Layout Update", "Saving BeforeUpdate.Xml");
            Project.SaveXml(string.Format(@"{0}Data\Xml\BeforeUpdate.Xml", Project.WorkingDirName));

            Dialog.SetProgress("Layout Update", "Building layout");
            Run<Build>();

            Dialog.SetProgress("Layout Update", "Saving AfterUpdate.Xml");
            Project.SaveXml(string.Format(@"{0}Data\Xml\AfterUpdate.Xml", Project.WorkingDirName));

            Dialog.SetProgress("Layout Update", "Saving dynamic project data to database");
            Run<SaveHybrid>();

            Dialog.SetProgress("Layout Update", "Starting the E'tricc service");
            service.Start();

            Dialog.MessageBox.Show("The update has finished. Please close the E'tricc Explorer without saving", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }



        /// <summary>
        /// Gets a reference to the E'tricc service.
        /// </summary>
        private ServiceController GetEtriccService()
        {
            var services = from service in ServiceController.GetServices(Environment.MachineName)
                           where service.ServiceName.StartsWith("E'tricc")
                              || service.ServiceName.StartsWith("E'pia")
                           select service;

            return services.FirstOrDefault();
        }


        /// <summary>
        /// Check the E'tricc service status
        /// </summary>
        private bool IsServiceStatusValidForUpdate(ServiceController service, int timeout)
        {
            if (service == null)
            {
                Dialog.SetProgress("Layout Update", "Servicecontroller does not exist, the update process cannot continue");
                return false;
            }

            if (service.Status == ServiceControllerStatus.Stopped)
            {
                Dialog.SetProgress("Layout Update", "The service is not running, the update process will continue");
                return true;
            }

            if (MessageBox.Show(null, string.Format(@"The E'tricc service has not entered the stopped state.{0}Press Yes to stop the service and continue the system update.{1}Press No to abort the update process", Environment.NewLine, Environment.NewLine), "E'tricc service not stopped", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes)
            {
                Dialog.SetProgress("Layout Update", "Layout update process aborted by operator");
                return false;
            }

            Dialog.SetProgress("Layout Update", "Stopping the E'tricc service");

            service.Stop();
            service.WaitForStatus(ServiceControllerStatus.Stopped, new TimeSpan(0, 5, 0));

            Dialog.SetProgress("Layout Update", "Waiting for the service to enter the stopped state ...");

            int counter = 0;
            while (counter < timeout)
            {
                counter++;
                service.Refresh();

                if (service.Status == ServiceControllerStatus.Stopped)
                    break;

                Thread.Sleep(1000);
                Application.DoEvents();
            }

            if (service.Status != ServiceControllerStatus.Stopped)
            {
                Dialog.SetProgress("Layout Update", "The service could not be stopped within the configured timeframe");

                Dialog.MessageBox.Show("The E'tricc service has not entered the stopped state within the configured timeout. The update process will be aborted", "E'tricc service hung", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            Dialog.SetProgress("Layout Update", "The service has entered the stopped state");

            return true;
        }
    } 
}