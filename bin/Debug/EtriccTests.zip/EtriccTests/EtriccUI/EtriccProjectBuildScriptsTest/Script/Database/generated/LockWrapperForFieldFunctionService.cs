public class LockWrapperForFieldFunctionService : Egemin.Epia.Foundation.ComponentManagement.WrapperGeneration.LockWrapper<Egemin.Etricc.Components.FieldFunctionService>, Egemin.Etricc.Components.Interfaces.IFieldFunctionService {
    
    public LockWrapperForFieldFunctionService(Egemin.Etricc.Components.FieldFunctionService wrappee) : 
            base(wrappee) {
    }
    
    System.Collections.Generic.IList<string> Egemin.Etricc.Components.Interfaces.IFieldFunctionService.GetFieldFunctionIds() {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.IFieldFunctionService)(this.Wrappee)).GetFieldFunctionIds();
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.FieldFunctionInfo> Egemin.Etricc.Components.Interfaces.IFieldFunctionService.GetFieldFunctionInfos() {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.IFieldFunctionService)(this.Wrappee)).GetFieldFunctionInfos();
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.FieldFunctionInfo> Egemin.Etricc.Components.Interfaces.IFieldFunctionService.GetFieldFunctionInfos(System.Collections.Generic.IEnumerable<string> fieldFunctionIds) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.IFieldFunctionService)(this.Wrappee)).GetFieldFunctionInfos(fieldFunctionIds);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.FieldFunctionInfo> Egemin.Etricc.Components.Interfaces.IFieldFunctionService.GetDetailedFieldFunctionInfos(System.Collections.Generic.IEnumerable<string> fieldFunctionIds) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.IFieldFunctionService)(this.Wrappee)).GetDetailedFieldFunctionInfos(fieldFunctionIds);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    Egemin.Epia.Foundation.ServiceModel.Polling.ChangeSet<string, Egemin.Etricc.Components.Interfaces.FieldFunctionInfo> Egemin.Etricc.Components.Interfaces.IFieldFunctionService.Poll(int version) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.IFieldFunctionService)(this.Wrappee)).Poll(version);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.IFieldFunctionService.SetMode(System.Collections.Generic.IEnumerable<string> fieldFunctionIds, Egemin.Etricc.Components.Interfaces.FieldFunctionMode mode) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            ((Egemin.Etricc.Components.Interfaces.IFieldFunctionService)(this.Wrappee)).SetMode(fieldFunctionIds, mode);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.IFieldFunctionService.SetForcedState(System.Collections.Generic.IEnumerable<string> fieldFunctionIds, bool state) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            ((Egemin.Etricc.Components.Interfaces.IFieldFunctionService)(this.Wrappee)).SetForcedState(fieldFunctionIds, state);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.FieldFunctionImage> Egemin.Etricc.Components.Interfaces.IFieldFunctionService.GetFieldFunctionImages() {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.IFieldFunctionService)(this.Wrappee)).GetFieldFunctionImages();
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
}
