public class LockWrapperForStationService : Egemin.Epia.Foundation.ComponentManagement.WrapperGeneration.LockWrapper<Egemin.Etricc.Components.StationService>, Egemin.Etricc.Components.Interfaces.IStationService {
    
    public LockWrapperForStationService(Egemin.Etricc.Components.StationService wrappee) : 
            base(wrappee) {
    }
    
    System.Collections.Generic.IList<string> Egemin.Etricc.Components.Interfaces.IStationService.GetStationIds() {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.IStationService)(this.Wrappee)).GetStationIds();
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    Egemin.Etricc.Components.Interfaces.StationInfo Egemin.Etricc.Components.Interfaces.IStationService.GetStationInfo(string stationId) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.IStationService)(this.Wrappee)).GetStationInfo(stationId);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.StationInfo> Egemin.Etricc.Components.Interfaces.IStationService.GetStationInfos() {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.IStationService)(this.Wrappee)).GetStationInfos();
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.StationInfo> Egemin.Etricc.Components.Interfaces.IStationService.GetStationInfos(System.Collections.Generic.IEnumerable<string> stationIds) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.IStationService)(this.Wrappee)).GetStationInfos(stationIds);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.StationInfo> Egemin.Etricc.Components.Interfaces.IStationService.GetDetailedStationInfos(System.Collections.Generic.IEnumerable<string> stationIds) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.IStationService)(this.Wrappee)).GetDetailedStationInfos(stationIds);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    Egemin.Epia.Foundation.ServiceModel.Polling.ChangeSet<string, Egemin.Etricc.Components.Interfaces.StationInfo> Egemin.Etricc.Components.Interfaces.IStationService.Poll(int version) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.IStationService)(this.Wrappee)).Poll(version);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.IStationService.SetMode(System.Collections.Generic.IEnumerable<string> stationIds, Egemin.Etricc.Components.Interfaces.StationMode mode) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            ((Egemin.Etricc.Components.Interfaces.IStationService)(this.Wrappee)).SetMode(stationIds, mode);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.StationSystemOverviewInfo> Egemin.Etricc.Components.Interfaces.IStationService.GetStationSystemOverviewInfos() {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.IStationService)(this.Wrappee)).GetStationSystemOverviewInfos();
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    System.Collections.Generic.Dictionary<string, System.Collections.Generic.List<string>> Egemin.Etricc.Components.Interfaces.IStationService.GetMutexes() {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.IStationService)(this.Wrappee)).GetMutexes();
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
}
