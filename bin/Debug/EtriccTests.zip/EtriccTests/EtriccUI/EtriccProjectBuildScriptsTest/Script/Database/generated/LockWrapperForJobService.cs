public class LockWrapperForJobService : Egemin.Epia.Foundation.ComponentManagement.WrapperGeneration.LockWrapper<Egemin.Etricc.Components.JobService>, Egemin.Etricc.Components.Interfaces.IJobService {
    
    public LockWrapperForJobService(Egemin.Etricc.Components.JobService wrappee) : 
            base(wrappee) {
    }
    
    System.Collections.Generic.IDictionary<string, System.Collections.Generic.List<string>> Egemin.Etricc.Components.Interfaces.IJobService.GetJobIds() {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.IJobService)(this.Wrappee)).GetJobIds();
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    System.Collections.Generic.IDictionary<string, System.Collections.Generic.List<string>> Egemin.Etricc.Components.Interfaces.IJobService.GetJobIdsForAgvs(System.Collections.Generic.IEnumerable<string> agvIds) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.IJobService)(this.Wrappee)).GetJobIdsForAgvs(agvIds);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    System.Collections.Generic.IDictionary<string, System.Collections.Generic.List<Egemin.Etricc.Components.Interfaces.JobInfo>> Egemin.Etricc.Components.Interfaces.IJobService.GetJobInfos() {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.IJobService)(this.Wrappee)).GetJobInfos();
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    System.Collections.Generic.IDictionary<string, System.Collections.Generic.List<Egemin.Etricc.Components.Interfaces.JobInfo>> Egemin.Etricc.Components.Interfaces.IJobService.GetJobInfosForAgvs(System.Collections.Generic.IEnumerable<string> agvIds) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.IJobService)(this.Wrappee)).GetJobInfosForAgvs(agvIds);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.JobInfo> Egemin.Etricc.Components.Interfaces.IJobService.GetDetailedJobInfos(string agvId, System.Collections.Generic.IEnumerable<string> jobIds) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.IJobService)(this.Wrappee)).GetDetailedJobInfos(agvId, jobIds);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    System.Collections.Generic.IDictionary<string, Egemin.Epia.Foundation.ServiceModel.Polling.ChangeSet<string, Egemin.Etricc.Components.Interfaces.JobInfo>> Egemin.Etricc.Components.Interfaces.IJobService.Poll(System.Collections.Generic.IEnumerable<Egemin.Etricc.Components.Interfaces.VersionedId> versionedAgvIds) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.IJobService)(this.Wrappee)).Poll(versionedAgvIds);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.IJobService.Abort(string agvId, System.Collections.Generic.IEnumerable<string> jobIds) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            ((Egemin.Etricc.Components.Interfaces.IJobService)(this.Wrappee)).Abort(agvId, jobIds);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.IJobService.Cancel(string agvId, System.Collections.Generic.IEnumerable<string> jobIds) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            ((Egemin.Etricc.Components.Interfaces.IJobService)(this.Wrappee)).Cancel(agvId, jobIds);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    string Egemin.Etricc.Components.Interfaces.IJobService.CreateJob(string agvId, Egemin.Etricc.Components.Interfaces.JobType jobType, string originatorId, string locationId, string carrierId, bool suspended, string viaLocationStation) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.IJobService)(this.Wrappee)).CreateJob(agvId, jobType, originatorId, locationId, carrierId, suspended, viaLocationStation);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.IJobService.FlushAll(string agvId) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            ((Egemin.Etricc.Components.Interfaces.IJobService)(this.Wrappee)).FlushAll(agvId);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.IJobService.Flush(string agvId, System.Collections.Generic.IEnumerable<string> jobIds) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            ((Egemin.Etricc.Components.Interfaces.IJobService)(this.Wrappee)).Flush(agvId, jobIds);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
}
