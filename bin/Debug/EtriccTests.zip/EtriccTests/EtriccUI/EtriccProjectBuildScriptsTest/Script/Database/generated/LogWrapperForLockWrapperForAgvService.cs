public class LogWrapperForLockWrapperForAgvService : Egemin.Epia.Foundation.ComponentManagement.WrapperGeneration.LogWrapper<Egemin.Epia.Foundation.ComponentManagement.DynamicWrappers.LockWrapperForAgvService>, Egemin.Etricc.Components.Interfaces.IAgvService {
    
    public LogWrapperForLockWrapperForAgvService(Egemin.Epia.Foundation.ComponentManagement.DynamicWrappers.LockWrapperForAgvService wrappee) : 
            base(wrappee) {
    }
    
    void Egemin.Etricc.Components.Interfaces.IAgvService.Freeze(System.Collections.Generic.IEnumerable<string> agvIds) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Void Freeze(System.Collections.Generic.IEnumerable`1[System.String])", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(agvIds));
            beforeLogEntry.Log();
        }
        ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).Freeze(agvIds);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Void Freeze(System.Collections.Generic.IEnumerable`1[System.String])", base.MakeSecondPartOfLogMessage());
            afterLogEntry.Log();
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.IAgvService.Thaw(System.Collections.Generic.IEnumerable<string> agvIds) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Void Thaw(System.Collections.Generic.IEnumerable`1[System.String])", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(agvIds));
            beforeLogEntry.Log();
        }
        ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).Thaw(agvIds);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Void Thaw(System.Collections.Generic.IEnumerable`1[System.String])", base.MakeSecondPartOfLogMessage());
            afterLogEntry.Log();
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.IAgvService.StartAgvLogging(System.Collections.Generic.IEnumerable<string> agvIds, Egemin.Etricc.Components.Interfaces.AgvLoggingType loggingType) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Void StartAgvLogging(System.Collections.Generic.IEnumerable`1[System.String], Ege" +
                    "min.Etricc.Components.Interfaces.AgvLoggingType)", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(agvIds), ", ", base.CallToString(loggingType));
            beforeLogEntry.Log();
        }
        ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).StartAgvLogging(agvIds, loggingType);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Void StartAgvLogging(System.Collections.Generic.IEnumerable`1[System.String], Ege" +
                    "min.Etricc.Components.Interfaces.AgvLoggingType)", base.MakeSecondPartOfLogMessage());
            afterLogEntry.Log();
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.IAgvService.HandleAgvTestSequence(System.Collections.Generic.IEnumerable<string> agvIds, Egemin.Etricc.Components.Interfaces.AgvTestSequenceRequest agvTestSequenceRequest) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Void HandleAgvTestSequence(System.Collections.Generic.IEnumerable`1[System.String" +
                    "], Egemin.Etricc.Components.Interfaces.AgvTestSequenceRequest)", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(agvIds), ", ", base.CallToString(agvTestSequenceRequest));
            beforeLogEntry.Log();
        }
        ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).HandleAgvTestSequence(agvIds, agvTestSequenceRequest);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Void HandleAgvTestSequence(System.Collections.Generic.IEnumerable`1[System.String" +
                    "], Egemin.Etricc.Components.Interfaces.AgvTestSequenceRequest)", base.MakeSecondPartOfLogMessage());
            afterLogEntry.Log();
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.IAgvService.SetBooleanProperty(System.Collections.Generic.IEnumerable<string> agvIds, string propertyName, bool value) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Void SetBooleanProperty(System.Collections.Generic.IEnumerable`1[System.String], " +
                    "System.String, Boolean)", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(agvIds), ", ", base.CallToString(propertyName), ", ", base.CallToString(value));
            beforeLogEntry.Log();
        }
        ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).SetBooleanProperty(agvIds, propertyName, value);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Void SetBooleanProperty(System.Collections.Generic.IEnumerable`1[System.String], " +
                    "System.String, Boolean)", base.MakeSecondPartOfLogMessage());
            afterLogEntry.Log();
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.IAgvService.SetTextProperty(System.Collections.Generic.IEnumerable<string> agvIds, string propertyName, string value) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Void SetTextProperty(System.Collections.Generic.IEnumerable`1[System.String], Sys" +
                    "tem.String, System.String)", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(agvIds), ", ", base.CallToString(propertyName), ", ", base.CallToString(value));
            beforeLogEntry.Log();
        }
        ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).SetTextProperty(agvIds, propertyName, value);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Void SetTextProperty(System.Collections.Generic.IEnumerable`1[System.String], Sys" +
                    "tem.String, System.String)", base.MakeSecondPartOfLogMessage());
            afterLogEntry.Log();
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.IAgvService.SetNumericProperty(System.Collections.Generic.IEnumerable<string> agvIds, string propertyName, int value) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Void SetNumericProperty(System.Collections.Generic.IEnumerable`1[System.String], " +
                    "System.String, Int32)", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(agvIds), ", ", base.CallToString(propertyName), ", ", base.CallToString(value));
            beforeLogEntry.Log();
        }
        ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).SetNumericProperty(agvIds, propertyName, value);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Void SetNumericProperty(System.Collections.Generic.IEnumerable`1[System.String], " +
                    "System.String, Int32)", base.MakeSecondPartOfLogMessage());
            afterLogEntry.Log();
        }
    }
    
    System.Collections.Generic.List<string> Egemin.Etricc.Components.Interfaces.IAgvService.GetMaintenanceLocationIDs(string agvId) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.List`1[System.String] GetMaintenanceLocationIDs(System" +
                    ".String)", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(agvId));
            beforeLogEntry.Log();
        }
        System.Collections.Generic.List<string> result = ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).GetMaintenanceLocationIDs(agvId);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.List`1[System.String] GetMaintenanceLocationIDs(System" +
                    ".String)", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    void Egemin.Etricc.Components.Interfaces.IAgvService.Maintenance(string agvId, string maintenanceLocationId) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Void Maintenance(System.String, System.String)", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(agvId), ", ", base.CallToString(maintenanceLocationId));
            beforeLogEntry.Log();
        }
        ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).Maintenance(agvId, maintenanceLocationId);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Void Maintenance(System.String, System.String)", base.MakeSecondPartOfLogMessage());
            afterLogEntry.Log();
        }
    }
    
    System.Collections.Generic.IList<string> Egemin.Etricc.Components.Interfaces.IAgvService.GetAgvIds() {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[System.String] GetAgvIds()", base.MakeSecondPartOfLogMessage());
            beforeLogEntry.Log();
        }
        System.Collections.Generic.IList<string> result = ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).GetAgvIds();
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[System.String] GetAgvIds()", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    System.Collections.Generic.IList<string> Egemin.Etricc.Components.Interfaces.IAgvService.GetAgvTypes() {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[System.String] GetAgvTypes()", base.MakeSecondPartOfLogMessage());
            beforeLogEntry.Log();
        }
        System.Collections.Generic.IList<string> result = ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).GetAgvTypes();
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[System.String] GetAgvTypes()", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    string Egemin.Etricc.Components.Interfaces.IAgvService.GetAgvType(string agvId) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "System.String GetAgvType(System.String)", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(agvId));
            beforeLogEntry.Log();
        }
        string result = ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).GetAgvType(agvId);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "System.String GetAgvType(System.String)", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    System.Collections.Generic.IList<string> Egemin.Etricc.Components.Interfaces.IAgvService.GetCarrierIds(string agvTypeId) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[System.String] GetCarrierIds(System.String)", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(agvTypeId));
            beforeLogEntry.Log();
        }
        System.Collections.Generic.IList<string> result = ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).GetCarrierIds(agvTypeId);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[System.String] GetCarrierIds(System.String)", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    Egemin.Etricc.Components.Interfaces.Position Egemin.Etricc.Components.Interfaces.IAgvService.GetCarrierPosition(string agvTypeId, string carrierId) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Egemin.Etricc.Components.Interfaces.Position GetCarrierPosition(System.String, Sy" +
                    "stem.String)", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(agvTypeId), ", ", base.CallToString(carrierId));
            beforeLogEntry.Log();
        }
        Egemin.Etricc.Components.Interfaces.Position result = ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).GetCarrierPosition(agvTypeId, carrierId);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Egemin.Etricc.Components.Interfaces.Position GetCarrierPosition(System.String, Sy" +
                    "stem.String)", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    Egemin.Etricc.Components.Interfaces.AgvImage Egemin.Etricc.Components.Interfaces.IAgvService.GetAgvImage(string type) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Egemin.Etricc.Components.Interfaces.AgvImage GetAgvImage(System.String)", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(type));
            beforeLogEntry.Log();
        }
        Egemin.Etricc.Components.Interfaces.AgvImage result = ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).GetAgvImage(type);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Egemin.Etricc.Components.Interfaces.AgvImage GetAgvImage(System.String)", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.AgvImage> Egemin.Etricc.Components.Interfaces.IAgvService.GetAgvImages() {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[Egemin.Etricc.Components.Interfaces.AgvImage] " +
                    "GetAgvImages()", base.MakeSecondPartOfLogMessage());
            beforeLogEntry.Log();
        }
        System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.AgvImage> result = ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).GetAgvImages();
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[Egemin.Etricc.Components.Interfaces.AgvImage] " +
                    "GetAgvImages()", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.AgvInfo> Egemin.Etricc.Components.Interfaces.IAgvService.GetAgvInfos() {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[Egemin.Etricc.Components.Interfaces.AgvInfo] G" +
                    "etAgvInfos()", base.MakeSecondPartOfLogMessage());
            beforeLogEntry.Log();
        }
        System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.AgvInfo> result = ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).GetAgvInfos();
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[Egemin.Etricc.Components.Interfaces.AgvInfo] G" +
                    "etAgvInfos()", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    Egemin.Etricc.Components.Interfaces.AgvInfo Egemin.Etricc.Components.Interfaces.IAgvService.GetAgvInfo(string agvId) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Egemin.Etricc.Components.Interfaces.AgvInfo GetAgvInfo(System.String)", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(agvId));
            beforeLogEntry.Log();
        }
        Egemin.Etricc.Components.Interfaces.AgvInfo result = ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).GetAgvInfo(agvId);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Egemin.Etricc.Components.Interfaces.AgvInfo GetAgvInfo(System.String)", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.AgvInfo> Egemin.Etricc.Components.Interfaces.IAgvService.GetDetailedAgvInfos(System.Collections.Generic.IEnumerable<string> agvIds) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[Egemin.Etricc.Components.Interfaces.AgvInfo] G" +
                    "etDetailedAgvInfos(System.Collections.Generic.IEnumerable`1[System.String])", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(agvIds));
            beforeLogEntry.Log();
        }
        System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.AgvInfo> result = ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).GetDetailedAgvInfos(agvIds);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[Egemin.Etricc.Components.Interfaces.AgvInfo] G" +
                    "etDetailedAgvInfos(System.Collections.Generic.IEnumerable`1[System.String])", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    Egemin.Etricc.Components.Interfaces.AgvSystemOverviewInfo Egemin.Etricc.Components.Interfaces.IAgvService.GetAgvSystemOverviewInfo(string agvId) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Egemin.Etricc.Components.Interfaces.AgvSystemOverviewInfo GetAgvSystemOverviewInf" +
                    "o(System.String)", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(agvId));
            beforeLogEntry.Log();
        }
        Egemin.Etricc.Components.Interfaces.AgvSystemOverviewInfo result = ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).GetAgvSystemOverviewInfo(agvId);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Egemin.Etricc.Components.Interfaces.AgvSystemOverviewInfo GetAgvSystemOverviewInf" +
                    "o(System.String)", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.AgvSystemOverviewInfo> Egemin.Etricc.Components.Interfaces.IAgvService.GetAgvSystemOverviewInfos() {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[Egemin.Etricc.Components.Interfaces.AgvSystemO" +
                    "verviewInfo] GetAgvSystemOverviewInfos()", base.MakeSecondPartOfLogMessage());
            beforeLogEntry.Log();
        }
        System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.AgvSystemOverviewInfo> result = ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).GetAgvSystemOverviewInfos();
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[Egemin.Etricc.Components.Interfaces.AgvSystemO" +
                    "verviewInfo] GetAgvSystemOverviewInfos()", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    Egemin.Etricc.Components.Interfaces.AgvSystemOverviewInfo Egemin.Etricc.Components.Interfaces.IAgvService.GetDetailedAgvSystemOverviewInfo(string agvId) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Egemin.Etricc.Components.Interfaces.AgvSystemOverviewInfo GetDetailedAgvSystemOve" +
                    "rviewInfo(System.String)", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(agvId));
            beforeLogEntry.Log();
        }
        Egemin.Etricc.Components.Interfaces.AgvSystemOverviewInfo result = ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).GetDetailedAgvSystemOverviewInfo(agvId);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Egemin.Etricc.Components.Interfaces.AgvSystemOverviewInfo GetDetailedAgvSystemOve" +
                    "rviewInfo(System.String)", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.AgvSystemOverviewInfo> Egemin.Etricc.Components.Interfaces.IAgvService.GetDetailedAgvSystemOverviewInfos() {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[Egemin.Etricc.Components.Interfaces.AgvSystemO" +
                    "verviewInfo] GetDetailedAgvSystemOverviewInfos()", base.MakeSecondPartOfLogMessage());
            beforeLogEntry.Log();
        }
        System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.AgvSystemOverviewInfo> result = ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).GetDetailedAgvSystemOverviewInfos();
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[Egemin.Etricc.Components.Interfaces.AgvSystemO" +
                    "verviewInfo] GetDetailedAgvSystemOverviewInfos()", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    void Egemin.Etricc.Components.Interfaces.IAgvService.Restart(System.Collections.Generic.IEnumerable<string> agvIds) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Void Restart(System.Collections.Generic.IEnumerable`1[System.String])", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(agvIds));
            beforeLogEntry.Log();
        }
        ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).Restart(agvIds);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Void Restart(System.Collections.Generic.IEnumerable`1[System.String])", base.MakeSecondPartOfLogMessage());
            afterLogEntry.Log();
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.IAgvService.Restart() {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Void Restart()", base.MakeSecondPartOfLogMessage());
            beforeLogEntry.Log();
        }
        ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).Restart();
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Void Restart()", base.MakeSecondPartOfLogMessage());
            afterLogEntry.Log();
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.IAgvService.Stop(System.Collections.Generic.IEnumerable<string> agvIds) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Void Stop(System.Collections.Generic.IEnumerable`1[System.String])", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(agvIds));
            beforeLogEntry.Log();
        }
        ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).Stop(agvIds);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Void Stop(System.Collections.Generic.IEnumerable`1[System.String])", base.MakeSecondPartOfLogMessage());
            afterLogEntry.Log();
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.IAgvService.Stop() {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Void Stop()", base.MakeSecondPartOfLogMessage());
            beforeLogEntry.Log();
        }
        ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).Stop();
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Void Stop()", base.MakeSecondPartOfLogMessage());
            afterLogEntry.Log();
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.IAgvService.Retire(System.Collections.Generic.IEnumerable<string> agvIds) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Void Retire(System.Collections.Generic.IEnumerable`1[System.String])", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(agvIds));
            beforeLogEntry.Log();
        }
        ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).Retire(agvIds);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Void Retire(System.Collections.Generic.IEnumerable`1[System.String])", base.MakeSecondPartOfLogMessage());
            afterLogEntry.Log();
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.IAgvService.Retire() {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Void Retire()", base.MakeSecondPartOfLogMessage());
            beforeLogEntry.Log();
        }
        ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).Retire();
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Void Retire()", base.MakeSecondPartOfLogMessage());
            afterLogEntry.Log();
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.IAgvService.Deploy(System.Collections.Generic.IEnumerable<string> agvIds) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Void Deploy(System.Collections.Generic.IEnumerable`1[System.String])", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(agvIds));
            beforeLogEntry.Log();
        }
        ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).Deploy(agvIds);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Void Deploy(System.Collections.Generic.IEnumerable`1[System.String])", base.MakeSecondPartOfLogMessage());
            afterLogEntry.Log();
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.IAgvService.Deploy() {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Void Deploy()", base.MakeSecondPartOfLogMessage());
            beforeLogEntry.Log();
        }
        ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).Deploy();
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Void Deploy()", base.MakeSecondPartOfLogMessage());
            afterLogEntry.Log();
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.IAgvService.Suspend(System.Collections.Generic.IEnumerable<string> agvIds) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Void Suspend(System.Collections.Generic.IEnumerable`1[System.String])", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(agvIds));
            beforeLogEntry.Log();
        }
        ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).Suspend(agvIds);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Void Suspend(System.Collections.Generic.IEnumerable`1[System.String])", base.MakeSecondPartOfLogMessage());
            afterLogEntry.Log();
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.IAgvService.Suspend() {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Void Suspend()", base.MakeSecondPartOfLogMessage());
            beforeLogEntry.Log();
        }
        ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).Suspend();
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Void Suspend()", base.MakeSecondPartOfLogMessage());
            afterLogEntry.Log();
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.IAgvService.Release(System.Collections.Generic.IEnumerable<string> agvIds) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Void Release(System.Collections.Generic.IEnumerable`1[System.String])", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(agvIds));
            beforeLogEntry.Log();
        }
        ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).Release(agvIds);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Void Release(System.Collections.Generic.IEnumerable`1[System.String])", base.MakeSecondPartOfLogMessage());
            afterLogEntry.Log();
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.IAgvService.Release() {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Void Release()", base.MakeSecondPartOfLogMessage());
            beforeLogEntry.Log();
        }
        ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).Release();
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Void Release()", base.MakeSecondPartOfLogMessage());
            afterLogEntry.Log();
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.IAgvService.SetMode(System.Collections.Generic.IEnumerable<string> agvIds, Egemin.Etricc.Components.Interfaces.MoverMode mode) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Void SetMode(System.Collections.Generic.IEnumerable`1[System.String], Egemin.Etri" +
                    "cc.Components.Interfaces.MoverMode)", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(agvIds), ", ", base.CallToString(mode));
            beforeLogEntry.Log();
        }
        ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).SetMode(agvIds, mode);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Void SetMode(System.Collections.Generic.IEnumerable`1[System.String], Egemin.Etri" +
                    "cc.Components.Interfaces.MoverMode)", base.MakeSecondPartOfLogMessage());
            afterLogEntry.Log();
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.IAgvService.CancelCurrentBatch() {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Void CancelCurrentBatch()", base.MakeSecondPartOfLogMessage());
            beforeLogEntry.Log();
        }
        ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).CancelCurrentBatch();
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Void CancelCurrentBatch()", base.MakeSecondPartOfLogMessage());
            afterLogEntry.Log();
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.IAgvService.CancelCurrentBatch(System.Collections.Generic.IEnumerable<string> agvIds) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Void CancelCurrentBatch(System.Collections.Generic.IEnumerable`1[System.String])", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(agvIds));
            beforeLogEntry.Log();
        }
        ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).CancelCurrentBatch(agvIds);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Void CancelCurrentBatch(System.Collections.Generic.IEnumerable`1[System.String])", base.MakeSecondPartOfLogMessage());
            afterLogEntry.Log();
        }
    }
    
    System.Collections.Generic.IList<string> Egemin.Etricc.Components.Interfaces.IAgvService.GetAgvIdsFromAgvType(string agvTypeId) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[System.String] GetAgvIdsFromAgvType(System.Str" +
                    "ing)", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(agvTypeId));
            beforeLogEntry.Log();
        }
        System.Collections.Generic.IList<string> result = ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).GetAgvIdsFromAgvType(agvTypeId);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[System.String] GetAgvIdsFromAgvType(System.Str" +
                    "ing)", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    void Egemin.Etricc.Components.Interfaces.IAgvService.StartDownload(System.Collections.Generic.IEnumerable<string> agvIds) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Void StartDownload(System.Collections.Generic.IEnumerable`1[System.String])", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(agvIds));
            beforeLogEntry.Log();
        }
        ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).StartDownload(agvIds);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Void StartDownload(System.Collections.Generic.IEnumerable`1[System.String])", base.MakeSecondPartOfLogMessage());
            afterLogEntry.Log();
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.IAgvService.StopDownload(System.Collections.Generic.IEnumerable<string> agvIds) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Void StopDownload(System.Collections.Generic.IEnumerable`1[System.String])", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(agvIds));
            beforeLogEntry.Log();
        }
        ((Egemin.Etricc.Components.Interfaces.IAgvService)(this.Wrappee)).StopDownload(agvIds);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Void StopDownload(System.Collections.Generic.IEnumerable`1[System.String])", base.MakeSecondPartOfLogMessage());
            afterLogEntry.Log();
        }
    }
}
