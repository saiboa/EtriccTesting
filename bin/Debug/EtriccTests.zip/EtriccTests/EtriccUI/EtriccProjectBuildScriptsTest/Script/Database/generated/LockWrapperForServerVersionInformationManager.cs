public class LockWrapperForServerVersionInformationManager : Egemin.Epia.Foundation.ComponentManagement.WrapperGeneration.LockWrapper<Egemin.Epia.Components.VersionInformation.ServerVersionInformationManager>, Egemin.Epia.Foundation.VersionInformation.Interfaces.IServerVersionInformation {
    
    public LockWrapperForServerVersionInformationManager(Egemin.Epia.Components.VersionInformation.ServerVersionInformationManager wrappee) : 
            base(wrappee) {
    }
    
    Egemin.Epia.Foundation.ServiceModel.Polling.ChangeSet<string, Egemin.Epia.Foundation.VersionInformation.AssemblyFileInformation> Egemin.Epia.Foundation.VersionInformation.Interfaces.IServerVersionInformation.PollAssemblyFileInformation(int version) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Epia.Foundation.VersionInformation.Interfaces.IServerVersionInformation)(this.Wrappee)).PollAssemblyFileInformation(version);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
}
