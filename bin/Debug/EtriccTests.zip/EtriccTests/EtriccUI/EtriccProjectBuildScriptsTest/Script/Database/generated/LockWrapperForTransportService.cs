public class LockWrapperForTransportService : Egemin.Epia.Foundation.ComponentManagement.WrapperGeneration.LockWrapper<Egemin.Etricc.Components.TransportService>, Egemin.Etricc.Components.Interfaces.ITransportService {
    
    public LockWrapperForTransportService(Egemin.Etricc.Components.TransportService wrappee) : 
            base(wrappee) {
    }
    
    System.Collections.Generic.IList<string> Egemin.Etricc.Components.Interfaces.ITransportService.GetTransportIds() {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.ITransportService)(this.Wrappee)).GetTransportIds();
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    string Egemin.Etricc.Components.Interfaces.ITransportService.VerifyTransport(Egemin.Etricc.Components.Interfaces.EditableTransportInfo transportInfo) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.ITransportService)(this.Wrappee)).VerifyTransport(transportInfo);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    string Egemin.Etricc.Components.Interfaces.ITransportService.EditTransport(Egemin.Etricc.Components.Interfaces.EditableTransportInfo transportInfo) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.ITransportService)(this.Wrappee)).EditTransport(transportInfo);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    string Egemin.Etricc.Components.Interfaces.ITransportService.CreateTransport(Egemin.Etricc.Components.Interfaces.EditableTransportInfo transportInfo) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.ITransportService)(this.Wrappee)).CreateTransport(transportInfo);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    bool Egemin.Etricc.Components.Interfaces.ITransportService.CreateBatchTransport(System.Collections.Generic.IEnumerable<Egemin.Etricc.Components.Interfaces.EditableTransportInfo> transportInfos) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.ITransportService)(this.Wrappee)).CreateBatchTransport(transportInfos);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.TransportInfo> Egemin.Etricc.Components.Interfaces.ITransportService.GetTransportInfos() {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.ITransportService)(this.Wrappee)).GetTransportInfos();
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.TransportInfo> Egemin.Etricc.Components.Interfaces.ITransportService.GetTransportInfos(System.Collections.Generic.IEnumerable<string> transportIds) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.ITransportService)(this.Wrappee)).GetTransportInfos(transportIds);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    Egemin.Etricc.Components.Interfaces.EditableTransportInfo Egemin.Etricc.Components.Interfaces.ITransportService.GetEditableTransportInfo(string transportId) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.ITransportService)(this.Wrappee)).GetEditableTransportInfo(transportId);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.TransportInfo> Egemin.Etricc.Components.Interfaces.ITransportService.GetDetailedTransportInfos(System.Collections.Generic.IEnumerable<string> transportIds) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.ITransportService)(this.Wrappee)).GetDetailedTransportInfos(transportIds);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    Egemin.Epia.Foundation.ServiceModel.Polling.ChangeSet<string, Egemin.Etricc.Components.Interfaces.TransportInfo> Egemin.Etricc.Components.Interfaces.ITransportService.Poll(int version) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.ITransportService)(this.Wrappee)).Poll(version);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.ITransportService.Cancel(System.Collections.Generic.IEnumerable<string> transportIds) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            ((Egemin.Etricc.Components.Interfaces.ITransportService)(this.Wrappee)).Cancel(transportIds);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.ITransportService.Suspend(System.Collections.Generic.IEnumerable<string> transportIds) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            ((Egemin.Etricc.Components.Interfaces.ITransportService)(this.Wrappee)).Suspend(transportIds);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.ITransportService.Release(System.Collections.Generic.IEnumerable<string> transportIds) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            ((Egemin.Etricc.Components.Interfaces.ITransportService)(this.Wrappee)).Release(transportIds);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.ITransportService.Finish(System.Collections.Generic.IEnumerable<string> transportIds) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            ((Egemin.Etricc.Components.Interfaces.ITransportService)(this.Wrappee)).Finish(transportIds);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.ITransportService.Resync(System.Collections.Generic.IEnumerable<string> transportIds) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            ((Egemin.Etricc.Components.Interfaces.ITransportService)(this.Wrappee)).Resync(transportIds);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.ITransportService.Retry(System.Collections.Generic.IEnumerable<string> transportIds) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            ((Egemin.Etricc.Components.Interfaces.ITransportService)(this.Wrappee)).Retry(transportIds);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.ITransportService.MakeObsolete(System.Collections.Generic.IEnumerable<string> transportIds) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            ((Egemin.Etricc.Components.Interfaces.ITransportService)(this.Wrappee)).MakeObsolete(transportIds);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.ITransportService.FlushAll() {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            ((Egemin.Etricc.Components.Interfaces.ITransportService)(this.Wrappee)).FlushAll();
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.ITransportService.Flush(System.Collections.Generic.IEnumerable<string> transportIds) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            ((Egemin.Etricc.Components.Interfaces.ITransportService)(this.Wrappee)).Flush(transportIds);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
}
