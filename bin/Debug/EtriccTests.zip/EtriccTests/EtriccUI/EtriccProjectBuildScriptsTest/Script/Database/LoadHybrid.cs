﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Egemin.EPIA.ComponentModel;
using Egemin.EPIA.WCS.Resources;
using Egemin.Etricc.Scripts.Core;

namespace Egemin.Etricc.Scripts.Database
{
    [Entry("LoadHybrid", "Main")]
    [Include(@"..\Core\Script.cs")]
    public class LoadHybrid : Script
    {
        public override void Run()
        {
            Project.LoadDbWithContextDefault();
        }
    } 
}