public class LockWrapperForLoadService : Egemin.Epia.Foundation.ComponentManagement.WrapperGeneration.LockWrapper<Egemin.Etricc.Components.LoadService>, Egemin.Etricc.Components.Interfaces.ILoadService {
    
    public LockWrapperForLoadService(Egemin.Etricc.Components.LoadService wrappee) : 
            base(wrappee) {
    }
    
    void Egemin.Etricc.Components.Interfaces.ILoadService.FlushAll() {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            ((Egemin.Etricc.Components.Interfaces.ILoadService)(this.Wrappee)).FlushAll();
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.ILoadService.Flush(System.Collections.Generic.IEnumerable<string> loadIds) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            ((Egemin.Etricc.Components.Interfaces.ILoadService)(this.Wrappee)).Flush(loadIds);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.ILoadService.Discard(System.Collections.Generic.IEnumerable<string> loadIds) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            ((Egemin.Etricc.Components.Interfaces.ILoadService)(this.Wrappee)).Discard(loadIds);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    System.Collections.Generic.IList<string> Egemin.Etricc.Components.Interfaces.ILoadService.GetLoadIds() {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.ILoadService)(this.Wrappee)).GetLoadIds();
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    Egemin.Etricc.Components.Interfaces.LoadInfo Egemin.Etricc.Components.Interfaces.ILoadService.GetLoadInfo(string loadId) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.ILoadService)(this.Wrappee)).GetLoadInfo(loadId);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.LoadInfo> Egemin.Etricc.Components.Interfaces.ILoadService.GetLoadInfos() {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.ILoadService)(this.Wrappee)).GetLoadInfos();
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.LoadInfo> Egemin.Etricc.Components.Interfaces.ILoadService.GetLoadInfos(System.Collections.Generic.IEnumerable<string> loadIds) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.ILoadService)(this.Wrappee)).GetLoadInfos(loadIds);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.LoadInfo> Egemin.Etricc.Components.Interfaces.ILoadService.GetDetailedLoadInfos(System.Collections.Generic.IEnumerable<string> loadIds) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.ILoadService)(this.Wrappee)).GetDetailedLoadInfos(loadIds);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.LoadSystemOverviewInfo> Egemin.Etricc.Components.Interfaces.ILoadService.GetLoadSystemOverviewInfos() {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.ILoadService)(this.Wrappee)).GetLoadSystemOverviewInfos();
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.LoadImage> Egemin.Etricc.Components.Interfaces.ILoadService.GetLoadImages() {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.ILoadService)(this.Wrappee)).GetLoadImages();
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    Egemin.Epia.Foundation.ServiceModel.Polling.ChangeSet<string, Egemin.Etricc.Components.Interfaces.LoadInfo> Egemin.Etricc.Components.Interfaces.ILoadService.Poll(int version) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.ILoadService)(this.Wrappee)).Poll(version);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
}
