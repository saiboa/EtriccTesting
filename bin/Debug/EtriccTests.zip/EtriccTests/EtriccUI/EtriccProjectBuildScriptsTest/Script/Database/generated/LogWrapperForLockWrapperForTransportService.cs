public class LogWrapperForLockWrapperForTransportService : Egemin.Epia.Foundation.ComponentManagement.WrapperGeneration.LogWrapper<Egemin.Epia.Foundation.ComponentManagement.DynamicWrappers.LockWrapperForTransportService>, Egemin.Etricc.Components.Interfaces.ITransportService {
    
    public LogWrapperForLockWrapperForTransportService(Egemin.Epia.Foundation.ComponentManagement.DynamicWrappers.LockWrapperForTransportService wrappee) : 
            base(wrappee) {
    }
    
    System.Collections.Generic.IList<string> Egemin.Etricc.Components.Interfaces.ITransportService.GetTransportIds() {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[System.String] GetTransportIds()", base.MakeSecondPartOfLogMessage());
            beforeLogEntry.Log();
        }
        System.Collections.Generic.IList<string> result = ((Egemin.Etricc.Components.Interfaces.ITransportService)(this.Wrappee)).GetTransportIds();
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[System.String] GetTransportIds()", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    string Egemin.Etricc.Components.Interfaces.ITransportService.VerifyTransport(Egemin.Etricc.Components.Interfaces.EditableTransportInfo transportInfo) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "System.String VerifyTransport(Egemin.Etricc.Components.Interfaces.EditableTranspo" +
                    "rtInfo)", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(transportInfo));
            beforeLogEntry.Log();
        }
        string result = ((Egemin.Etricc.Components.Interfaces.ITransportService)(this.Wrappee)).VerifyTransport(transportInfo);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "System.String VerifyTransport(Egemin.Etricc.Components.Interfaces.EditableTranspo" +
                    "rtInfo)", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    string Egemin.Etricc.Components.Interfaces.ITransportService.EditTransport(Egemin.Etricc.Components.Interfaces.EditableTransportInfo transportInfo) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "System.String EditTransport(Egemin.Etricc.Components.Interfaces.EditableTransport" +
                    "Info)", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(transportInfo));
            beforeLogEntry.Log();
        }
        string result = ((Egemin.Etricc.Components.Interfaces.ITransportService)(this.Wrappee)).EditTransport(transportInfo);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "System.String EditTransport(Egemin.Etricc.Components.Interfaces.EditableTransport" +
                    "Info)", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    string Egemin.Etricc.Components.Interfaces.ITransportService.CreateTransport(Egemin.Etricc.Components.Interfaces.EditableTransportInfo transportInfo) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "System.String CreateTransport(Egemin.Etricc.Components.Interfaces.EditableTranspo" +
                    "rtInfo)", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(transportInfo));
            beforeLogEntry.Log();
        }
        string result = ((Egemin.Etricc.Components.Interfaces.ITransportService)(this.Wrappee)).CreateTransport(transportInfo);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "System.String CreateTransport(Egemin.Etricc.Components.Interfaces.EditableTranspo" +
                    "rtInfo)", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    bool Egemin.Etricc.Components.Interfaces.ITransportService.CreateBatchTransport(System.Collections.Generic.IEnumerable<Egemin.Etricc.Components.Interfaces.EditableTransportInfo> transportInfos) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Boolean CreateBatchTransport(System.Collections.Generic.IEnumerable`1[Egemin.Etri" +
                    "cc.Components.Interfaces.EditableTransportInfo])", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(transportInfos));
            beforeLogEntry.Log();
        }
        bool result = ((Egemin.Etricc.Components.Interfaces.ITransportService)(this.Wrappee)).CreateBatchTransport(transportInfos);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Boolean CreateBatchTransport(System.Collections.Generic.IEnumerable`1[Egemin.Etri" +
                    "cc.Components.Interfaces.EditableTransportInfo])", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.TransportInfo> Egemin.Etricc.Components.Interfaces.ITransportService.GetTransportInfos() {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[Egemin.Etricc.Components.Interfaces.TransportI" +
                    "nfo] GetTransportInfos()", base.MakeSecondPartOfLogMessage());
            beforeLogEntry.Log();
        }
        System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.TransportInfo> result = ((Egemin.Etricc.Components.Interfaces.ITransportService)(this.Wrappee)).GetTransportInfos();
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[Egemin.Etricc.Components.Interfaces.TransportI" +
                    "nfo] GetTransportInfos()", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.TransportInfo> Egemin.Etricc.Components.Interfaces.ITransportService.GetTransportInfos(System.Collections.Generic.IEnumerable<string> transportIds) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[Egemin.Etricc.Components.Interfaces.TransportI" +
                    "nfo] GetTransportInfos(System.Collections.Generic.IEnumerable`1[System.String])", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(transportIds));
            beforeLogEntry.Log();
        }
        System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.TransportInfo> result = ((Egemin.Etricc.Components.Interfaces.ITransportService)(this.Wrappee)).GetTransportInfos(transportIds);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[Egemin.Etricc.Components.Interfaces.TransportI" +
                    "nfo] GetTransportInfos(System.Collections.Generic.IEnumerable`1[System.String])", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    Egemin.Etricc.Components.Interfaces.EditableTransportInfo Egemin.Etricc.Components.Interfaces.ITransportService.GetEditableTransportInfo(string transportId) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Egemin.Etricc.Components.Interfaces.EditableTransportInfo GetEditableTransportInf" +
                    "o(System.String)", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(transportId));
            beforeLogEntry.Log();
        }
        Egemin.Etricc.Components.Interfaces.EditableTransportInfo result = ((Egemin.Etricc.Components.Interfaces.ITransportService)(this.Wrappee)).GetEditableTransportInfo(transportId);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Egemin.Etricc.Components.Interfaces.EditableTransportInfo GetEditableTransportInf" +
                    "o(System.String)", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.TransportInfo> Egemin.Etricc.Components.Interfaces.ITransportService.GetDetailedTransportInfos(System.Collections.Generic.IEnumerable<string> transportIds) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[Egemin.Etricc.Components.Interfaces.TransportI" +
                    "nfo] GetDetailedTransportInfos(System.Collections.Generic.IEnumerable`1[System.S" +
                    "tring])", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(transportIds));
            beforeLogEntry.Log();
        }
        System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.TransportInfo> result = ((Egemin.Etricc.Components.Interfaces.ITransportService)(this.Wrappee)).GetDetailedTransportInfos(transportIds);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[Egemin.Etricc.Components.Interfaces.TransportI" +
                    "nfo] GetDetailedTransportInfos(System.Collections.Generic.IEnumerable`1[System.S" +
                    "tring])", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    Egemin.Epia.Foundation.ServiceModel.Polling.ChangeSet<string, Egemin.Etricc.Components.Interfaces.TransportInfo> Egemin.Etricc.Components.Interfaces.ITransportService.Poll(int version) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Egemin.Epia.Foundation.ServiceModel.Polling.ChangeSet`2[System.String,Egemin.Etri" +
                    "cc.Components.Interfaces.TransportInfo] Poll(Int32)", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(version));
            beforeLogEntry.Log();
        }
        Egemin.Epia.Foundation.ServiceModel.Polling.ChangeSet<string, Egemin.Etricc.Components.Interfaces.TransportInfo> result = ((Egemin.Etricc.Components.Interfaces.ITransportService)(this.Wrappee)).Poll(version);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Egemin.Epia.Foundation.ServiceModel.Polling.ChangeSet`2[System.String,Egemin.Etri" +
                    "cc.Components.Interfaces.TransportInfo] Poll(Int32)", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    void Egemin.Etricc.Components.Interfaces.ITransportService.Cancel(System.Collections.Generic.IEnumerable<string> transportIds) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Void Cancel(System.Collections.Generic.IEnumerable`1[System.String])", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(transportIds));
            beforeLogEntry.Log();
        }
        ((Egemin.Etricc.Components.Interfaces.ITransportService)(this.Wrappee)).Cancel(transportIds);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Void Cancel(System.Collections.Generic.IEnumerable`1[System.String])", base.MakeSecondPartOfLogMessage());
            afterLogEntry.Log();
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.ITransportService.Suspend(System.Collections.Generic.IEnumerable<string> transportIds) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Void Suspend(System.Collections.Generic.IEnumerable`1[System.String])", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(transportIds));
            beforeLogEntry.Log();
        }
        ((Egemin.Etricc.Components.Interfaces.ITransportService)(this.Wrappee)).Suspend(transportIds);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Void Suspend(System.Collections.Generic.IEnumerable`1[System.String])", base.MakeSecondPartOfLogMessage());
            afterLogEntry.Log();
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.ITransportService.Release(System.Collections.Generic.IEnumerable<string> transportIds) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Void Release(System.Collections.Generic.IEnumerable`1[System.String])", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(transportIds));
            beforeLogEntry.Log();
        }
        ((Egemin.Etricc.Components.Interfaces.ITransportService)(this.Wrappee)).Release(transportIds);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Void Release(System.Collections.Generic.IEnumerable`1[System.String])", base.MakeSecondPartOfLogMessage());
            afterLogEntry.Log();
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.ITransportService.Finish(System.Collections.Generic.IEnumerable<string> transportIds) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Void Finish(System.Collections.Generic.IEnumerable`1[System.String])", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(transportIds));
            beforeLogEntry.Log();
        }
        ((Egemin.Etricc.Components.Interfaces.ITransportService)(this.Wrappee)).Finish(transportIds);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Void Finish(System.Collections.Generic.IEnumerable`1[System.String])", base.MakeSecondPartOfLogMessage());
            afterLogEntry.Log();
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.ITransportService.Resync(System.Collections.Generic.IEnumerable<string> transportIds) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Void Resync(System.Collections.Generic.IEnumerable`1[System.String])", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(transportIds));
            beforeLogEntry.Log();
        }
        ((Egemin.Etricc.Components.Interfaces.ITransportService)(this.Wrappee)).Resync(transportIds);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Void Resync(System.Collections.Generic.IEnumerable`1[System.String])", base.MakeSecondPartOfLogMessage());
            afterLogEntry.Log();
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.ITransportService.Retry(System.Collections.Generic.IEnumerable<string> transportIds) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Void Retry(System.Collections.Generic.IEnumerable`1[System.String])", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(transportIds));
            beforeLogEntry.Log();
        }
        ((Egemin.Etricc.Components.Interfaces.ITransportService)(this.Wrappee)).Retry(transportIds);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Void Retry(System.Collections.Generic.IEnumerable`1[System.String])", base.MakeSecondPartOfLogMessage());
            afterLogEntry.Log();
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.ITransportService.MakeObsolete(System.Collections.Generic.IEnumerable<string> transportIds) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Void MakeObsolete(System.Collections.Generic.IEnumerable`1[System.String])", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(transportIds));
            beforeLogEntry.Log();
        }
        ((Egemin.Etricc.Components.Interfaces.ITransportService)(this.Wrappee)).MakeObsolete(transportIds);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Void MakeObsolete(System.Collections.Generic.IEnumerable`1[System.String])", base.MakeSecondPartOfLogMessage());
            afterLogEntry.Log();
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.ITransportService.FlushAll() {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Void FlushAll()", base.MakeSecondPartOfLogMessage());
            beforeLogEntry.Log();
        }
        ((Egemin.Etricc.Components.Interfaces.ITransportService)(this.Wrappee)).FlushAll();
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Void FlushAll()", base.MakeSecondPartOfLogMessage());
            afterLogEntry.Log();
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.ITransportService.Flush(System.Collections.Generic.IEnumerable<string> transportIds) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Void Flush(System.Collections.Generic.IEnumerable`1[System.String])", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(transportIds));
            beforeLogEntry.Log();
        }
        ((Egemin.Etricc.Components.Interfaces.ITransportService)(this.Wrappee)).Flush(transportIds);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Void Flush(System.Collections.Generic.IEnumerable`1[System.String])", base.MakeSecondPartOfLogMessage());
            afterLogEntry.Log();
        }
    }
}
