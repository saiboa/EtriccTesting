public class LogWrapperForLockWrapperForWeekPlanService : Egemin.Epia.Foundation.ComponentManagement.WrapperGeneration.LogWrapper<Egemin.Epia.Foundation.ComponentManagement.DynamicWrappers.LockWrapperForWeekPlanService>, Egemin.Etricc.Components.Interfaces.IWeekPlanService {
    
    public LogWrapperForLockWrapperForWeekPlanService(Egemin.Epia.Foundation.ComponentManagement.DynamicWrappers.LockWrapperForWeekPlanService wrappee) : 
            base(wrappee) {
    }
    
    string Egemin.Etricc.Components.Interfaces.IWeekPlanService.CreateWeekPlan(string agvId, string originatorId, string weekPlanId, System.DayOfWeek day, int startHour, int startMinute, int duration, string arguments, bool enabled) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "System.String CreateWeekPlan(System.String, System.String, System.String, System." +
                    "DayOfWeek, Int32, Int32, Int32, System.String, Boolean)", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(agvId), ", ", base.CallToString(originatorId), ", ", base.CallToString(weekPlanId), ", ", base.CallToString(day), ", ", base.CallToString(startHour), ", ", base.CallToString(startMinute), ", ", base.CallToString(duration), ", ", base.CallToString(arguments), ", ", base.CallToString(enabled));
            beforeLogEntry.Log();
        }
        string result = ((Egemin.Etricc.Components.Interfaces.IWeekPlanService)(this.Wrappee)).CreateWeekPlan(agvId, originatorId, weekPlanId, day, startHour, startMinute, duration, arguments, enabled);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "System.String CreateWeekPlan(System.String, System.String, System.String, System." +
                    "DayOfWeek, Int32, Int32, Int32, System.String, Boolean)", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    void Egemin.Etricc.Components.Interfaces.IWeekPlanService.Delete(string agvId, System.Collections.Generic.IEnumerable<string> weekplanIds) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Void Delete(System.String, System.Collections.Generic.IEnumerable`1[System.String" +
                    "])", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(agvId), ", ", base.CallToString(weekplanIds));
            beforeLogEntry.Log();
        }
        ((Egemin.Etricc.Components.Interfaces.IWeekPlanService)(this.Wrappee)).Delete(agvId, weekplanIds);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Void Delete(System.String, System.Collections.Generic.IEnumerable`1[System.String" +
                    "])", base.MakeSecondPartOfLogMessage());
            afterLogEntry.Log();
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.IWeekPlanService.Disable(string agvId, System.Collections.Generic.IEnumerable<string> weekplanIds) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Void Disable(System.String, System.Collections.Generic.IEnumerable`1[System.Strin" +
                    "g])", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(agvId), ", ", base.CallToString(weekplanIds));
            beforeLogEntry.Log();
        }
        ((Egemin.Etricc.Components.Interfaces.IWeekPlanService)(this.Wrappee)).Disable(agvId, weekplanIds);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Void Disable(System.String, System.Collections.Generic.IEnumerable`1[System.Strin" +
                    "g])", base.MakeSecondPartOfLogMessage());
            afterLogEntry.Log();
        }
    }
    
    string Egemin.Etricc.Components.Interfaces.IWeekPlanService.EditWeekPlan(string agvId, string originatorId, string weekPlanId, System.DayOfWeek day, int startHour, int startMinute, int duration, string arguments, bool enabled) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "System.String EditWeekPlan(System.String, System.String, System.String, System.Da" +
                    "yOfWeek, Int32, Int32, Int32, System.String, Boolean)", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(agvId), ", ", base.CallToString(originatorId), ", ", base.CallToString(weekPlanId), ", ", base.CallToString(day), ", ", base.CallToString(startHour), ", ", base.CallToString(startMinute), ", ", base.CallToString(duration), ", ", base.CallToString(arguments), ", ", base.CallToString(enabled));
            beforeLogEntry.Log();
        }
        string result = ((Egemin.Etricc.Components.Interfaces.IWeekPlanService)(this.Wrappee)).EditWeekPlan(agvId, originatorId, weekPlanId, day, startHour, startMinute, duration, arguments, enabled);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "System.String EditWeekPlan(System.String, System.String, System.String, System.Da" +
                    "yOfWeek, Int32, Int32, Int32, System.String, Boolean)", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    void Egemin.Etricc.Components.Interfaces.IWeekPlanService.Enable(string agvId, System.Collections.Generic.IEnumerable<string> weekplanIds) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Void Enable(System.String, System.Collections.Generic.IEnumerable`1[System.String" +
                    "])", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(agvId), ", ", base.CallToString(weekplanIds));
            beforeLogEntry.Log();
        }
        ((Egemin.Etricc.Components.Interfaces.IWeekPlanService)(this.Wrappee)).Enable(agvId, weekplanIds);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Void Enable(System.String, System.Collections.Generic.IEnumerable`1[System.String" +
                    "])", base.MakeSecondPartOfLogMessage());
            afterLogEntry.Log();
        }
    }
    
    System.Collections.Generic.IDictionary<string, System.Collections.Generic.List<string>> Egemin.Etricc.Components.Interfaces.IWeekPlanService.GetWeekPlanIds() {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IDictionary`2[System.String,System.Collections.Generic" +
                    ".List`1[System.String]] GetWeekPlanIds()", base.MakeSecondPartOfLogMessage());
            beforeLogEntry.Log();
        }
        System.Collections.Generic.IDictionary<string, System.Collections.Generic.List<string>> result = ((Egemin.Etricc.Components.Interfaces.IWeekPlanService)(this.Wrappee)).GetWeekPlanIds();
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IDictionary`2[System.String,System.Collections.Generic" +
                    ".List`1[System.String]] GetWeekPlanIds()", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    System.Collections.Generic.IDictionary<string, System.Collections.Generic.List<string>> Egemin.Etricc.Components.Interfaces.IWeekPlanService.GetWeekPlanIdsForAgvs(System.Collections.Generic.IEnumerable<string> agvIds) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IDictionary`2[System.String,System.Collections.Generic" +
                    ".List`1[System.String]] GetWeekPlanIdsForAgvs(System.Collections.Generic.IEnumer" +
                    "able`1[System.String])", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(agvIds));
            beforeLogEntry.Log();
        }
        System.Collections.Generic.IDictionary<string, System.Collections.Generic.List<string>> result = ((Egemin.Etricc.Components.Interfaces.IWeekPlanService)(this.Wrappee)).GetWeekPlanIdsForAgvs(agvIds);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IDictionary`2[System.String,System.Collections.Generic" +
                    ".List`1[System.String]] GetWeekPlanIdsForAgvs(System.Collections.Generic.IEnumer" +
                    "able`1[System.String])", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    System.Collections.Generic.IDictionary<string, System.Collections.Generic.List<Egemin.Etricc.Components.Interfaces.WeekPlanInfo>> Egemin.Etricc.Components.Interfaces.IWeekPlanService.GetWeekPlanInfos() {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IDictionary`2[System.String,System.Collections.Generic" +
                    ".List`1[Egemin.Etricc.Components.Interfaces.WeekPlanInfo]] GetWeekPlanInfos()", base.MakeSecondPartOfLogMessage());
            beforeLogEntry.Log();
        }
        System.Collections.Generic.IDictionary<string, System.Collections.Generic.List<Egemin.Etricc.Components.Interfaces.WeekPlanInfo>> result = ((Egemin.Etricc.Components.Interfaces.IWeekPlanService)(this.Wrappee)).GetWeekPlanInfos();
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IDictionary`2[System.String,System.Collections.Generic" +
                    ".List`1[Egemin.Etricc.Components.Interfaces.WeekPlanInfo]] GetWeekPlanInfos()", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    System.Collections.Generic.IDictionary<string, System.Collections.Generic.List<Egemin.Etricc.Components.Interfaces.WeekPlanInfo>> Egemin.Etricc.Components.Interfaces.IWeekPlanService.GetWeekPlanInfosForAgvs(System.Collections.Generic.IEnumerable<string> agvIds) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IDictionary`2[System.String,System.Collections.Generic" +
                    ".List`1[Egemin.Etricc.Components.Interfaces.WeekPlanInfo]] GetWeekPlanInfosForAg" +
                    "vs(System.Collections.Generic.IEnumerable`1[System.String])", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(agvIds));
            beforeLogEntry.Log();
        }
        System.Collections.Generic.IDictionary<string, System.Collections.Generic.List<Egemin.Etricc.Components.Interfaces.WeekPlanInfo>> result = ((Egemin.Etricc.Components.Interfaces.IWeekPlanService)(this.Wrappee)).GetWeekPlanInfosForAgvs(agvIds);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IDictionary`2[System.String,System.Collections.Generic" +
                    ".List`1[Egemin.Etricc.Components.Interfaces.WeekPlanInfo]] GetWeekPlanInfosForAg" +
                    "vs(System.Collections.Generic.IEnumerable`1[System.String])", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    System.Collections.Generic.IDictionary<string, Egemin.Epia.Foundation.ServiceModel.Polling.ChangeSet<string, Egemin.Etricc.Components.Interfaces.WeekPlanInfo>> Egemin.Etricc.Components.Interfaces.IWeekPlanService.Poll(System.Collections.Generic.IEnumerable<Egemin.Etricc.Components.Interfaces.VersionedId> versionedAgvIds) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), @"System.Collections.Generic.IDictionary`2[System.String,Egemin.Epia.Foundation.ServiceModel.Polling.ChangeSet`2[System.String,Egemin.Etricc.Components.Interfaces.WeekPlanInfo]] Poll(System.Collections.Generic.IEnumerable`1[Egemin.Etricc.Components.Interfaces.VersionedId])", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(versionedAgvIds));
            beforeLogEntry.Log();
        }
        System.Collections.Generic.IDictionary<string, Egemin.Epia.Foundation.ServiceModel.Polling.ChangeSet<string, Egemin.Etricc.Components.Interfaces.WeekPlanInfo>> result = ((Egemin.Etricc.Components.Interfaces.IWeekPlanService)(this.Wrappee)).Poll(versionedAgvIds);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), @"System.Collections.Generic.IDictionary`2[System.String,Egemin.Epia.Foundation.ServiceModel.Polling.ChangeSet`2[System.String,Egemin.Etricc.Components.Interfaces.WeekPlanInfo]] Poll(System.Collections.Generic.IEnumerable`1[Egemin.Etricc.Components.Interfaces.VersionedId])", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
}
