public class LogWrapperForLockWrapperForLocationService : Egemin.Epia.Foundation.ComponentManagement.WrapperGeneration.LogWrapper<Egemin.Epia.Foundation.ComponentManagement.DynamicWrappers.LockWrapperForLocationService>, Egemin.Etricc.Components.Interfaces.ILocationService {
    
    public LogWrapperForLockWrapperForLocationService(Egemin.Epia.Foundation.ComponentManagement.DynamicWrappers.LockWrapperForLocationService wrappee) : 
            base(wrappee) {
    }
    
    System.Collections.Generic.IList<string> Egemin.Etricc.Components.Interfaces.ILocationService.GetLocationIds() {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[System.String] GetLocationIds()", base.MakeSecondPartOfLogMessage());
            beforeLogEntry.Log();
        }
        System.Collections.Generic.IList<string> result = ((Egemin.Etricc.Components.Interfaces.ILocationService)(this.Wrappee)).GetLocationIds();
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[System.String] GetLocationIds()", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    System.Collections.Generic.IList<string> Egemin.Etricc.Components.Interfaces.ILocationService.GetGroupIds() {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[System.String] GetGroupIds()", base.MakeSecondPartOfLogMessage());
            beforeLogEntry.Log();
        }
        System.Collections.Generic.IList<string> result = ((Egemin.Etricc.Components.Interfaces.ILocationService)(this.Wrappee)).GetGroupIds();
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[System.String] GetGroupIds()", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    Egemin.Etricc.Components.Interfaces.LocationInfo Egemin.Etricc.Components.Interfaces.ILocationService.GetLocationInfo(string locationId) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Egemin.Etricc.Components.Interfaces.LocationInfo GetLocationInfo(System.String)", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(locationId));
            beforeLogEntry.Log();
        }
        Egemin.Etricc.Components.Interfaces.LocationInfo result = ((Egemin.Etricc.Components.Interfaces.ILocationService)(this.Wrappee)).GetLocationInfo(locationId);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Egemin.Etricc.Components.Interfaces.LocationInfo GetLocationInfo(System.String)", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.LocationInfo> Egemin.Etricc.Components.Interfaces.ILocationService.GetLocationInfos() {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[Egemin.Etricc.Components.Interfaces.LocationIn" +
                    "fo] GetLocationInfos()", base.MakeSecondPartOfLogMessage());
            beforeLogEntry.Log();
        }
        System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.LocationInfo> result = ((Egemin.Etricc.Components.Interfaces.ILocationService)(this.Wrappee)).GetLocationInfos();
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[Egemin.Etricc.Components.Interfaces.LocationIn" +
                    "fo] GetLocationInfos()", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.LocationDefInfo> Egemin.Etricc.Components.Interfaces.ILocationService.GetLocationDefInfos() {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[Egemin.Etricc.Components.Interfaces.LocationDe" +
                    "fInfo] GetLocationDefInfos()", base.MakeSecondPartOfLogMessage());
            beforeLogEntry.Log();
        }
        System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.LocationDefInfo> result = ((Egemin.Etricc.Components.Interfaces.ILocationService)(this.Wrappee)).GetLocationDefInfos();
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[Egemin.Etricc.Components.Interfaces.LocationDe" +
                    "fInfo] GetLocationDefInfos()", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.LocationInfo> Egemin.Etricc.Components.Interfaces.ILocationService.GetLocationInfos(System.Collections.Generic.IEnumerable<string> locationIds) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[Egemin.Etricc.Components.Interfaces.LocationIn" +
                    "fo] GetLocationInfos(System.Collections.Generic.IEnumerable`1[System.String])", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(locationIds));
            beforeLogEntry.Log();
        }
        System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.LocationInfo> result = ((Egemin.Etricc.Components.Interfaces.ILocationService)(this.Wrappee)).GetLocationInfos(locationIds);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[Egemin.Etricc.Components.Interfaces.LocationIn" +
                    "fo] GetLocationInfos(System.Collections.Generic.IEnumerable`1[System.String])", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.LocationInfo> Egemin.Etricc.Components.Interfaces.ILocationService.GetDetailedLocationInfos(System.Collections.Generic.IEnumerable<string> locationIds) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[Egemin.Etricc.Components.Interfaces.LocationIn" +
                    "fo] GetDetailedLocationInfos(System.Collections.Generic.IEnumerable`1[System.Str" +
                    "ing])", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(locationIds));
            beforeLogEntry.Log();
        }
        System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.LocationInfo> result = ((Egemin.Etricc.Components.Interfaces.ILocationService)(this.Wrappee)).GetDetailedLocationInfos(locationIds);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[Egemin.Etricc.Components.Interfaces.LocationIn" +
                    "fo] GetDetailedLocationInfos(System.Collections.Generic.IEnumerable`1[System.Str" +
                    "ing])", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    Egemin.Epia.Foundation.ServiceModel.Polling.ChangeSet<string, Egemin.Etricc.Components.Interfaces.LocationInfo> Egemin.Etricc.Components.Interfaces.ILocationService.Poll(int version) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Egemin.Epia.Foundation.ServiceModel.Polling.ChangeSet`2[System.String,Egemin.Etri" +
                    "cc.Components.Interfaces.LocationInfo] Poll(Int32)", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(version));
            beforeLogEntry.Log();
        }
        Egemin.Epia.Foundation.ServiceModel.Polling.ChangeSet<string, Egemin.Etricc.Components.Interfaces.LocationInfo> result = ((Egemin.Etricc.Components.Interfaces.ILocationService)(this.Wrappee)).Poll(version);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Egemin.Epia.Foundation.ServiceModel.Polling.ChangeSet`2[System.String,Egemin.Etri" +
                    "cc.Components.Interfaces.LocationInfo] Poll(Int32)", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    void Egemin.Etricc.Components.Interfaces.ILocationService.SetMode(System.Collections.Generic.IEnumerable<string> locationIds, Egemin.Etricc.Components.Interfaces.LocationMode mode) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Void SetMode(System.Collections.Generic.IEnumerable`1[System.String], Egemin.Etri" +
                    "cc.Components.Interfaces.LocationMode)", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(locationIds), ", ", base.CallToString(mode));
            beforeLogEntry.Log();
        }
        ((Egemin.Etricc.Components.Interfaces.ILocationService)(this.Wrappee)).SetMode(locationIds, mode);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Void SetMode(System.Collections.Generic.IEnumerable`1[System.String], Egemin.Etri" +
                    "cc.Components.Interfaces.LocationMode)", base.MakeSecondPartOfLogMessage());
            afterLogEntry.Log();
        }
    }
}
