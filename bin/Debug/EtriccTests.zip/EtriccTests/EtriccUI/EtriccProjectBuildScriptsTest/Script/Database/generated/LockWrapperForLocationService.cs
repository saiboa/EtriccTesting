public class LockWrapperForLocationService : Egemin.Epia.Foundation.ComponentManagement.WrapperGeneration.LockWrapper<Egemin.Etricc.Components.LocationService>, Egemin.Etricc.Components.Interfaces.ILocationService {
    
    public LockWrapperForLocationService(Egemin.Etricc.Components.LocationService wrappee) : 
            base(wrappee) {
    }
    
    System.Collections.Generic.IList<string> Egemin.Etricc.Components.Interfaces.ILocationService.GetLocationIds() {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.ILocationService)(this.Wrappee)).GetLocationIds();
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    System.Collections.Generic.IList<string> Egemin.Etricc.Components.Interfaces.ILocationService.GetGroupIds() {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.ILocationService)(this.Wrappee)).GetGroupIds();
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    Egemin.Etricc.Components.Interfaces.LocationInfo Egemin.Etricc.Components.Interfaces.ILocationService.GetLocationInfo(string locationId) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.ILocationService)(this.Wrappee)).GetLocationInfo(locationId);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.LocationInfo> Egemin.Etricc.Components.Interfaces.ILocationService.GetLocationInfos() {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.ILocationService)(this.Wrappee)).GetLocationInfos();
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.LocationDefInfo> Egemin.Etricc.Components.Interfaces.ILocationService.GetLocationDefInfos() {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.ILocationService)(this.Wrappee)).GetLocationDefInfos();
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.LocationInfo> Egemin.Etricc.Components.Interfaces.ILocationService.GetLocationInfos(System.Collections.Generic.IEnumerable<string> locationIds) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.ILocationService)(this.Wrappee)).GetLocationInfos(locationIds);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.LocationInfo> Egemin.Etricc.Components.Interfaces.ILocationService.GetDetailedLocationInfos(System.Collections.Generic.IEnumerable<string> locationIds) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.ILocationService)(this.Wrappee)).GetDetailedLocationInfos(locationIds);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    Egemin.Epia.Foundation.ServiceModel.Polling.ChangeSet<string, Egemin.Etricc.Components.Interfaces.LocationInfo> Egemin.Etricc.Components.Interfaces.ILocationService.Poll(int version) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.ILocationService)(this.Wrappee)).Poll(version);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.ILocationService.SetMode(System.Collections.Generic.IEnumerable<string> locationIds, Egemin.Etricc.Components.Interfaces.LocationMode mode) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            ((Egemin.Etricc.Components.Interfaces.ILocationService)(this.Wrappee)).SetMode(locationIds, mode);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
}
