public class LogWrapperForLockWrapperForFieldPortService : Egemin.Epia.Foundation.ComponentManagement.WrapperGeneration.LogWrapper<Egemin.Epia.Foundation.ComponentManagement.DynamicWrappers.LockWrapperForFieldPortService>, Egemin.Etricc.Components.Interfaces.IFieldPortService {
    
    public LogWrapperForLockWrapperForFieldPortService(Egemin.Epia.Foundation.ComponentManagement.DynamicWrappers.LockWrapperForFieldPortService wrappee) : 
            base(wrappee) {
    }
    
    System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.FieldPortInfo> Egemin.Etricc.Components.Interfaces.IFieldPortService.GetFieldPortInfos() {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[Egemin.Etricc.Components.Interfaces.FieldPortI" +
                    "nfo] GetFieldPortInfos()", base.MakeSecondPartOfLogMessage());
            beforeLogEntry.Log();
        }
        System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.FieldPortInfo> result = ((Egemin.Etricc.Components.Interfaces.IFieldPortService)(this.Wrappee)).GetFieldPortInfos();
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[Egemin.Etricc.Components.Interfaces.FieldPortI" +
                    "nfo] GetFieldPortInfos()", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    Egemin.Epia.Foundation.ServiceModel.Polling.ChangeSet<string, Egemin.Etricc.Components.Interfaces.FieldPortInfo> Egemin.Etricc.Components.Interfaces.IFieldPortService.Poll(int version) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Egemin.Epia.Foundation.ServiceModel.Polling.ChangeSet`2[System.String,Egemin.Etri" +
                    "cc.Components.Interfaces.FieldPortInfo] Poll(Int32)", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(version));
            beforeLogEntry.Log();
        }
        Egemin.Epia.Foundation.ServiceModel.Polling.ChangeSet<string, Egemin.Etricc.Components.Interfaces.FieldPortInfo> result = ((Egemin.Etricc.Components.Interfaces.IFieldPortService)(this.Wrappee)).Poll(version);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Egemin.Epia.Foundation.ServiceModel.Polling.ChangeSet`2[System.String,Egemin.Etri" +
                    "cc.Components.Interfaces.FieldPortInfo] Poll(Int32)", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
}
