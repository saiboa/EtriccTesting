public class LogWrapperForLockWrapperForFieldPointService : Egemin.Epia.Foundation.ComponentManagement.WrapperGeneration.LogWrapper<Egemin.Epia.Foundation.ComponentManagement.DynamicWrappers.LockWrapperForFieldPointService>, Egemin.Etricc.Components.Interfaces.IFieldPointService {
    
    public LogWrapperForLockWrapperForFieldPointService(Egemin.Epia.Foundation.ComponentManagement.DynamicWrappers.LockWrapperForFieldPointService wrappee) : 
            base(wrappee) {
    }
    
    System.Collections.Generic.IDictionary<string, System.Collections.Generic.List<Egemin.Etricc.Components.Interfaces.FieldPointInfo>> Egemin.Etricc.Components.Interfaces.IFieldPointService.GetFieldPointInfosForPointCollections(System.Collections.Generic.IEnumerable<string> pointCollectionIds) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IDictionary`2[System.String,System.Collections.Generic" +
                    ".List`1[Egemin.Etricc.Components.Interfaces.FieldPointInfo]] GetFieldPointInfosF" +
                    "orPointCollections(System.Collections.Generic.IEnumerable`1[System.String])", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(pointCollectionIds));
            beforeLogEntry.Log();
        }
        System.Collections.Generic.IDictionary<string, System.Collections.Generic.List<Egemin.Etricc.Components.Interfaces.FieldPointInfo>> result = ((Egemin.Etricc.Components.Interfaces.IFieldPointService)(this.Wrappee)).GetFieldPointInfosForPointCollections(pointCollectionIds);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IDictionary`2[System.String,System.Collections.Generic" +
                    ".List`1[Egemin.Etricc.Components.Interfaces.FieldPointInfo]] GetFieldPointInfosF" +
                    "orPointCollections(System.Collections.Generic.IEnumerable`1[System.String])", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.FieldPointInfo> Egemin.Etricc.Components.Interfaces.IFieldPointService.GetDetailedFieldPointInfos(System.Collections.Generic.IEnumerable<string> fieldPointIds) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[Egemin.Etricc.Components.Interfaces.FieldPoint" +
                    "Info] GetDetailedFieldPointInfos(System.Collections.Generic.IEnumerable`1[System" +
                    ".String])", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(fieldPointIds));
            beforeLogEntry.Log();
        }
        System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.FieldPointInfo> result = ((Egemin.Etricc.Components.Interfaces.IFieldPointService)(this.Wrappee)).GetDetailedFieldPointInfos(fieldPointIds);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[Egemin.Etricc.Components.Interfaces.FieldPoint" +
                    "Info] GetDetailedFieldPointInfos(System.Collections.Generic.IEnumerable`1[System" +
                    ".String])", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    System.Collections.Generic.IDictionary<string, Egemin.Epia.Foundation.ServiceModel.Polling.ChangeSet<string, Egemin.Etricc.Components.Interfaces.FieldPointInfo>> Egemin.Etricc.Components.Interfaces.IFieldPointService.Poll(System.Collections.Generic.IEnumerable<Egemin.Etricc.Components.Interfaces.VersionedId> versionedPointCollectionIds) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), @"System.Collections.Generic.IDictionary`2[System.String,Egemin.Epia.Foundation.ServiceModel.Polling.ChangeSet`2[System.String,Egemin.Etricc.Components.Interfaces.FieldPointInfo]] Poll(System.Collections.Generic.IEnumerable`1[Egemin.Etricc.Components.Interfaces.VersionedId])", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(versionedPointCollectionIds));
            beforeLogEntry.Log();
        }
        System.Collections.Generic.IDictionary<string, Egemin.Epia.Foundation.ServiceModel.Polling.ChangeSet<string, Egemin.Etricc.Components.Interfaces.FieldPointInfo>> result = ((Egemin.Etricc.Components.Interfaces.IFieldPointService)(this.Wrappee)).Poll(versionedPointCollectionIds);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), @"System.Collections.Generic.IDictionary`2[System.String,Egemin.Epia.Foundation.ServiceModel.Polling.ChangeSet`2[System.String,Egemin.Etricc.Components.Interfaces.FieldPointInfo]] Poll(System.Collections.Generic.IEnumerable`1[Egemin.Etricc.Components.Interfaces.VersionedId])", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    void Egemin.Etricc.Components.Interfaces.IFieldPointService.Toggle(string fieldPointId) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Void Toggle(System.String)", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(fieldPointId));
            beforeLogEntry.Log();
        }
        ((Egemin.Etricc.Components.Interfaces.IFieldPointService)(this.Wrappee)).Toggle(fieldPointId);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Void Toggle(System.String)", base.MakeSecondPartOfLogMessage());
            afterLogEntry.Log();
        }
    }
}
