public class LockWrapperForFieldPointService : Egemin.Epia.Foundation.ComponentManagement.WrapperGeneration.LockWrapper<Egemin.Etricc.Components.FieldPointService>, Egemin.Etricc.Components.Interfaces.IFieldPointService {
    
    public LockWrapperForFieldPointService(Egemin.Etricc.Components.FieldPointService wrappee) : 
            base(wrappee) {
    }
    
    System.Collections.Generic.IDictionary<string, System.Collections.Generic.List<Egemin.Etricc.Components.Interfaces.FieldPointInfo>> Egemin.Etricc.Components.Interfaces.IFieldPointService.GetFieldPointInfosForPointCollections(System.Collections.Generic.IEnumerable<string> pointCollectionIds) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.IFieldPointService)(this.Wrappee)).GetFieldPointInfosForPointCollections(pointCollectionIds);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.FieldPointInfo> Egemin.Etricc.Components.Interfaces.IFieldPointService.GetDetailedFieldPointInfos(System.Collections.Generic.IEnumerable<string> fieldPointIds) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.IFieldPointService)(this.Wrappee)).GetDetailedFieldPointInfos(fieldPointIds);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    System.Collections.Generic.IDictionary<string, Egemin.Epia.Foundation.ServiceModel.Polling.ChangeSet<string, Egemin.Etricc.Components.Interfaces.FieldPointInfo>> Egemin.Etricc.Components.Interfaces.IFieldPointService.Poll(System.Collections.Generic.IEnumerable<Egemin.Etricc.Components.Interfaces.VersionedId> versionedPointCollectionIds) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            return ((Egemin.Etricc.Components.Interfaces.IFieldPointService)(this.Wrappee)).Poll(versionedPointCollectionIds);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.IFieldPointService.Toggle(string fieldPointId) {
        System.Threading.Monitor.Enter(this.LockObject);
        try {
            ((Egemin.Etricc.Components.Interfaces.IFieldPointService)(this.Wrappee)).Toggle(fieldPointId);
        }
        finally {
            System.Threading.Monitor.Exit(this.LockObject);
        }
    }
}
