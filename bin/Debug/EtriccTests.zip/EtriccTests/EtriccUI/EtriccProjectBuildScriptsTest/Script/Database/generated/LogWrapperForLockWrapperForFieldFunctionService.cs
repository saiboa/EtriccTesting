public class LogWrapperForLockWrapperForFieldFunctionService : Egemin.Epia.Foundation.ComponentManagement.WrapperGeneration.LogWrapper<Egemin.Epia.Foundation.ComponentManagement.DynamicWrappers.LockWrapperForFieldFunctionService>, Egemin.Etricc.Components.Interfaces.IFieldFunctionService {
    
    public LogWrapperForLockWrapperForFieldFunctionService(Egemin.Epia.Foundation.ComponentManagement.DynamicWrappers.LockWrapperForFieldFunctionService wrappee) : 
            base(wrappee) {
    }
    
    System.Collections.Generic.IList<string> Egemin.Etricc.Components.Interfaces.IFieldFunctionService.GetFieldFunctionIds() {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[System.String] GetFieldFunctionIds()", base.MakeSecondPartOfLogMessage());
            beforeLogEntry.Log();
        }
        System.Collections.Generic.IList<string> result = ((Egemin.Etricc.Components.Interfaces.IFieldFunctionService)(this.Wrappee)).GetFieldFunctionIds();
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[System.String] GetFieldFunctionIds()", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.FieldFunctionInfo> Egemin.Etricc.Components.Interfaces.IFieldFunctionService.GetFieldFunctionInfos() {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[Egemin.Etricc.Components.Interfaces.FieldFunct" +
                    "ionInfo] GetFieldFunctionInfos()", base.MakeSecondPartOfLogMessage());
            beforeLogEntry.Log();
        }
        System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.FieldFunctionInfo> result = ((Egemin.Etricc.Components.Interfaces.IFieldFunctionService)(this.Wrappee)).GetFieldFunctionInfos();
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[Egemin.Etricc.Components.Interfaces.FieldFunct" +
                    "ionInfo] GetFieldFunctionInfos()", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.FieldFunctionInfo> Egemin.Etricc.Components.Interfaces.IFieldFunctionService.GetFieldFunctionInfos(System.Collections.Generic.IEnumerable<string> fieldFunctionIds) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[Egemin.Etricc.Components.Interfaces.FieldFunct" +
                    "ionInfo] GetFieldFunctionInfos(System.Collections.Generic.IEnumerable`1[System.S" +
                    "tring])", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(fieldFunctionIds));
            beforeLogEntry.Log();
        }
        System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.FieldFunctionInfo> result = ((Egemin.Etricc.Components.Interfaces.IFieldFunctionService)(this.Wrappee)).GetFieldFunctionInfos(fieldFunctionIds);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[Egemin.Etricc.Components.Interfaces.FieldFunct" +
                    "ionInfo] GetFieldFunctionInfos(System.Collections.Generic.IEnumerable`1[System.S" +
                    "tring])", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.FieldFunctionInfo> Egemin.Etricc.Components.Interfaces.IFieldFunctionService.GetDetailedFieldFunctionInfos(System.Collections.Generic.IEnumerable<string> fieldFunctionIds) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[Egemin.Etricc.Components.Interfaces.FieldFunct" +
                    "ionInfo] GetDetailedFieldFunctionInfos(System.Collections.Generic.IEnumerable`1[" +
                    "System.String])", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(fieldFunctionIds));
            beforeLogEntry.Log();
        }
        System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.FieldFunctionInfo> result = ((Egemin.Etricc.Components.Interfaces.IFieldFunctionService)(this.Wrappee)).GetDetailedFieldFunctionInfos(fieldFunctionIds);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[Egemin.Etricc.Components.Interfaces.FieldFunct" +
                    "ionInfo] GetDetailedFieldFunctionInfos(System.Collections.Generic.IEnumerable`1[" +
                    "System.String])", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    Egemin.Epia.Foundation.ServiceModel.Polling.ChangeSet<string, Egemin.Etricc.Components.Interfaces.FieldFunctionInfo> Egemin.Etricc.Components.Interfaces.IFieldFunctionService.Poll(int version) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Egemin.Epia.Foundation.ServiceModel.Polling.ChangeSet`2[System.String,Egemin.Etri" +
                    "cc.Components.Interfaces.FieldFunctionInfo] Poll(Int32)", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(version));
            beforeLogEntry.Log();
        }
        Egemin.Epia.Foundation.ServiceModel.Polling.ChangeSet<string, Egemin.Etricc.Components.Interfaces.FieldFunctionInfo> result = ((Egemin.Etricc.Components.Interfaces.IFieldFunctionService)(this.Wrappee)).Poll(version);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Egemin.Epia.Foundation.ServiceModel.Polling.ChangeSet`2[System.String,Egemin.Etri" +
                    "cc.Components.Interfaces.FieldFunctionInfo] Poll(Int32)", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    void Egemin.Etricc.Components.Interfaces.IFieldFunctionService.SetMode(System.Collections.Generic.IEnumerable<string> fieldFunctionIds, Egemin.Etricc.Components.Interfaces.FieldFunctionMode mode) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Void SetMode(System.Collections.Generic.IEnumerable`1[System.String], Egemin.Etri" +
                    "cc.Components.Interfaces.FieldFunctionMode)", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(fieldFunctionIds), ", ", base.CallToString(mode));
            beforeLogEntry.Log();
        }
        ((Egemin.Etricc.Components.Interfaces.IFieldFunctionService)(this.Wrappee)).SetMode(fieldFunctionIds, mode);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Void SetMode(System.Collections.Generic.IEnumerable`1[System.String], Egemin.Etri" +
                    "cc.Components.Interfaces.FieldFunctionMode)", base.MakeSecondPartOfLogMessage());
            afterLogEntry.Log();
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.IFieldFunctionService.SetForcedState(System.Collections.Generic.IEnumerable<string> fieldFunctionIds, bool state) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Void SetForcedState(System.Collections.Generic.IEnumerable`1[System.String], Bool" +
                    "ean)", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(fieldFunctionIds), ", ", base.CallToString(state));
            beforeLogEntry.Log();
        }
        ((Egemin.Etricc.Components.Interfaces.IFieldFunctionService)(this.Wrappee)).SetForcedState(fieldFunctionIds, state);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Void SetForcedState(System.Collections.Generic.IEnumerable`1[System.String], Bool" +
                    "ean)", base.MakeSecondPartOfLogMessage());
            afterLogEntry.Log();
        }
    }
    
    System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.FieldFunctionImage> Egemin.Etricc.Components.Interfaces.IFieldFunctionService.GetFieldFunctionImages() {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[Egemin.Etricc.Components.Interfaces.FieldFunct" +
                    "ionImage] GetFieldFunctionImages()", base.MakeSecondPartOfLogMessage());
            beforeLogEntry.Log();
        }
        System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.FieldFunctionImage> result = ((Egemin.Etricc.Components.Interfaces.IFieldFunctionService)(this.Wrappee)).GetFieldFunctionImages();
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[Egemin.Etricc.Components.Interfaces.FieldFunct" +
                    "ionImage] GetFieldFunctionImages()", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
}
