using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Egemin.EPIA.ComponentModel;
using Egemin.Etricc.Scripts.Core;

namespace Egemin.Etricc.Scripts.Database
{
    [Entry( "SaveHybrid", "Main" )]
    [Include( @"..\Core\Script.cs" )]
    public class SaveHybrid : Script
    {
        public override void Run()
        {
            Project.SaveXml( @"C:\Etricc 5.0.0\Sample\Data\Xml\TestXml.xml" );

            Project.RuntimeDbSerializers.InsertRuntimeDbSerializer( "SQL", "Provider=SQLOLEDB.1;Integrated Security=SSPI;Persist Security Info=False;Initial Catalog=Etricc;Data Source=." );
            Project.SetRuntimeDbSerializingDefault();
            Project.SaveDbWithContextDefault();

            Project.SaveXml( @"C:\Etricc 5.0.0\Sample\Data\Xml\TestHybrid.xml" );
        }
    }
}