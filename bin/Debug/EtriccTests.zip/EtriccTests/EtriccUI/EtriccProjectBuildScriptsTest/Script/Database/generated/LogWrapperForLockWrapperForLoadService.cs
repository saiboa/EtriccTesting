public class LogWrapperForLockWrapperForLoadService : Egemin.Epia.Foundation.ComponentManagement.WrapperGeneration.LogWrapper<Egemin.Epia.Foundation.ComponentManagement.DynamicWrappers.LockWrapperForLoadService>, Egemin.Etricc.Components.Interfaces.ILoadService {
    
    public LogWrapperForLockWrapperForLoadService(Egemin.Epia.Foundation.ComponentManagement.DynamicWrappers.LockWrapperForLoadService wrappee) : 
            base(wrappee) {
    }
    
    void Egemin.Etricc.Components.Interfaces.ILoadService.FlushAll() {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Void FlushAll()", base.MakeSecondPartOfLogMessage());
            beforeLogEntry.Log();
        }
        ((Egemin.Etricc.Components.Interfaces.ILoadService)(this.Wrappee)).FlushAll();
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Void FlushAll()", base.MakeSecondPartOfLogMessage());
            afterLogEntry.Log();
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.ILoadService.Flush(System.Collections.Generic.IEnumerable<string> loadIds) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Void Flush(System.Collections.Generic.IEnumerable`1[System.String])", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(loadIds));
            beforeLogEntry.Log();
        }
        ((Egemin.Etricc.Components.Interfaces.ILoadService)(this.Wrappee)).Flush(loadIds);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Void Flush(System.Collections.Generic.IEnumerable`1[System.String])", base.MakeSecondPartOfLogMessage());
            afterLogEntry.Log();
        }
    }
    
    void Egemin.Etricc.Components.Interfaces.ILoadService.Discard(System.Collections.Generic.IEnumerable<string> loadIds) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Void Discard(System.Collections.Generic.IEnumerable`1[System.String])", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(loadIds));
            beforeLogEntry.Log();
        }
        ((Egemin.Etricc.Components.Interfaces.ILoadService)(this.Wrappee)).Discard(loadIds);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Void Discard(System.Collections.Generic.IEnumerable`1[System.String])", base.MakeSecondPartOfLogMessage());
            afterLogEntry.Log();
        }
    }
    
    System.Collections.Generic.IList<string> Egemin.Etricc.Components.Interfaces.ILoadService.GetLoadIds() {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[System.String] GetLoadIds()", base.MakeSecondPartOfLogMessage());
            beforeLogEntry.Log();
        }
        System.Collections.Generic.IList<string> result = ((Egemin.Etricc.Components.Interfaces.ILoadService)(this.Wrappee)).GetLoadIds();
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[System.String] GetLoadIds()", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    Egemin.Etricc.Components.Interfaces.LoadInfo Egemin.Etricc.Components.Interfaces.ILoadService.GetLoadInfo(string loadId) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Egemin.Etricc.Components.Interfaces.LoadInfo GetLoadInfo(System.String)", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(loadId));
            beforeLogEntry.Log();
        }
        Egemin.Etricc.Components.Interfaces.LoadInfo result = ((Egemin.Etricc.Components.Interfaces.ILoadService)(this.Wrappee)).GetLoadInfo(loadId);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Egemin.Etricc.Components.Interfaces.LoadInfo GetLoadInfo(System.String)", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.LoadInfo> Egemin.Etricc.Components.Interfaces.ILoadService.GetLoadInfos() {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[Egemin.Etricc.Components.Interfaces.LoadInfo] " +
                    "GetLoadInfos()", base.MakeSecondPartOfLogMessage());
            beforeLogEntry.Log();
        }
        System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.LoadInfo> result = ((Egemin.Etricc.Components.Interfaces.ILoadService)(this.Wrappee)).GetLoadInfos();
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[Egemin.Etricc.Components.Interfaces.LoadInfo] " +
                    "GetLoadInfos()", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.LoadInfo> Egemin.Etricc.Components.Interfaces.ILoadService.GetLoadInfos(System.Collections.Generic.IEnumerable<string> loadIds) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[Egemin.Etricc.Components.Interfaces.LoadInfo] " +
                    "GetLoadInfos(System.Collections.Generic.IEnumerable`1[System.String])", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(loadIds));
            beforeLogEntry.Log();
        }
        System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.LoadInfo> result = ((Egemin.Etricc.Components.Interfaces.ILoadService)(this.Wrappee)).GetLoadInfos(loadIds);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[Egemin.Etricc.Components.Interfaces.LoadInfo] " +
                    "GetLoadInfos(System.Collections.Generic.IEnumerable`1[System.String])", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.LoadInfo> Egemin.Etricc.Components.Interfaces.ILoadService.GetDetailedLoadInfos(System.Collections.Generic.IEnumerable<string> loadIds) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[Egemin.Etricc.Components.Interfaces.LoadInfo] " +
                    "GetDetailedLoadInfos(System.Collections.Generic.IEnumerable`1[System.String])", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(loadIds));
            beforeLogEntry.Log();
        }
        System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.LoadInfo> result = ((Egemin.Etricc.Components.Interfaces.ILoadService)(this.Wrappee)).GetDetailedLoadInfos(loadIds);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[Egemin.Etricc.Components.Interfaces.LoadInfo] " +
                    "GetDetailedLoadInfos(System.Collections.Generic.IEnumerable`1[System.String])", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.LoadSystemOverviewInfo> Egemin.Etricc.Components.Interfaces.ILoadService.GetLoadSystemOverviewInfos() {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[Egemin.Etricc.Components.Interfaces.LoadSystem" +
                    "OverviewInfo] GetLoadSystemOverviewInfos()", base.MakeSecondPartOfLogMessage());
            beforeLogEntry.Log();
        }
        System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.LoadSystemOverviewInfo> result = ((Egemin.Etricc.Components.Interfaces.ILoadService)(this.Wrappee)).GetLoadSystemOverviewInfos();
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[Egemin.Etricc.Components.Interfaces.LoadSystem" +
                    "OverviewInfo] GetLoadSystemOverviewInfos()", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.LoadImage> Egemin.Etricc.Components.Interfaces.ILoadService.GetLoadImages() {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[Egemin.Etricc.Components.Interfaces.LoadImage]" +
                    " GetLoadImages()", base.MakeSecondPartOfLogMessage());
            beforeLogEntry.Log();
        }
        System.Collections.Generic.IList<Egemin.Etricc.Components.Interfaces.LoadImage> result = ((Egemin.Etricc.Components.Interfaces.ILoadService)(this.Wrappee)).GetLoadImages();
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "System.Collections.Generic.IList`1[Egemin.Etricc.Components.Interfaces.LoadImage]" +
                    " GetLoadImages()", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
    
    Egemin.Epia.Foundation.ServiceModel.Polling.ChangeSet<string, Egemin.Etricc.Components.Interfaces.LoadInfo> Egemin.Etricc.Components.Interfaces.ILoadService.Poll(int version) {
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry beforeLogEntry = base.MakeLogEntry();
        if (beforeLogEntry.ShouldLog()) {
            beforeLogEntry.Message = string.Concat("Begin call from ", base.MakeFirstPartOfLogMessage(), "Egemin.Epia.Foundation.ServiceModel.Polling.ChangeSet`2[System.String,Egemin.Etri" +
                    "cc.Components.Interfaces.LoadInfo] Poll(Int32)", base.MakeSecondPartOfLogMessage(), " with actual arguments ", base.CallToString(version));
            beforeLogEntry.Log();
        }
        Egemin.Epia.Foundation.ServiceModel.Polling.ChangeSet<string, Egemin.Etricc.Components.Interfaces.LoadInfo> result = ((Egemin.Etricc.Components.Interfaces.ILoadService)(this.Wrappee)).Poll(version);
        Egemin.Epia.Foundation.ComponentManagement.LoggingAndExceptionHandling.LogWrapperLogEntry afterLogEntry = base.MakeLogEntry();
        if (afterLogEntry.ShouldLog()) {
            afterLogEntry.Message = string.Concat("End call from ", base.MakeFirstPartOfLogMessage(), "Egemin.Epia.Foundation.ServiceModel.Polling.ChangeSet`2[System.String,Egemin.Etri" +
                    "cc.Components.Interfaces.LoadInfo] Poll(Int32)", base.MakeSecondPartOfLogMessage(), " with result ", base.CallToString(result));
            afterLogEntry.Log();
        }
        return result;
    }
}
