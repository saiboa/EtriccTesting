﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Egemin.Etricc.Scripts.Core
{
    public static class IOSerialExtensions
    {
        /// <summary>
        /// Adds a serial port to the serial ports collection.
        /// </summary>
        /// <param name="serialPorts">Serial port collection.</param>
        /// <param name="id">Serial port ID.</param>
        /// <param name="baudRate">Serial port baud rate.</param>
        /// <param name="byteSize">Serial port byte size.</param>
        /// <param name="parity">Serial port parity.</param>
        /// <returns>The created serial port.</returns>
        public static Egemin.EPIA.IO.Serial.SerialPort InsertSerialPort(this Egemin.EPIA.IO.Serial.SerialPorts serialPorts, string id, int baudRate, int byteSize, char parity)
        {
            Dialog.SetProgress("SerialPorts", string.Format("Inserting SerialPort : {0}", id));

            Egemin.EPIA.IO.Serial.SerialPort serialPort = new Egemin.EPIA.IO.Serial.SerialPort(id);

            // properties
            serialPort.Baudrate = baudRate;
            serialPort.ByteSize = byteSize;
            serialPort.Stopbits = 1;
            serialPort.Parity = parity;
            serialPort.LeadSync = "~~~";
            serialPort.RtsCts = true;
            serialPort.RcvTimeout = 400;

            return serialPorts.Insert(serialPort, true) as Egemin.EPIA.IO.Serial.SerialPort;
        }

        /// <summary>
        /// Adds gateway to the gateway collection.
        /// </summary>
        /// <param name="gateways">Gateway collection.</param>
        /// <param name="id">Gateway ID.</param>
        /// <param name="type">Gateway type.</param>
        /// <param name="connectionType">Gateway connection type.</param>
        /// <param name="address">Gateway remote address.</param>
        /// <returns>The created gateway.</returns>
        public static Egemin.EPIA.Communication.Gateway InsertGateWay(this Egemin.EPIA.Communication.Gateways gateways, string id, Egemin.EPIA.Communication.Gateway.TYPE type, Egemin.EPIA.Communication.Gateway.CONNECTION_TYPE connectionType, string address)
        {
            Dialog.SetProgress("SerialPorts", string.Format("Inserting SerialPort : {0}", id));

            Egemin.EPIA.Communication.Gateway gateway = new Egemin.EPIA.Communication.Gateway(id);

            //properties
            gateway.Type = type;
            gateway.ConnectionType = connectionType;
            gateway.Address = address;

            return gateways.Insert(gateway, true) as Egemin.EPIA.Communication.Gateway;
        }

    } 
}