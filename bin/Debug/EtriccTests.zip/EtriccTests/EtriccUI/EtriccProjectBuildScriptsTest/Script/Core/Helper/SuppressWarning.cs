﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Egemin.Etricc.Scripts.Core
{
    [AttributeUsage(AttributeTargets.Assembly, AllowMultiple = true)]
    public class SuppressWarning : Attribute
    {
        public string Symbol { get; private set; }
        public string[] Arguments { get; private set; }

        public SuppressWarning(string symbol, params string[] arguments)
        {
            this.Symbol = symbol;
            this.Arguments = arguments;
        }

        public bool Suppresses(Egemin.EPIA.Logging.LogMessage logMessage)
        {
            if (logMessage == null)
                return false;

            if (this.Symbol != logMessage.Symbol)
                return false;

            foreach (var arg in this.Arguments)
                if (!logMessage.Arguments.Contains(arg))
                    return false;

            return true;
        }
    }
}