﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Egemin.Etricc.Scripts.Core
{
    public static class File
    {

        /// <summary>
        /// Gets the fully qualified path of a file. Absolute or relative to the project base directory.
        /// </summary>
        /// <param name="fileName">Absolute or relative path of a file.</param>
        /// <returns>The fully qualified name of a file.</returns>
        public static string GetFullFileName(string fileName)
        {
            return GetFullFileName(fileName, true);
        }

        /// <summary>
        /// Gets the fully qualified path of a file. Absolute or relative to the project base directory.
        /// </summary>
        /// <param name="fileName">Absolute or relative path of a file.</param>
        /// <param name="fileName">Defines if the file should exist or not.</param>
        /// <returns>The fully qualified name of a file.</returns>
        public static string GetFullFileName(string fileName, bool shouldExist)
        {
            return GetFullFileName(fileName, shouldExist, Script.Project.WorkingDirName);
        }

        /// <summary>
        /// Gets the fully qualified path of a file. Absolute or relative to the project base directory.
        /// </summary>
        /// <param name="fileName">Absolute or relative path of a file.</param>
        /// <param name="shouldExist">Defines if the file should exist or not.</param>
        /// <param name="searchDirs">A list of directorynames where to look for the file.</param>
        /// <returns>The fully qualified name of a file.</returns>
        public static string GetFullFileName(string fileName, bool shouldExist, params string[] searchDirs)
        {
            if (fileName == null)
                return null;

            try
            {
                // path is absolute or relative to the working directory
                System.IO.FileInfo fileInfo = new System.IO.FileInfo(fileName);
                if (fileInfo.Exists)
                    return fileInfo.FullName;
                else if (!shouldExist && fileInfo.Directory.Exists)
                    return fileInfo.FullName;

                if (!searchDirs.Contains(Script.Project.WorkingDirName))
                    searchDirs = searchDirs.Concat(new string[] { Script.Project.WorkingDirName }).ToArray();

                // path is relative to the search directories
                foreach (var searchDir in searchDirs)
                {
                    fileInfo = new System.IO.FileInfo(searchDir + @"\" + fileName);
                    if (fileInfo.Exists)
                        return fileInfo.FullName;
                    else if (!shouldExist && fileInfo.Directory.Exists)
                        return fileInfo.FullName;
                }

            }
            // the fileName given to the constructor of FileInfo is not valid.
            catch (NotSupportedException)
            { }

            // no valid file found
            if (shouldExist)
                throw new System.IO.FileNotFoundException(null, fileName);
            // no valid directory found
            else
                throw new System.IO.DirectoryNotFoundException(fileName);
        }

        /// <summary>
        /// Gets the fully qualified path of a directory.
        /// </summary>
        /// <param name="directoryName">Absolute or relative path of a directory.</param>
        /// <returns>The fully qualified name of a directory.</returns>
        public static string GetFullDirectoryName(string directoryName)
        {
            if (directoryName == null)
                return null;

            // path is absolute
            System.IO.DirectoryInfo directoryInfo = new System.IO.DirectoryInfo(directoryName);
            if (directoryInfo.Exists)
                return directoryInfo.FullName;

            // path is relative to the project directory
            directoryInfo = new System.IO.DirectoryInfo(Script.Project.WorkingDirName + @"\" + directoryInfo);
            if (directoryInfo.Exists)
                return directoryInfo.FullName;

            //No valid Directory found. Throw Invalid FileNameException
            throw new System.IO.DirectoryNotFoundException(directoryName);
        }
    }
}