﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Egemin.Etricc.Scripts.Core
{
    public static class TransportationExtensions
    {
        /// <summary>
        /// Adds a new transport type to the transport type collection 
        /// </summary>
        /// <param name="transportTypes">Transport types collection.</param>
        /// <param name="id">Transport ID.</param>
        /// <param name="priorityDefault">Default transport priority.</param>
        /// <param name="priorityInrTime">Transport priority increment time.</param>
        /// <returns>The created transport type.</returns>
        public static Egemin.EPIA.WCS.Transportation.TransportType InsertTransportType(this Egemin.EPIA.WCS.Transportation.TransportTypes transportTypes, string id, int priorityDefault, int priorityInrTime)
        {
            Egemin.EPIA.WCS.Transportation.TransportType transportType = new Egemin.EPIA.WCS.Transportation.TransportType(id);

            // parameters
            transportType.Parameters[Egemin.EPIA.WCS.Transportation.TransportType.PRIORITY_DEFAULT].ValueAsInt = priorityDefault;
            transportType.Parameters[Egemin.EPIA.WCS.Transportation.TransportType.PRIORITY_INCR_TIME].ValueAsInt = priorityInrTime;

            return transportTypes.Insert(transportType, true) as Egemin.EPIA.WCS.Transportation.TransportType;
        }
    } 
}