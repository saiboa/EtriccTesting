using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Egemin.Etricc.Scripts.Core
{
    /// <summary>
    /// Base class for all E'tricc scripts.
    /// </summary>
    [Egemin.EPIA.ComponentModel.Reference("Egemin.EPIA.Common")]
    [Egemin.EPIA.ComponentModel.Reference("Egemin.EPIA.Common.Interfaces")]
    [Egemin.EPIA.ComponentModel.Reference("Egemin.EPIA.Common.Security")]
    [Egemin.EPIA.ComponentModel.Reference("Egemin.EPIA.Common.UI")]
    [Egemin.EPIA.ComponentModel.Reference("Egemin.EPIA.Definitions")]
    [Egemin.EPIA.ComponentModel.Reference("Egemin.EPIA.ExplorerLib")]
    [Egemin.EPIA.ComponentModel.Reference("Egemin.EPIA.WCS")]
    [Egemin.EPIA.ComponentModel.Reference("System")]
    [Egemin.EPIA.ComponentModel.Reference("System.Core")]
    [Egemin.EPIA.ComponentModel.Reference("System.Data")]
    [Egemin.EPIA.ComponentModel.Reference("System.Data.Linq")]
    [Egemin.EPIA.ComponentModel.Reference("System.Data.DataSetExtensions")]
    [Egemin.EPIA.ComponentModel.Reference("System.Drawing")]
    [Egemin.EPIA.ComponentModel.Reference("System.Windows.Forms")]
    [Egemin.EPIA.ComponentModel.Reference("System.Xml")]
    [Egemin.EPIA.ComponentModel.Reference("System.Xml.Linq")]

    [Egemin.EPIA.ComponentModel.Include(@"..\Core\ScriptContext.cs")]

    [Egemin.EPIA.ComponentModel.Include(@"..\Core\Extensions\CollectionExtensions.cs")]
    [Egemin.EPIA.ComponentModel.Include(@"..\Core\Extensions\CoreExtensions.cs")]
    [Egemin.EPIA.ComponentModel.Include(@"..\Core\Extensions\IOFieldExtensions.cs")]
    [Egemin.EPIA.ComponentModel.Include(@"..\Core\Extensions\IOHostExtensions.cs")]
    [Egemin.EPIA.ComponentModel.Include(@"..\Core\Extensions\IOOPCExtensions.cs")]
    [Egemin.EPIA.ComponentModel.Include(@"..\Core\Extensions\IOSerialExtensions.cs")]
    [Egemin.EPIA.ComponentModel.Include(@"..\Core\Extensions\LayoutingExtensions.cs")]
    [Egemin.EPIA.ComponentModel.Include(@"..\Core\Extensions\LoggingExtensions.cs")]
    [Egemin.EPIA.ComponentModel.Include(@"..\Core\Extensions\PersistencyExtensions.cs")]
    [Egemin.EPIA.ComponentModel.Include(@"..\Core\Extensions\ResourcesExtensions.cs")]
    [Egemin.EPIA.ComponentModel.Include(@"..\Core\Extensions\SchedulingExtensions.cs")]
    [Egemin.EPIA.ComponentModel.Include(@"..\Core\Extensions\SecurityExtensions.cs")]
    [Egemin.EPIA.ComponentModel.Include(@"..\Core\Extensions\StorageExtensions.cs")]
    [Egemin.EPIA.ComponentModel.Include(@"..\Core\Extensions\TaskExtensions.cs")]
    [Egemin.EPIA.ComponentModel.Include(@"..\Core\Extensions\TransportationExtensions.cs")]

    [Egemin.EPIA.ComponentModel.Include(@"..\Core\Helper\AbortException.cs")]
    [Egemin.EPIA.ComponentModel.Include(@"..\Core\Helper\Constants.cs")]
    [Egemin.EPIA.ComponentModel.Include(@"..\Core\Helper\Dialog.cs")]
    [Egemin.EPIA.ComponentModel.Include(@"..\Core\Helper\File.cs")]
    [Egemin.EPIA.ComponentModel.Include(@"..\Core\Helper\SuppressWarning.cs")]

    [Egemin.EPIA.ComponentModel.Include(@"..\Main\Header.cs")]

    [Egemin.EPIA.ComponentModel.Entry("Script", "Main")]
    public abstract class Script
    {

        #region Properties

        /// <summary>
        /// Gets or sets a static root project reference.
        /// </summary>
        public static Egemin.EPIA.WCS.Core.Project Project { get; set; }

        /// <summary>
        /// Reference to the initial root, to verify if a new instance was assigned to the root.
        /// </summary>
        private static Egemin.EPIA.WCS.Core.Project InitialProject { get; set; }

        #endregion

        #region Methods

        /// <summary>
        /// Main entry point for every script
        /// </summary>
        /// <param name="root">Root object</param>
        /// <returns>A new root if a new instance was created</returns>
        public object Main(object root)
        {
            // copy the root to a static member, so that all scripts can access it
            InitialProject = Project = root as Egemin.EPIA.WCS.Core.Project;


            // run the Run() method
            try
            {
                Dialog.SetProgress(null, "Running script");

                Run();
            }
            // somewhere in the stack, an Abort() was called
            catch (AbortException abortEx)
            {
                if (abortEx.InnerException != null)
                    throw;
                return null;
            }
            // Hide the splash screen
            finally
            {
                Dialog.Splash.Hide();
            }

            // if the project is a new instance, return it
            if (InitialProject != Project)
                return Project;
            else
                return null;
        }

        /// <summary>
        /// General method called by the main entry point for the script.
        /// </summary>
        public abstract void Run();

        /// <summary>
        /// Instantiates a script and executes the Run() method.
        /// </summary>
        /// <param name="scriptTypeName">Name of the type of script to run.</param>
        public static void Run(string scriptTypeName)
        {
            System.Reflection.Assembly assembly = System.Reflection.Assembly.GetExecutingAssembly();
            if (assembly.GetType(scriptTypeName) == null)
                assembly = System.Reflection.Assembly.GetCallingAssembly();
            if (assembly.GetType(scriptTypeName) == null)
                assembly = System.Reflection.Assembly.GetEntryAssembly();

            Script script = Activator.CreateInstance(System.Reflection.Assembly.GetCallingAssembly().FullName, scriptTypeName).Unwrap() as Script;
            if (script == null)
                throw new ArgumentNullException("script");

            script.Run();
        }

        /// <summary>
        /// Instantiates a script and executes the Run() method.
        /// </summary>
        /// <param name="t">Type of script to run.</param>
        public static void Run(Type t)
        {
            Script script = Activator.CreateInstance(t) as Script;
            if (script == null)
                throw new ArgumentNullException("script");

            script.Run();
        }

        /// <summary>
        /// Instantiates a script and executes the Run() method.
        /// </summary>
        /// <typeparam name="T">Type of script to run.</typeparam>
        public static void Run<T>() where T : Script
        {
            T script = Activator.CreateInstance<T>();
            if (script == null)
                throw new ArgumentNullException("script");

            script.Run();
        }

        /// <summary>
        /// Executes the Run() method of the provided Script.
        /// </summary>
        /// <param name="script">The script to run.</param>
        public static void Run(Script script)
        {
            if (script == null)
                throw new ArgumentNullException("script");

            script.Run();
        }

        /// <summary>
        /// Aborts script execution.
        /// </summary>
        public static void Abort()
        {
            throw new AbortException();
        }

        /// <summary>
        /// Aborts script execution.
        /// </summary>
        /// <param name="message">A message that explains the reason for the abortion.</param>
        public static void Abort(string message)
        {
            throw new AbortException(message);
        }

        /// <summary>
        /// Aborts script execution.
        /// </summary>
        /// <param name="innerException">The exception that is the cause of the abortion.</param>
        public static void Abort(Exception innerException)
        {
            throw new AbortException(innerException);
        }

        /// <summary>
        /// Aborts script execution.
        /// </summary>
        /// <param name="message">A message that explains the reason for the abortion.</param>
        /// <param name="innerException">The exception that is the cause of the abortion.</param>
        public static void Abort(string message, Exception innerException)
        {
            throw new AbortException(message, innerException);
        }

        #endregion
    }
}