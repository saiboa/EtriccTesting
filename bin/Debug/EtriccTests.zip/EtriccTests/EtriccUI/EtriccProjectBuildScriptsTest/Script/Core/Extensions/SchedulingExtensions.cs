﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Egemin.Etricc.Scripts.Core
{
    /// <summary>
    /// Defines extension methods to the Egemin.EPIA.WCS.Scheduling namespace.
    /// </summary>
    public static class SchedulingExtensions
    {
        /// <summary>
        /// Adds a schedule to the schedule collection.
        /// </summary>
        /// <param name="schedules">Schedule collection.</param>
        /// <param name="lsgid">Schedule reference location/station/group ID.</param>
        /// <param name="type">Schedule type.</param>
        /// <returns>The created schedule.</returns>
        public static Egemin.EPIA.WCS.Scheduling.Schedule InsertSchedule(this Egemin.EPIA.WCS.Scheduling.Schedules schedules, object lsgid, Egemin.EPIA.WCS.Scheduling.Schedule.TYPE type)
        {
            var schedule = new Egemin.EPIA.WCS.Scheduling.Schedule(lsgid, type);

            Dialog.SetProgress("Schedules", string.Format("Inserting Schedule : {0}.{1}", lsgid, type));

            return schedules.Insert(schedule, true) as Egemin.EPIA.WCS.Scheduling.Schedule;
        }

        /// <summary>
        /// Adds a rule to the rules collection.
        /// </summary>
        /// <param name="schedule">Rule collection.</param>
        /// <param name="type">Rule type.</param>
        /// <param name="arguments">Rule arguments.</param>
        /// <returns>The created schedule.</returns>
        public static Egemin.EPIA.WCS.Scheduling.Rule InsertRule(this Egemin.EPIA.WCS.Scheduling.Rules rules, Egemin.EPIA.WCS.Scheduling.Rule.TYPE type, string arguments)
        {
            var rule = new Egemin.EPIA.WCS.Scheduling.Rule();

            // properties
            rule.Type = type;
            rule.Arguments = arguments;

            Dialog.SetProgress("Schedules", string.Format("Inserting Rule : Type = {0}, Arguments = {1}", type.ToString(), arguments));

            return rules.Insert(rule, true) as Egemin.EPIA.WCS.Scheduling.Rule;
        }
    } 
}