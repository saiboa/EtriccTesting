﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Egemin.Etricc.Scripts.Core
{
    public static class Dialog
    {
        /// <summary>
        /// Indicates that no UI messages should be displayed.
        /// </summary>
        public static bool Silent { get; set; }

        #region  Splash

        /// <summary>
        /// a splash screen for displaying progress.
        /// </summary>
        private static Egemin.EPIA.UI.Windows.Forms.frmSplash m_Splash = new Egemin.EPIA.UI.Windows.Forms.frmSplash("E'pia Explorer Script", new System.Drawing.Bitmap(1, 1));

        /// <summary>
        /// Splash screen for dispaying progress.
        /// </summary>
        public static Egemin.EPIA.UI.Windows.Forms.frmSplash Splash
        {
            get { return m_Splash; }
        }

        /// <summary>
        /// Title in the progress display window.
        /// </summary>
        private static string ProgressTitle
        {
            get { return m_Splash.Message; }
            set
            {
                if (m_Splash.Message == value)
                    return;
                m_Splash.Message = value;
            }
        }

        /// <summary>
        /// Message in the progress display window.
        /// </summary>
        private static string ProgessMessage
        {
            get { return m_Splash.Title; }
            set
            {
                if (m_Splash.Title == value)
                    return;
                m_Splash.Title = value;

                if (value == null)
                    return;
                if (value.Trim() == string.Empty)
                    return;
                Console.WriteLine("{0} {1}", DateTime.Now.ToString("hh:MM:ss.fff"), value);
            }
        }

        /// <summary>
        /// Show a progress display window.
        /// </summary>
        /// <param name="title">Progress window title.</param>
        /// <param name="message">Pogress window message.</param>
        public static void SetProgress(string title, string message)
        {
            ProgressTitle = title;
            ProgessMessage = message;

            if (Silent)
                return;

            Splash.Show();

            System.Windows.Forms.Application.DoEvents();
        }

        #endregion

        #region MessageBox

        public static class MessageBox
        {

            /// <summary>
            /// Displays a message box with specified text.
            /// </summary>
            /// <param name="text">The text to display in the message box.</param>
            /// <returns>One of the System.Windows.Forms.DialogResult values.</returns>
            public static System.Windows.Forms.DialogResult Show(string text)
            {
                if (Silent)
                    return System.Windows.Forms.DialogResult.None;

                return System.Windows.Forms.MessageBox.Show(text);
            }

            /// <summary>
            /// Displays a message box in front of the specified object and with the specified text.
            /// </summary>
            /// <param name="owner">An implementation of System.Windows.Forms.IWin32Window that will own the modal dialog box.</param>
            /// <param name="text">The text to display in the message box.</param>
            /// <returns>One of the System.Windows.Forms.DialogResult values.</returns>
            public static System.Windows.Forms.DialogResult Show(System.Windows.Forms.IWin32Window owner, string text)
            {
                if (Silent)
                    return System.Windows.Forms.DialogResult.None;

                return System.Windows.Forms.MessageBox.Show(owner, text);
            }

            /// <summary>
            /// Displays a message box with specified text and caption.
            /// </summary>
            /// <param name="text">The text to display in the message box.</param>
            /// <param name="caption">The text to display in the title bar of the message box.</param>
            /// <returns>One of the System.Windows.Forms.DialogResult values.</returns>
            public static System.Windows.Forms.DialogResult Show(string text, string caption)
            {
                if (Silent)
                    return System.Windows.Forms.DialogResult.None;

                return System.Windows.Forms.MessageBox.Show(text, caption);
            }

            /// <summary>
            ///  Displays a message box in front of the specified object and with the specified text and caption.
            /// </summary>
            /// <param name="owner">An implementation of System.Windows.Forms.IWin32Window that will own the modal dialog box.</param>
            /// <param name="text">The text to display in the message box.</param>
            /// <param name="caption">The text to display in the title bar of the message box.</param>
            /// <returns>One of the System.Windows.Forms.DialogResult values.</returns>
            public static System.Windows.Forms.DialogResult Show(System.Windows.Forms.IWin32Window owner, string text, string caption)
            {
                if (Silent)
                    return System.Windows.Forms.DialogResult.None;

                return System.Windows.Forms.MessageBox.Show(owner, text, caption);
            }

            /// <summary>
            /// Displays a message box with specified text, caption, and buttons.
            /// </summary>
            /// <param name="text">The text to display in the message box.</param>
            /// <param name="caption"> The text to display in the title bar of the message box.</param>
            /// <param name="buttons">One of the System.Windows.Forms.MessageBoxButtons values that specifies which buttons to display in the message box.</param>
            /// <returns>One of the System.Windows.Forms.DialogResult values.</returns>
            public static System.Windows.Forms.DialogResult Show(string text, string caption, System.Windows.Forms.MessageBoxButtons buttons)
            {
                if (Silent)
                    return System.Windows.Forms.DialogResult.None;

                return System.Windows.Forms.MessageBox.Show(text, caption, buttons);
            }

            /// <summary>
            /// Displays a message box in front of the specified object and with the specified text, caption, and buttons.</summary>
            /// <param name="owner">An implementation of System.Windows.Forms.IWin32Window that will own the modal dialog box.</param>
            /// <param name="text">The text to display in the message box.</param>
            /// <param name="buttons">One of the System.Windows.Forms.MessageBoxButtons values that specifies which buttons to display in the message box.</param>
            /// <returns>One of the System.Windows.Forms.DialogResult values.</returns>
            public static System.Windows.Forms.DialogResult Show(System.Windows.Forms.IWin32Window owner, string text, string caption, System.Windows.Forms.MessageBoxButtons buttons)
            {
                if (Silent)
                    return System.Windows.Forms.DialogResult.None;

                return System.Windows.Forms.MessageBox.Show(owner, text, caption, buttons);
            }

            /// <summary>
            /// Displays a message box with specified text, caption, buttons, and icon.
            /// </summary>
            /// <param name="text">The text to display in the message box.</param>
            /// <param name="caption">The text to display in the title bar of the message box.</param>
            /// <param name="buttons">One of the System.Windows.Forms.MessageBoxButtons values that specifies which buttons to display in the message box.</param>
            /// <param name="icon">One of the System.Windows.Forms.MessageBoxIcon values that specifies which icon to display in the message box.</param>
            /// <returns>One of the System.Windows.Forms.DialogResult values.</returns>
            public static System.Windows.Forms.DialogResult Show(string text, string caption, System.Windows.Forms.MessageBoxButtons buttons, System.Windows.Forms.MessageBoxIcon icon)
            {
                if (Silent)
                    return System.Windows.Forms.DialogResult.None;

                return System.Windows.Forms.MessageBox.Show(text, caption, buttons, icon);
            }

            /// <summary>
            /// Displays a message box in front of the specified object and with the specified text, caption, buttons, and icon.
            /// </summary>
            /// <param name="owner">An implementation of System.Windows.Forms.IWin32Window that will own the modal dialog box.</param>
            /// <param name="text">The text to display in the message box.</param>
            /// <param name="caption"> The text to display in the title bar of the message box.</param>
            /// <param name="buttons">One of the System.Windows.Forms.MessageBoxButtons values that specifies which buttons to display in the message box.</param>
            /// <param name="icon">One of the System.Windows.Forms.MessageBoxIcon values that specifies which icon to display in the message box.</param>
            /// <returns>One of the System.Windows.Forms.DialogResult values.</returns>
            public static System.Windows.Forms.DialogResult Show(System.Windows.Forms.IWin32Window owner, string text, string caption, System.Windows.Forms.MessageBoxButtons buttons, System.Windows.Forms.MessageBoxIcon icon)
            {
                if (Silent)
                    return System.Windows.Forms.DialogResult.None;

                return System.Windows.Forms.MessageBox.Show(owner, text, caption, buttons, icon);
            }

            /// <summary>
            /// Displays a message box with the specified text, caption, buttons, icon, and default button.
            /// </summary>
            /// <param name="text">The text to display in the message box.</param>
            /// <param name="caption">The text to display in the title bar of the message box.</param>
            /// <param name="buttons">One of the System.Windows.Forms.MessageBoxButtons values that specifies which buttons to display in the message box.</param>
            /// <param name="icon">One of the System.Windows.Forms.MessageBoxIcon values that specifies which icon to display in the message box.</param>
            /// <param name="defaultButton">One of the System.Windows.Forms.MessageBoxDefaultButton values that specifies the default button for the message box.</param>
            /// <returns>One of the System.Windows.Forms.DialogResult values.</returns>
            public static System.Windows.Forms.DialogResult Show(string text, string caption, System.Windows.Forms.MessageBoxButtons buttons, System.Windows.Forms.MessageBoxIcon icon, System.Windows.Forms.MessageBoxDefaultButton defaultButton)
            {
                if (Silent)
                    return System.Windows.Forms.DialogResult.None;

                return System.Windows.Forms.MessageBox.Show(text, caption, buttons, icon, defaultButton);
            }

            /// <summary>
            /// Displays a message box in front of the specified object and with the specified text, caption, buttons, icon, and default button.
            /// </summary>
            /// <param name="owner">An implementation of System.Windows.Forms.IWin32Window that will own the modal dialog box.</param>
            /// <param name="text">The text to display in the message box.</param>
            /// <param name="caption"> The text to display in the title bar of the message box.</param>
            /// <param name="buttons">One of the System.Windows.Forms.MessageBoxButtons values that specifies which buttons to display in the message box.</param>
            /// <param name="icon">One of the System.Windows.Forms.MessageBoxIcon values that specifies which icon to display in the message box.</param>
            /// <param name="defaultButton">One of the System.Windows.Forms.MessageBoxDefaultButton values that specifies the default button for the message box.</param>
            /// <returns>One of the System.Windows.Forms.DialogResult values.</returns>
            public static System.Windows.Forms.DialogResult Show(System.Windows.Forms.IWin32Window owner, string text, string caption, System.Windows.Forms.MessageBoxButtons buttons, System.Windows.Forms.MessageBoxIcon icon, System.Windows.Forms.MessageBoxDefaultButton defaultButton)
            {
                if (Silent)
                    return System.Windows.Forms.DialogResult.None;

                return System.Windows.Forms.MessageBox.Show(owner, text, caption, buttons, icon, defaultButton);
            }

            /// <summary>
            /// Displays a message box with the specified text, caption, buttons, icon, default button, and options.
            /// </summary>
            /// <param name="text">The text to display in the message box.</param>
            /// <param name="caption">The text to display in the title bar of the message box.</param>
            /// <param name="buttons">One of the System.Windows.Forms.MessageBoxButtons values that specifies which buttons to display in the message box.</param>
            /// <param name="icon">One of the System.Windows.Forms.MessageBoxIcon values that specifies which icon to display in the message box.</param>
            /// <param name="defaultButton">One of the System.Windows.Forms.MessageBoxDefaultButton values that specifies the default button for the message box.</param>
            /// <param name="options">One of the System.Windows.Forms.MessageBoxOptions values that specifies which display and association options will be used for the message box. You may pass in 0 if you wish to use the defaults.</param>
            /// <returns>One of the System.Windows.Forms.DialogResult values.</returns>
            public static System.Windows.Forms.DialogResult Show(string text, string caption, System.Windows.Forms.MessageBoxButtons buttons, System.Windows.Forms.MessageBoxIcon icon, System.Windows.Forms.MessageBoxDefaultButton defaultButton, System.Windows.Forms.MessageBoxOptions options)
            {
                if (Silent)
                    return System.Windows.Forms.DialogResult.None;

                return System.Windows.Forms.MessageBox.Show(text, caption, buttons, icon, defaultButton, options);
            }

            /// <summary>
            /// Displays a message box in front of the specified object and with the specified text, caption, buttons, icon, default button, and options.
            /// </summary>
            /// <param name="owner">An implementation of System.Windows.Forms.IWin32Window that will own the modal dialog box.</param>
            /// <param name="text">The text to display in the message box.</param>
            /// <param name="caption"> The text to display in the title bar of the message box.</param>
            /// <param name="buttons">One of the System.Windows.Forms.MessageBoxButtons values that specifies which buttons to display in the message box.</param>
            /// <param name="icon">One of the System.Windows.Forms.MessageBoxIcon values that specifies which icon to display in the message box.</param>
            /// <param name="defaultButton">One of the System.Windows.Forms.MessageBoxDefaultButton values that specifies the default button for the message box.</param>
            /// <param name="options">One of the System.Windows.Forms.MessageBoxOptions values that specifies which display and association options will be used for the message box. You may pass in 0 if you wish to use the defaults.</param>
            /// <returns>One of the System.Windows.Forms.DialogResult values.</returns>
            public static System.Windows.Forms.DialogResult Show(System.Windows.Forms.IWin32Window owner, string text, string caption, System.Windows.Forms.MessageBoxButtons buttons, System.Windows.Forms.MessageBoxIcon icon, System.Windows.Forms.MessageBoxDefaultButton defaultButton, System.Windows.Forms.MessageBoxOptions options)
            {
                if (Silent)
                    return System.Windows.Forms.DialogResult.None;

                return System.Windows.Forms.MessageBox.Show(owner, text, caption, buttons, icon, defaultButton, options);
            }

            /// <summary>
            /// Displays a message box with the specified text, caption, buttons, icon, default button, options, and Help button.
            /// </summary>
            /// <param name="text">The text to display in the message box.</param>
            /// <param name="caption"> The text to display in the title bar of the message box.</param>
            /// <param name="buttons">One of the System.Windows.Forms.MessageBoxButtons values that specifies which buttons to display in the message box.</param>
            /// <param name="icon">One of the System.Windows.Forms.MessageBoxIcon values that specifies which icon to display in the message box.</param>
            /// <param name="defaultButton">One of the System.Windows.Forms.MessageBoxDefaultButton values that specifies the default button for the message box.</param>
            /// <param name="options">One of the System.Windows.Forms.MessageBoxOptions values that specifies which display and association options will be used for the message box. You may pass in 0 if you wish to use the defaults.</param>
            /// <param name="displayHelpButton"></param>
            /// <returns>One of the System.Windows.Forms.DialogResult values.</returns>
            public static System.Windows.Forms.DialogResult Show(string text, string caption, System.Windows.Forms.MessageBoxButtons buttons, System.Windows.Forms.MessageBoxIcon icon, System.Windows.Forms.MessageBoxDefaultButton defaultButton, System.Windows.Forms.MessageBoxOptions options, bool displayHelpButton)
            {
                if (Silent)
                    return System.Windows.Forms.DialogResult.None;

                return System.Windows.Forms.MessageBox.Show(text, caption, buttons, icon, defaultButton, options, displayHelpButton);
            }

            /// <summary>
            /// Displays a message box with the specified text, caption, buttons, icon, default button, options, and Help button, using the specified Help file.
            /// </summary>
            /// <param name="text">The text to display in the message box.</param>
            /// <param name="caption"> The text to display in the title bar of the message box.</param>
            /// <param name="buttons">One of the System.Windows.Forms.MessageBoxButtons values that specifies which buttons to display in the message box.</param>
            /// <param name="icon">One of the System.Windows.Forms.MessageBoxIcon values that specifies which icon to display in the message box.</param>
            /// <param name="defaultButton">One of the System.Windows.Forms.MessageBoxDefaultButton values that specifies the default button for the message box.</param>
            /// <param name="options">One of the System.Windows.Forms.MessageBoxOptions values that specifies which display and association options will be used for the message box. You may pass in 0 if you wish to use the defaults.</param>
            /// <param name="helpFilePath">The path and name of the Help file to display when the user clicks the Help button.</param>
            /// <returns>One of the System.Windows.Forms.DialogResult values.</returns>
            public static System.Windows.Forms.DialogResult Show(string text, string caption, System.Windows.Forms.MessageBoxButtons buttons, System.Windows.Forms.MessageBoxIcon icon, System.Windows.Forms.MessageBoxDefaultButton defaultButton, System.Windows.Forms.MessageBoxOptions options, string helpFilePath)
            {
                if (Silent)
                    return System.Windows.Forms.DialogResult.None;

                return System.Windows.Forms.MessageBox.Show(text, caption, buttons, icon, defaultButton, options, helpFilePath);
            }

            /// <summary>
            /// Displays a message box with the specified text, caption, buttons, icon, default button, options, and Help button, using the specified Help file.
            /// </summary>
            /// <param name="owner">An implementation of System.Windows.Forms.IWin32Window that will own the modal dialog box.</param>
            /// <param name="text">The text to display in the message box.</param>
            /// <param name="caption"> The text to display in the title bar of the message box.</param>
            /// <param name="buttons">One of the System.Windows.Forms.MessageBoxButtons values that specifies which buttons to display in the message box.</param>
            /// <param name="icon">One of the System.Windows.Forms.MessageBoxIcon values that specifies which icon to display in the message box.</param>
            /// <param name="defaultButton">One of the System.Windows.Forms.MessageBoxDefaultButton values that specifies the default button for the message box.</param>
            /// <param name="options">One of the System.Windows.Forms.MessageBoxOptions values that specifies which display and association options will be used for the message box. You may pass in 0 if you wish to use the defaults.</param>
            /// <param name="helpFilePath">The path and name of the Help file to display when the user clicks the Help button.</param>
            /// <returns>One of the System.Windows.Forms.DialogResult values.</returns>
            public static System.Windows.Forms.DialogResult Show(System.Windows.Forms.IWin32Window owner, string text, string caption, System.Windows.Forms.MessageBoxButtons buttons, System.Windows.Forms.MessageBoxIcon icon, System.Windows.Forms.MessageBoxDefaultButton defaultButton, System.Windows.Forms.MessageBoxOptions options, string helpFilePath)
            {
                if (Silent)
                    return System.Windows.Forms.DialogResult.None;

                return System.Windows.Forms.MessageBox.Show(owner, text, caption, buttons, icon, defaultButton, options, helpFilePath);
            }

            /// <summary>
            /// Displays a message box with the specified text, caption, buttons, icon, default button, options, and Help button, using the specified Help file and HelpNavigator.
            /// </summary>
            /// <param name="text">The text to display in the message box.</param>
            /// <param name="caption"> The text to display in the title bar of the message box.</param>
            /// <param name="buttons">One of the System.Windows.Forms.MessageBoxButtons values that specifies which buttons to display in the message box.</param>
            /// <param name="icon">One of the System.Windows.Forms.MessageBoxIcon values that specifies which icon to display in the message box.</param>
            /// <param name="defaultButton">One of the System.Windows.Forms.MessageBoxDefaultButton values that specifies the default button for the message box.</param>
            /// <param name="options">One of the System.Windows.Forms.MessageBoxOptions values that specifies which display and association options will be used for the message box. You may pass in 0 if you wish to use the defaults.</param>
            /// <param name="helpFilePath">The path and name of the Help file to display when the user clicks the Help button.</param>
            /// <param name="navigator">One of the System.Windows.Forms.HelpNavigator values.</param>
            /// <returns>One of the System.Windows.Forms.DialogResult values.</returns>
            public static System.Windows.Forms.DialogResult Show(string text, string caption, System.Windows.Forms.MessageBoxButtons buttons, System.Windows.Forms.MessageBoxIcon icon, System.Windows.Forms.MessageBoxDefaultButton defaultButton, System.Windows.Forms.MessageBoxOptions options, string helpFilePath, System.Windows.Forms.HelpNavigator navigator)
            {
                if (Silent)
                    return System.Windows.Forms.DialogResult.None;

                return System.Windows.Forms.MessageBox.Show(text, caption, buttons, icon, defaultButton, options, helpFilePath, navigator);
            }

            /// <summary>
            /// Displays a message box with the specified text, caption, buttons, icon, default button, options, and Help button, using the specified Help file and Help keyword.
            /// </summary>
            /// <param name="text">The text to display in the message box.</param>
            /// <param name="caption"> The text to display in the title bar of the message box.</param>
            /// <param name="buttons">One of the System.Windows.Forms.MessageBoxButtons values that specifies which buttons to display in the message box.</param>
            /// <param name="icon">One of the System.Windows.Forms.MessageBoxIcon values that specifies which icon to display in the message box.</param>
            /// <param name="defaultButton">One of the System.Windows.Forms.MessageBoxDefaultButton values that specifies the default button for the message box.</param>
            /// <param name="options">One of the System.Windows.Forms.MessageBoxOptions values that specifies which display and association options will be used for the message box. You may pass in 0 if you wish to use the defaults.</param>
            /// <param name="helpFilePath">The path and name of the Help file to display when the user clicks the Help button.</param>
            /// <param name="keyword">The Help keyword to display when the user clicks the Help button.</param>
            /// <returns>One of the System.Windows.Forms.DialogResult values.</returns>
            public static System.Windows.Forms.DialogResult Show(string text, string caption, System.Windows.Forms.MessageBoxButtons buttons, System.Windows.Forms.MessageBoxIcon icon, System.Windows.Forms.MessageBoxDefaultButton defaultButton, System.Windows.Forms.MessageBoxOptions options, string helpFilePath, string keyword)
            {
                if (Silent)
                    return System.Windows.Forms.DialogResult.None;

                return System.Windows.Forms.MessageBox.Show(text, caption, buttons, icon, defaultButton, options, helpFilePath, keyword);
            }

            /// <summary>
            /// Displays a message box with the specified text, caption, buttons, icon, default button, options, and Help button, using the specified Help file and HelpNavigator.
            /// </summary>
            /// <param name="owner">An implementation of System.Windows.Forms.IWin32Window that will own the modal dialog box.</param>
            /// <param name="text">The text to display in the message box.</param>
            /// <param name="caption"> The text to display in the title bar of the message box.</param>
            /// <param name="buttons">One of the System.Windows.Forms.MessageBoxButtons values that specifies which buttons to display in the message box.</param>
            /// <param name="icon">One of the System.Windows.Forms.MessageBoxIcon values that specifies which icon to display in the message box.</param>
            /// <param name="defaultButton">One of the System.Windows.Forms.MessageBoxDefaultButton values that specifies the default button for the message box.</param>
            /// <param name="options">One of the System.Windows.Forms.MessageBoxOptions values that specifies which display and association options will be used for the message box. You may pass in 0 if you wish to use the defaults.</param>
            /// <param name="helpFilePath">The path and name of the Help file to display when the user clicks the Help button.</param>
            /// <param name="navigator">One of the System.Windows.Forms.HelpNavigator values.</param>
            /// <returns>One of the System.Windows.Forms.DialogResult values.</returns>
            public static System.Windows.Forms.DialogResult Show(System.Windows.Forms.IWin32Window owner, string text, string caption, System.Windows.Forms.MessageBoxButtons buttons, System.Windows.Forms.MessageBoxIcon icon, System.Windows.Forms.MessageBoxDefaultButton defaultButton, System.Windows.Forms.MessageBoxOptions options, string helpFilePath, System.Windows.Forms.HelpNavigator navigator)
            {
                if (Silent)
                    return System.Windows.Forms.DialogResult.None;

                return System.Windows.Forms.MessageBox.Show(owner, text, caption, buttons, icon, defaultButton, options, helpFilePath, navigator);
            }

            /// <summary>
            /// Displays a message box with the specified text, caption, buttons, icon, default button, options, and Help button, using the specified Help file and Help keyword.
            /// </summary>
            /// <param name="owner">An implementation of System.Windows.Forms.IWin32Window that will own the modal dialog box.</param>
            /// <param name="text">The text to display in the message box.</param>
            /// <param name="caption"> The text to display in the title bar of the message box.</param>
            /// <param name="buttons">One of the System.Windows.Forms.MessageBoxButtons values that specifies which buttons to display in the message box.</param>
            /// <param name="icon">One of the System.Windows.Forms.MessageBoxIcon values that specifies which icon to display in the message box.</param>
            /// <param name="defaultButton">One of the System.Windows.Forms.MessageBoxDefaultButton values that specifies the default button for the message box.</param>
            /// <param name="options">One of the System.Windows.Forms.MessageBoxOptions values that specifies which display and association options will be used for the message box. You may pass in 0 if you wish to use the defaults.</param>
            /// <param name="helpFilePath">The path and name of the Help file to display when the user clicks the Help button.</param>
            /// <param name="keyword">The Help keyword to display when the user clicks the Help button.</param>
            /// <returns>One of the System.Windows.Forms.DialogResult values.</returns>
            public static System.Windows.Forms.DialogResult Show(System.Windows.Forms.IWin32Window owner, string text, string caption, System.Windows.Forms.MessageBoxButtons buttons, System.Windows.Forms.MessageBoxIcon icon, System.Windows.Forms.MessageBoxDefaultButton defaultButton, System.Windows.Forms.MessageBoxOptions options, string helpFilePath, string keyword)
            {
                if (Silent)
                    return System.Windows.Forms.DialogResult.None;

                return System.Windows.Forms.MessageBox.Show(owner, text, caption, buttons, icon, defaultButton, options, helpFilePath, keyword);
            }

            /// <summary>
            /// Displays a message box with the specified text, caption, buttons, icon, default button, options, and Help button, using the specified Help file, HelpNavigator, and Help topic.
            /// </summary>
            /// <param name="text">The text to display in the message box.</param>
            /// <param name="caption"> The text to display in the title bar of the message box.</param>
            /// <param name="buttons">One of the System.Windows.Forms.MessageBoxButtons values that specifies which buttons to display in the message box.</param>
            /// <param name="icon">One of the System.Windows.Forms.MessageBoxIcon values that specifies which icon to display in the message box.</param>
            /// <param name="defaultButton">One of the System.Windows.Forms.MessageBoxDefaultButton values that specifies the default button for the message box.</param>
            /// <param name="options">One of the System.Windows.Forms.MessageBoxOptions values that specifies which display and association options will be used for the message box. You may pass in 0 if you wish to use the defaults.</param>
            /// <param name="helpFilePath">The path and name of the Help file to display when the user clicks the Help button.</param>
            /// <param name="navigator">One of the System.Windows.Forms.HelpNavigator values.</param>
            /// <param name="param">The numeric ID of the Help topic to display when the user clicks the Help button.</param>
            /// <returns>One of the System.Windows.Forms.DialogResult values.</returns>
            public static System.Windows.Forms.DialogResult Show(string text, string caption, System.Windows.Forms.MessageBoxButtons buttons, System.Windows.Forms.MessageBoxIcon icon, System.Windows.Forms.MessageBoxDefaultButton defaultButton, System.Windows.Forms.MessageBoxOptions options, string helpFilePath, System.Windows.Forms.HelpNavigator navigator, object param)
            {
                if (Silent)
                    return System.Windows.Forms.DialogResult.None;

                return System.Windows.Forms.MessageBox.Show(text, caption, buttons, icon, defaultButton, options, helpFilePath, navigator, param);
            }

            /// <summary>
            /// Displays a message box with the specified text, caption, buttons, icon, default button, options, and Help button, using the specified Help file, HelpNavigator, and Help topic
            /// </summary>
            /// <param name="owner">An implementation of System.Windows.Forms.IWin32Window that will own the modal dialog box.</param>
            /// <param name="text">The text to display in the message box.</param>
            /// <param name="caption"> The text to display in the title bar of the message box.</param>
            /// <param name="buttons">One of the System.Windows.Forms.MessageBoxButtons values that specifies which buttons to display in the message box.</param>
            /// <param name="icon">One of the System.Windows.Forms.MessageBoxIcon values that specifies which icon to display in the message box.</param>
            /// <param name="defaultButton">One of the System.Windows.Forms.MessageBoxDefaultButton values that specifies the default button for the message box.</param>
            /// <param name="options">One of the System.Windows.Forms.MessageBoxOptions values that specifies which display and association options will be used for the message box. You may pass in 0 if you wish to use the defaults.</param>
            /// <param name="helpFilePath">The path and name of the Help file to display when the user clicks the Help button.</param>
            /// <param name="navigator">One of the System.Windows.Forms.HelpNavigator values.</param>
            /// <param name="param">The numeric ID of the Help topic to display when the user clicks the Help button.</param>
            /// <returns>One of the System.Windows.Forms.DialogResult values.</returns>
            public static System.Windows.Forms.DialogResult Show(System.Windows.Forms.IWin32Window owner, string text, string caption, System.Windows.Forms.MessageBoxButtons buttons, System.Windows.Forms.MessageBoxIcon icon, System.Windows.Forms.MessageBoxDefaultButton defaultButton, System.Windows.Forms.MessageBoxOptions options, string helpFilePath, System.Windows.Forms.HelpNavigator navigator, object param)
            {
                if (Silent)
                    return System.Windows.Forms.DialogResult.None;

                return System.Windows.Forms.MessageBox.Show(owner, text, caption, buttons, icon, defaultButton, options, helpFilePath, navigator, param);
            }
        }

        #endregion

        #region Other Dialogs

        /// <summary>
        /// Select a filepath by showing a dialog to the user.
        /// </summary>
        /// <param name="text">Explaining text in the dialog.</param>
        /// <returns>The filepath of the selected file.</returns>
        public static string SelectFileOpen(string text)
        {
            return SelectFileOpen(text, null, null);
        }

        /// <summary>
        /// Select a filepath by showing a dialog to the user.
        /// </summary>
        /// <param name="text">Explaining text in the dialog.</param>
        /// <param name="subDirectory">Starting subdirectory of the project directory path.</param>
        /// <param name="extension">Extension of the file sought for.</param>
        /// <returns>The selected filepath.</returns>
        public static string SelectFileOpen(string text, string subDirectory, string extension)
        {
            if (Silent)
                return null;
            if (System.Threading.Thread.CurrentThread.GetApartmentState() != System.Threading.ApartmentState.STA)
                return null;

            System.Windows.Forms.OpenFileDialog dialog = new System.Windows.Forms.OpenFileDialog();
            dialog.Title = text;
            dialog.InitialDirectory = Script.Project.WorkingDirName != null ? Script.Project.WorkingDirName + subDirectory : @"C:\Etricc 5.0.0\";
            dialog.CheckFileExists = true;
            dialog.RestoreDirectory = true;
            if (extension != null)
                dialog.Filter = string.Format("Specific Files (*{0})|*{0}|All Files (*.*)|*.*", extension);

            System.Windows.Forms.DialogResult result = System.Windows.Forms.DialogResult.None;
            do
            {
                result = dialog.ShowDialog();
                if (result != System.Windows.Forms.DialogResult.OK)
                    result = Dialog.MessageBox.Show("No file was selected. What do you want to do?", string.Empty, System.Windows.Forms.MessageBoxButtons.AbortRetryIgnore);
            }
            while (result == System.Windows.Forms.DialogResult.Retry);

            if (result == System.Windows.Forms.DialogResult.Abort)
                Script.Abort();
            if (result == System.Windows.Forms.DialogResult.OK)
                return dialog.FileName;
            return null;
        }

        /// <summary>
        /// Select a filepath by showing a dialog to the user.
        /// </summary>
        /// <param name="text">Explaining text in the dialog.</param>
        /// <param name="subDirectory">Starting subdirectory of the project directory path.</param>
        /// <param name="extension">>Extension of the file being saved.</param>
        /// <returns>The selected filepath.</returns>
        public static string SelectFileSave(string text, string subDirectory, string extension)
        {
            if (Silent)
                return null;
            if (System.Threading.Thread.CurrentThread.GetApartmentState() != System.Threading.ApartmentState.STA)
                return null;

            System.Windows.Forms.SaveFileDialog dialog = new System.Windows.Forms.SaveFileDialog();
            dialog.Title = text;
            dialog.RestoreDirectory = true;
            dialog.InitialDirectory = Script.Project.WorkingDirName != null ? Script.Project.WorkingDirName + subDirectory : @"C:\Etricc 5.0.0\";
            if (extension != null)
                dialog.Filter = string.Format("Specific Files (*{0})|*{0}|All Files (*.*)|*.*", extension);

            System.Windows.Forms.DialogResult result = System.Windows.Forms.DialogResult.None;
            do
            {
                result = dialog.ShowDialog();
                if (result != System.Windows.Forms.DialogResult.OK)
                    result = Dialog.MessageBox.Show("No file was selected. What do you want to do?", string.Empty, System.Windows.Forms.MessageBoxButtons.AbortRetryIgnore);
            }
            while (result == System.Windows.Forms.DialogResult.Retry);

            if (result == System.Windows.Forms.DialogResult.Abort)
                Script.Abort();
            if (result == System.Windows.Forms.DialogResult.OK)
                return dialog.FileName;
            return null;
        }

        /// <summary>
        /// Select a directory by showing a dialog to the user.
        /// </summary>
        /// <param name="text">Explaining text in the dialog.</param>
        /// <returns>The seleced directoy path.</returns>
        public static string SelectDirectory(string text)
        {
            if (Silent)
                return null;
            if (System.Threading.Thread.CurrentThread.GetApartmentState() != System.Threading.ApartmentState.STA)
                return null;

            System.Windows.Forms.FolderBrowserDialog dialog = new System.Windows.Forms.FolderBrowserDialog();
            dialog.RootFolder = Environment.SpecialFolder.MyComputer;
            dialog.Description = text;
            dialog.SelectedPath = string.IsNullOrEmpty(Script.Project.WorkingDirName) ? @"C:\Etricc 5.0.0\" : Script.Project.WorkingDir.FullName;

            System.Windows.Forms.DialogResult result = System.Windows.Forms.DialogResult.None;
            do
            {
                result = dialog.ShowDialog();
                if (result != System.Windows.Forms.DialogResult.OK)
                    result = Dialog.MessageBox.Show("No directory was selected. What do you want to do?", string.Empty, System.Windows.Forms.MessageBoxButtons.AbortRetryIgnore);
            }
            while (result == System.Windows.Forms.DialogResult.Retry);

            if (result == System.Windows.Forms.DialogResult.Abort)
                Script.Abort();
            if (result == System.Windows.Forms.DialogResult.OK)
                return dialog.SelectedPath;
            return null;
        }

        #endregion

    } 
}