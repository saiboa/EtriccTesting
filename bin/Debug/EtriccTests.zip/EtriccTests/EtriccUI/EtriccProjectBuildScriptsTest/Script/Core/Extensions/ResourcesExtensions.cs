﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace Egemin.Etricc.Scripts.Core
{
    public static class ResourcesExtensions
    {
        /// <summary>
        /// Adds a new AGV type to the AGV types collection. 
        /// </summary>
        /// <param name="id">AGV type ID.</param>
        /// <param name="filePath">AGV drawing file path.</param>
        /// <param name="controllerType">AGV controller Type.</param>
        /// <param name="connectionType">AGV connection Type.</param>
        /// <returns>The created AGV type.</returns>
        public static Egemin.EPIA.WCS.Resources.AgvType InsertAgvType(this Egemin.EPIA.WCS.Resources.AgvTypes agvTypes, string id, string filePath, Egemin.EPIA.WCS.Resources.Controller.TYPE controllerType, Egemin.EPIA.Communication.Connection.TYPE connectionType)
        {
            return agvTypes.InsertAgvType(id, filePath, controllerType, connectionType, 0, 0, 0, OPERATORLANGUAGE.EN, false);
        }

        /// <summary>
        /// Adds a new AGV type to the AGV types collection. 
        /// </summary>
        /// <param name="id">AGV type ID.</param>
        /// <param name="filePath">AGV drawing file path.</param>
        /// <param name="backwardOffset">AGV backward offset.</param>
        /// <param name="wheelBase">AGV wheelbase.</param>
        /// <param name="carrierOffset">AGV carrier offset.</param>
        /// <param name="operatorLanguage">AGV operator language.</param>
        /// <param name="opportunityCharge">Opportunity charge.</param>
        /// <returns>The created AGV type.</returns>
        public static Egemin.EPIA.WCS.Resources.AgvType InsertAgvType(this Egemin.EPIA.WCS.Resources.AgvTypes agvTypes, string id, string filePath, int backwardOffset, int wheelBase, int carrierOffset, string operatorLanguage, bool opportunityCharge)
        {
            return agvTypes.InsertAgvType(id, filePath, Egemin.EPIA.WCS.Resources.Controller.TYPE.ENSOR_IPC1, Egemin.EPIA.Communication.Connection.TYPE.TCP, backwardOffset, wheelBase, carrierOffset, operatorLanguage, opportunityCharge);
        }

        /// <summary>
        /// Adds a new AGV type to the AGV types collection. 
        /// </summary>
        /// <param name="agvTypes">Agv types collection.</param>
        /// <param name="id">AGV type ID.</param>
        /// <param name="filePath">AGV drawing file path.</param>
        /// <param name="controllerType">AGV controller Type.</param>
        /// <param name="connectionType">AGV connection Type.</param>
        /// <param name="backwardOffset">AGV backward offset.</param>
        /// <param name="wheelBase">AGV wheelbase.</param>
        /// <param name="operatorLanguage">AGV operator language.</param>
        /// <param name="opportunityCharge">Opportunity charge.</param>
        /// <returns>The created AGV type.</returns>
        public static Egemin.EPIA.WCS.Resources.AgvType InsertAgvType(this Egemin.EPIA.WCS.Resources.AgvTypes agvTypes, string id, string filePath, Egemin.EPIA.WCS.Resources.Controller.TYPE controllerType, Egemin.EPIA.Communication.Connection.TYPE connectionType, int backwardOffset, int wheelBase, string operatorLanguage, bool opportunityCharge)
        {
            Dialog.SetProgress("AgvTypes", string.Format("Inserting VehicleType : {0}", id));

            Egemin.EPIA.WCS.Resources.AgvType agvType = new Egemin.EPIA.WCS.Resources.AgvType(id);

            // properties
            agvType.BackwardOffset = backwardOffset;
            agvType.Wheelbase = wheelBase;
            agvType.Controller.Type = controllerType;
            agvType.Protocol.Connection.Type = connectionType;

            // drawing
            agvType.Reset();
            agvType.Drawings.InsertDrawing(id, filePath);

            // parameters
            agvType.Parameters[Egemin.EPIA.WCS.Resources.AgvType.IMAGE_LAYER].ValueAsString = "ENSOR_VISUAL_VEHICLE";
            agvType.Parameters[Egemin.EPIA.WCS.Resources.AgvType.OPERATOR_LANGUAGE].ValueAsString = operatorLanguage;
            agvType.Parameters[Egemin.EPIA.WCS.Resources.AgvType.OPERATOR_DISPLAY_NR_OF_LINES].ValueAsInt = 3;
            agvType.Parameters[Egemin.EPIA.WCS.Resources.AgvType.OPERATOR_DISPLAY_ALTERNATING_PERIOD].ValueAsInt = 4;
            agvType.Parameters[Egemin.EPIA.WCS.Resources.AgvType.LOCK_AHEAD_DISTANCE].ValueAsInt = 7000;
            agvType.Parameters[Egemin.EPIA.WCS.Resources.AgvType.LOCK_DYNAMIC].ValueAsBool = true;
            agvType.Parameters[Egemin.EPIA.WCS.Resources.AgvType.LOCK_RELEASE_DISTANCE].ValueAsBool = true;
            agvType.Parameters[Egemin.EPIA.WCS.Resources.AgvType.OPPORTUNITY_CHARGE].ValueAsBool = opportunityCharge;
            agvType.Parameters[Egemin.EPIA.WCS.Resources.AgvType.BUMP_ENABLE].ValueAsBool = true;
            agvType.Parameters[Egemin.EPIA.WCS.Resources.AgvType.DYNAMIC_ROUTING].ValueAsBool = true;
            agvType.Parameters[Egemin.EPIA.WCS.Resources.AgvType.DYNAMIC_ROUTING_MODE].ValueAsString = "not_found_only";

            // save areas
            //agvType.Parameters[Egemin.EPIA.WCS.Resources.AgvType.SAVEAREA_LOADID_VEHICLE].ValueAsInt = 1;
            //agvType.Parameters[Egemin.EPIA.WCS.Resources.AgvType.SAVEAREA_LOADID_ORDER].ValueAsInt = 2;
            //agvType.Parameters[Egemin.EPIA.WCS.Resources.AgvType.SAVEAREA_JOB_ARGUMENTS].ValueAsInt = 3;
            agvType.Parameters[Egemin.EPIA.WCS.Resources.AgvType.SAVEAREA_CHANGE_LOG].ValueAsInt = 4;
            //agvType.Parameters[Egemin.EPIA.WCS.Resources.AgvType.SAVEAREA_LOAD_TYPE].ValueAsInt = 5;
            //agvType.Parameters[Egemin.EPIA.WCS.Resources.AgvType.SAVEAREA_POSITION_OFFSET].ValueAsInt = 6;
            //agvType.Parameters[Egemin.EPIA.WCS.Resources.AgvType.SAVEAREA_JOB_COMMENTS].ValueAsInt = 7;
            //agvType.Parameters[Egemin.EPIA.WCS.Resources.AgvType.SAVEAREA_POSITION_HEIGHT].ValueAsInt = 8;
            //agvType.Parameters[Egemin.EPIA.WCS.Resources.AgvType.SAVEAREA_SPEED_INDEX].ValueAsInt = 9;
            //agvType.Parameters[Egemin.EPIA.WCS.Resources.AgvType.SAVEAREA_LOAD_TYPE_ARGS].ValueAsInt = 10;
            //agvType.Parameters[Egemin.EPIA.WCS.Resources.AgvType.SAVEAREA_LOAD_WEIGHT].ValueAsInt = 11;
            //agvType.Parameters[Egemin.EPIA.WCS.Resources.AgvType.SAVEAREA_LOAD_DIMENSIONS].ValueAsInt = 12;
            //agvType.Parameters[Egemin.EPIA.WCS.Resources.AgvType.SAVEAREA_LOAD_ARGS].ValueAsInt = 13;
            //agvType.Parameters[Egemin.EPIA.WCS.Resources.AgvType.SAVEAREA_LOCATION_DIMENSIONS].ValueAsInt = 14;
            //agvType.Parameters[Egemin.EPIA.WCS.Resources.AgvType.SAVEAREA_LOCATION_CURRENT_SPACE].ValueAsInt = 15;

            return agvTypes.Insert(agvType, true) as Egemin.EPIA.WCS.Resources.AgvType;
        }

        /// <summary>
        /// Adds a new AGV type to the AGV types collection. 
        /// </summary>
        /// <param name="agvTypes">Agv types collection.</param>
        /// <param name="id">AGV type ID.</param>
        /// <param name="filePath">AGV drawing file path.</param>
        /// <param name="controllerType">AGV controller Type.</param>
        /// <param name="connectionType">AGV connection Type.</param>
        /// <param name="backwardOffset">AGV backward offset.</param>
        /// <param name="wheelBase">AGV wheelbase.</param>
        /// <param name="carrierOffset">AGV carrier offset.</param>
        /// <param name="operatorLanguage">AGV operator language.</param>
        /// <param name="opportunityCharge">Opportunity charge.</param>
        /// <returns>The created AGV type.</returns>
        public static Egemin.EPIA.WCS.Resources.AgvType InsertAgvType(this Egemin.EPIA.WCS.Resources.AgvTypes agvTypes, string id, string filePath, Egemin.EPIA.WCS.Resources.Controller.TYPE controllerType, Egemin.EPIA.Communication.Connection.TYPE connectionType, int backwardOffset, int wheelBase, int carrierOffset, string operatorLanguage, bool opportunityCharge)
        {
            Dialog.SetProgress("AgvTypes", string.Format("Inserting VehicleType : {0}", id));

            Egemin.EPIA.WCS.Resources.AgvType agvType = new Egemin.EPIA.WCS.Resources.AgvType(id);

            // properties
            agvType.BackwardOffset = backwardOffset;
            agvType.Wheelbase = wheelBase;
            agvType.Controller.Type = controllerType;
            agvType.Protocol.Connection.Type = connectionType;

            // drawing
            agvType.Reset();
            agvType.Drawings.InsertDrawing(id, filePath);

            // carrier
            agvType.Carriers.InsertCarrier(1, carrierOffset, 0);

            // parameters
            agvType.Parameters[Egemin.EPIA.WCS.Resources.AgvType.IMAGE_LAYER].ValueAsString = "ENSOR_VISUAL_VEHICLE";
            agvType.Parameters[Egemin.EPIA.WCS.Resources.AgvType.OPERATOR_LANGUAGE].ValueAsString = operatorLanguage;
            agvType.Parameters[Egemin.EPIA.WCS.Resources.AgvType.OPERATOR_DISPLAY_NR_OF_LINES].ValueAsInt = 3;
            agvType.Parameters[Egemin.EPIA.WCS.Resources.AgvType.OPERATOR_DISPLAY_ALTERNATING_PERIOD].ValueAsInt = 4;
            agvType.Parameters[Egemin.EPIA.WCS.Resources.AgvType.LOCK_AHEAD_DISTANCE].ValueAsInt = 7000;
            agvType.Parameters[Egemin.EPIA.WCS.Resources.AgvType.LOCK_DYNAMIC].ValueAsBool = true;
            agvType.Parameters[Egemin.EPIA.WCS.Resources.AgvType.LOCK_RELEASE_DISTANCE].ValueAsBool = true;
            agvType.Parameters[Egemin.EPIA.WCS.Resources.AgvType.OPPORTUNITY_CHARGE].ValueAsBool = opportunityCharge;
            agvType.Parameters[Egemin.EPIA.WCS.Resources.AgvType.BUMP_ENABLE].ValueAsBool = true;
            agvType.Parameters[Egemin.EPIA.WCS.Resources.AgvType.DYNAMIC_ROUTING].ValueAsBool = true;
            agvType.Parameters[Egemin.EPIA.WCS.Resources.AgvType.DYNAMIC_ROUTING_MODE].ValueAsString = "not_found_only";

            // save areas
            //agvType.Parameters[Egemin.EPIA.WCS.Resources.AgvType.SAVEAREA_LOADID_VEHICLE].ValueAsInt = 1;
            //agvType.Parameters[Egemin.EPIA.WCS.Resources.AgvType.SAVEAREA_LOADID_ORDER].ValueAsInt = 2;
            //agvType.Parameters[Egemin.EPIA.WCS.Resources.AgvType.SAVEAREA_JOB_ARGUMENTS].ValueAsInt = 3;
            agvType.Parameters[Egemin.EPIA.WCS.Resources.AgvType.SAVEAREA_CHANGE_LOG].ValueAsInt = 4;
            //agvType.Parameters[Egemin.EPIA.WCS.Resources.AgvType.SAVEAREA_LOAD_TYPE].ValueAsInt = 5;
            //agvType.Parameters[Egemin.EPIA.WCS.Resources.AgvType.SAVEAREA_POSITION_OFFSET].ValueAsInt = 6;
            //agvType.Parameters[Egemin.EPIA.WCS.Resources.AgvType.SAVEAREA_JOB_COMMENTS].ValueAsInt = 7;
            //agvType.Parameters[Egemin.EPIA.WCS.Resources.AgvType.SAVEAREA_POSITION_HEIGHT].ValueAsInt = 8;
            //agvType.Parameters[Egemin.EPIA.WCS.Resources.AgvType.SAVEAREA_SPEED_INDEX].ValueAsInt = 9;
            //agvType.Parameters[Egemin.EPIA.WCS.Resources.AgvType.SAVEAREA_LOAD_TYPE_ARGS].ValueAsInt = 10;
            //agvType.Parameters[Egemin.EPIA.WCS.Resources.AgvType.SAVEAREA_LOAD_WEIGHT].ValueAsInt = 11;
            //agvType.Parameters[Egemin.EPIA.WCS.Resources.AgvType.SAVEAREA_LOAD_DIMENSIONS].ValueAsInt = 12;
            //agvType.Parameters[Egemin.EPIA.WCS.Resources.AgvType.SAVEAREA_LOAD_ARGS].ValueAsInt = 13;
            //agvType.Parameters[Egemin.EPIA.WCS.Resources.AgvType.SAVEAREA_LOCATION_DIMENSIONS].ValueAsInt = 14;
            //agvType.Parameters[Egemin.EPIA.WCS.Resources.AgvType.SAVEAREA_LOCATION_CURRENT_SPACE].ValueAsInt = 15;

            switch (controllerType)
            {
                case Egemin.EPIA.WCS.Resources.Controller.TYPE.ENSOR_IPC1:
                case Egemin.EPIA.WCS.Resources.Controller.TYPE.ENSOR_IPC2:
                    agvType.Parameters[Egemin.EPIA.WCS.Resources.AgvType.LOCK_DYNAMIC].ValueAsBool = true;
                    agvType.Parameters[Egemin.EPIA.WCS.Resources.AgvType.LOCK_AHEAD].ValueAsInt = 0;
                    agvType.Parameters[Egemin.EPIA.WCS.Resources.AgvType.LOCK_AHEAD_DISTANCE].ValueAsInt = 7000;
                    break;

                default:
                    agvType.Parameters[Egemin.EPIA.WCS.Resources.AgvType.LOCK_DYNAMIC].ValueAsBool = false;
                    agvType.Parameters[Egemin.EPIA.WCS.Resources.AgvType.LOCK_AHEAD].ValueAsInt = 3;
                    agvType.Parameters[Egemin.EPIA.WCS.Resources.AgvType.LOCK_AHEAD_DISTANCE].ValueAsInt = 0;
                    break;
            }

            return agvTypes.Insert(agvType, true) as Egemin.EPIA.WCS.Resources.AgvType;
        }

        /// <summary>
        /// Adds a new carrier to the carrier collection.
        /// </summary>
        /// <param name="carries">Carrier collection.</param>
        /// <param name="id">Carrier ID.</param>
        /// <param name="xPos">Carrier X offset.</param>
        /// <param name="yPos">Carrier Y offset.</param>
        /// <returns>the created carrier.</returns>
        public static Egemin.EPIA.WCS.Resources.Carrier InsertCarrier(this Egemin.EPIA.WCS.Resources.Carriers carriers, object id, int xPos, int yPos)
        {
            Dialog.SetProgress("Carriers", string.Format("Inserting Carrier : {0}", id));

            Egemin.EPIA.WCS.Resources.Carrier carrier = new Egemin.EPIA.WCS.Resources.Carrier(id);

            // properties
            carrier.Position.Xpos = xPos;
            carrier.Position.Ypos = yPos;

            return carriers.Insert(carrier, true) as Egemin.EPIA.WCS.Resources.Carrier;
        }

        /// <summary>
        /// Adds an AGV to the AGV collcetion.
        /// </summary>
        /// <param name="agvs">AGV collection.</param>
        /// <param name="id">AGV ID.</param>
        /// <param name="typeID">AGV type ID.</param>
        /// <param name="address">Unique AGV address.</param>
        /// <param name="connectionAddress">AGV IP address.</param>
        /// <returns>The created AGV.</returns>
        public static Egemin.EPIA.WCS.Resources.Agv InsertAgv(this Egemin.EPIA.WCS.Resources.Agvs agvs, string id, object typeID, int address, string connectionAddress)
        {
            return agvs.InsertAgv(id, typeID, address, connectionAddress, null, null, null);
        }

        /// <summary>
        /// Adds an AGV to the AGV collection.
        /// </summary>
        /// <param name="agvs">AGV collection.</param>
        /// <param name="id">AGV ID.</param>
        /// <param name="typeID">AGV type ID.</param>
        /// <param name="address">Unique AGV address.</param>
        /// <param name="connectionAddress">AGV IP address.</param>
        /// <returns>The created AGV.</returns>
        public static Egemin.EPIA.WCS.Resources.Agv InsertAgv(this Egemin.EPIA.WCS.Resources.Agvs agvs, string id, object typeID, int address, string connectionAddress, object fixedParkLocationID, object fixedBattLocationID, object fixedRetireLocationID)
        {
            Dialog.SetProgress("Agvs", string.Format("Inserting Vehicle : {0}", id));

            Egemin.EPIA.WCS.Resources.Agv agv = new Egemin.EPIA.WCS.Resources.Agv(id);

            // input validation
            if (!Script.Project.AgvTypes.Contains(typeID))
                throw new ArgumentOutOfRangeException("typeID");

            Egemin.EPIA.WCS.Resources.AgvType agvType = Script.Project.AgvTypes[typeID];
            if (agvType.Protocol.Connection.Type == Egemin.EPIA.Communication.Connection.TYPE.TCP || agvType.Protocol.Connection.Type == Egemin.EPIA.Communication.Connection.TYPE.UDP)
                if (connectionAddress.IndexOf(':') < 0)
                    connectionAddress += ":8888";

            // properties
            agv.TypeID = typeID;
            agv.SimFieldControl = true;
            agv.Protocol.Address = address.ToString();
            agv.Protocol.Connection.Address = connectionAddress;
            agv.SimTrunk = 100 * address;
            agv.FixedBattLocationID = fixedBattLocationID;
            agv.FixedParkLocationID = fixedParkLocationID;
            agv.FixedRetireLocationID = fixedRetireLocationID;
            agv.Mode = Egemin.EPIA.WCS.Resources.Mover.MODE.AUTOMATIC;
            agv.LogLevel = Egemin.EPIA.Core.Definitions.Message.SEVERITY.INFO;

            return agvs.Insert(agv, true) as Egemin.EPIA.WCS.Resources.Agv;
        }

        /// <summary>
        /// Calculates a good spreading for agvs.
        /// </summary>
        /// <param name="agvs">AGV collection.</param>
        public static void CalculateSimTrunks(this Egemin.EPIA.WCS.Resources.Agvs agvs)
        {
            int segments = agvs.Count + 1;

            foreach (Egemin.EPIA.WCS.Resources.Agv agv in agvs)
            {
                Egemin.EPIA.WCS.Layouting.Layout layout = Script.Project.GetLayout(agv);
                if (layout == null)
                    continue;

                int agvIndex = agvs.GetIndex(agv) + 1;
                int totalTrunks = layout.NextTrunk() - 1;
                int simTrunk = agvIndex * totalTrunks / segments;

                if (simTrunk <= 0)
                    continue;

                agv.SimTrunk = simTrunk;
            }
        }

        /// <summary>
        /// Finds the next trunk number for a layout.
        /// </summary>
        /// <param name="layout">Layout.</param>
        /// <returns>The next trunk number.</returns>
        public static int NextTrunk(this Egemin.EPIA.WCS.Layouting.Layout layout)
        {
            if (layout == null)
                return 0;
            if (layout.Nodes.NextTrunk > 1)
                return layout.Nodes.NextTrunk;

            foreach (Egemin.EPIA.WCS.Layouting.Node node in layout.Nodes)
                if (node.Trunk >= layout.Nodes.NextTrunk)
                    layout.Nodes.NextTrunk = node.Trunk + 1;

            return layout.Nodes.NextTrunk;
        }
    } 
}