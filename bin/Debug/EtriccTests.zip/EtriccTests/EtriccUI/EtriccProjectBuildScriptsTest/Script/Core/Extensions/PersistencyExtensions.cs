﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Egemin.Etricc.Scripts.Core
{
    public static class PersistencyExtensions
    {

        /// <summary>
        /// Deserializes the project from an xml file.
        /// </summary>
        /// <param name="project">Project.</param>
        /// <param name="filePath">The filepath of the xml file.</param>
        public static Egemin.EPIA.WCS.Core.Project LoadXml(this Egemin.EPIA.WCS.Core.Project project, string filePath)
        {
            return Egemin.EPIA.BaseContext.LoadXml(new System.IO.FileInfo(filePath), typeof(Egemin.EPIA.WCS.Core.Project)) as Egemin.EPIA.WCS.Core.Project;
        }

        /// <summary>
        /// Serializes the project to an xml file.
        /// </summary>
        /// <param name="project">Project.</param>
        /// <param name="filePath">The filepath of the xml file.</param>
        public static void SaveXml(this Egemin.EPIA.WCS.Core.Project project, string filePath)
        {
            if (filePath == null)
            {
                string targetDir = ScriptContext.XmlDirectory ?? project.WorkingDirName + @"\\Data\\Xml\\";
                string targetName = project.Name + (project.Simulation ? "_Simulation" : string.Empty);
                filePath = string.Format("{0}\\{1}{2}", targetDir, targetName, EXTENSION.XML);
            }

            ((Egemin.EPIA.BaseContext)project).SaveXml(filePath);
            ScriptContext.AddTargetFile(filePath);
        }

        /// <summary>
        /// Serializes the project to a standard xml file.
        /// </summary>
        /// <param name="project">Project.</param>
        public static void SaveXmlWithDefaultName(this Egemin.EPIA.WCS.Core.Project project)
        {
            string filePath = Dialog.SelectFileSave("Save the project to file.", @"\Data\Xml\", EXTENSION.XML);
            project.SaveXml(filePath);
        }


        /// <summary>
        /// Serializes an object to an xml file.
        /// </summary>
        /// <param name="baseContext">The object to save.</param>
        /// <param name="filePath">The filepath of the xml file.</param>
        public static void SaveXml(this Egemin.EPIA.BaseContext baseContext, string filePath)
        {
            System.IO.FileInfo fileInfo = new System.IO.FileInfo(filePath);

            Dialog.SetProgress(null, string.Format("Saving to xml : {0}", fileInfo.FullName));

            if (baseContext is Egemin.EPIA.WCS.Core.Project)
                ((Egemin.EPIA.WCS.Core.Project)baseContext).SetDirectories(fileInfo);
            Egemin.EPIA.BaseContext.SaveXml(fileInfo, baseContext);
        }

        /// <summary>
        /// Adds a runtime database serializer to the runtime db serializer collection.
        /// </summary>
        /// <param name="id">Runtime database database ID.</param>
        /// <param name="connectionString">Connection string used to contact the database.</param>
        /// <returns>The created runtime database erializer.</returns>
        public static Egemin.EPIA.Data.Serialization.RuntimeDbSerializer InsertRuntimeDbSerializer(this Egemin.EPIA.Data.Serialization.RuntimeDbSerializers runtimeDbSerializers, string id, string connectionString)
        {
            Egemin.EPIA.Data.Serialization.RuntimeDbSerializer runtimeDbSerializer = new Egemin.EPIA.Data.Serialization.RuntimeDbSerializer();

            // properties
            runtimeDbSerializer.ID = id;
            runtimeDbSerializer.CommandTimeout = 30;
            runtimeDbSerializer.OleDbConnectionString.ConnectionString = connectionString;

            return runtimeDbSerializers.Insert(runtimeDbSerializer, true) as Egemin.EPIA.Data.Serialization.RuntimeDbSerializer;
        }

        /// <summary>
        /// Prepares an object for database persistency.
        /// </summary>
        /// <param name="baseContext">The object that is made persistent.</param>
        public static void SetRuntimeDbSerializing(this Egemin.EPIA.BaseContext baseContext)
        {
            baseContext.SetRuntimeDbSerializing(null);
        }

        /// <summary>
        /// Prepares an object for database persistency.
        /// </summary>
        /// <param name="baseContext">The object that is made persistent.</param>
        /// <param name="runtimeDbSerializerID">Runtime database serializer ID.</param>
        public static void SetRuntimeDbSerializing(this Egemin.EPIA.BaseContext baseContext, object runtimeDbSerializerID)
        {
            if (runtimeDbSerializerID == null)
                runtimeDbSerializerID = Script.Project.RuntimeDbSerializers.GetAllKeyIDs().First;

            baseContext.RuntimeDbSerializerID = runtimeDbSerializerID;
            baseContext.SetRuntimeDbSerializerID();
            baseContext.SetRuntimeDbSerializing();
        }

        /// <summary>
        /// Prepares the default objects for database persistency.
        /// </summary>
        public static void SetRuntimeDbSerializingDefault(this Egemin.EPIA.WCS.Core.Project project)
        {
            project.SetRuntimeDbSerializingDefault(null);
        }

        /// <summary>
        /// Prepares the default objects for database persistency.
        /// </summary>
        /// <param name="runtimeDbSerializerID">Runtime database serializer ID.</param>
        public static void SetRuntimeDbSerializingDefault(this Egemin.EPIA.WCS.Core.Project project, string runtimeDbSerializerID)
        {
            if (runtimeDbSerializerID == null)
                runtimeDbSerializerID = project.RuntimeDbSerializers.GetAllKeyIDs().FirstAsString;

            foreach (Egemin.EPIA.WCS.Resources.Agv agv in project.Agvs)
            {
                agv.Carriers.SetRuntimeDbSerializing(runtimeDbSerializerID);
                agv.Jobs.SetRuntimeDbSerializing(runtimeDbSerializerID);
                agv.BatteryChargePlan.SetRuntimeDbSerializing(runtimeDbSerializerID);
                agv.CalibrationPlan.SetRuntimeDbSerializing(runtimeDbSerializerID);
            }

            project.AgvTypes.SetRuntimeDbSerializing(runtimeDbSerializerID);
            project.Alarms.SetRuntimeDbSerializing(runtimeDbSerializerID);
            project.Facilities.SetRuntimeDbSerializing(runtimeDbSerializerID);
            project.Groups.SetRuntimeDbSerializing(runtimeDbSerializerID);
            project.HostPorts.SetRuntimeDbSerializing(runtimeDbSerializerID);
            project.Loads.SetRuntimeDbSerializing(runtimeDbSerializerID);
            project.Locations.SetRuntimeDbSerializing(runtimeDbSerializerID);
            project.Processes.SetRuntimeDbSerializing(runtimeDbSerializerID);
            project.Stations.SetRuntimeDbSerializing(runtimeDbSerializerID);
            project.Transports.SetRuntimeDbSerializing(runtimeDbSerializerID);
            project.UserGroups.SetRuntimeDbSerializing(runtimeDbSerializerID);
            project.Users.SetRuntimeDbSerializing(runtimeDbSerializerID);
        }

        /// <summary>
        /// Serializes an object to a database.
        /// </summary>
        /// <param name="baseContext">The object to save.</param>
        /// <param name="runtimeDbSerializerID">Runtime database serializer ID.</param>
        public static void SaveDbWithContext(this Egemin.EPIA.BaseContext baseContext, object runtimeDbSerializerID)
        {
            // get the serializer
            Egemin.EPIA.Data.Serialization.RuntimeDbSerializer runtimeDbSerializer = Script.Project.RuntimeDbSerializers[runtimeDbSerializerID];
            if (runtimeDbSerializer == null)
                throw new ArgumentException();

            // save the object to the database
            Egemin.EPIA.BaseContext.SaveDbWithContext(runtimeDbSerializer.OleDbConnectionString, runtimeDbSerializer.SessionName, baseContext);

            // clear the object
            baseContext.Clear();
        }

        /// <summary>
        /// Serializes the default objects to a database.
        /// </summary>
        public static void SaveDbWithContextDefault(this Egemin.EPIA.WCS.Core.Project project)
        {
            project.SaveDbWithContextDefault(null);
        }

        /// <summary>
        /// Serializes the default objects to a database.
        /// </summary>
        /// <param name="runtimeDbSerializerID">Runtime database serializer ID.</param>
        public static void SaveDbWithContextDefault(this Egemin.EPIA.WCS.Core.Project project, string runtimeDbSerializerID)
        {
            if (runtimeDbSerializerID == null)
                runtimeDbSerializerID = project.RuntimeDbSerializers.GetAllKeyIDs().FirstAsString;

            project.Reset();

            project.Agvs.SaveDbWithContext(runtimeDbSerializerID);
            project.AgvTypes.SaveDbWithContext(runtimeDbSerializerID);
            project.Alarms.SaveDbWithContext(runtimeDbSerializerID);
            project.Facilities.SaveDbWithContext(runtimeDbSerializerID);
            project.Groups.SaveDbWithContext(runtimeDbSerializerID);
            project.HostPorts.SaveDbWithContext(runtimeDbSerializerID);
            project.Loads.SaveDbWithContext(runtimeDbSerializerID);
            project.Locations.SaveDbWithContext(runtimeDbSerializerID);
            project.Processes.SaveDbWithContext(runtimeDbSerializerID);
            project.Stations.SaveDbWithContext(runtimeDbSerializerID);
            project.Transports.SaveDbWithContext(runtimeDbSerializerID);
            project.UserGroups.SaveDbWithContext(runtimeDbSerializerID);
            project.Users.SaveDbWithContext(runtimeDbSerializerID);
        }

        /// <summary>
        /// Deserializes an object from the database
        /// </summary>
        /// <param name="baseContext">The object to load.</param>
        /// <param name="runtimeDbSerializerID">Runtime database serializer ID.</param>
        /// <returns>The deserialized object</returns>
        public static T LoadDbWithContext<T>(this T baseContext, object runtimeDbSerializerID) where T : Egemin.EPIA.BaseContext
        {
            // get the serializer
            Egemin.EPIA.Data.Serialization.RuntimeDbSerializer runtimeDbSerializer = Script.Project.RuntimeDbSerializers[runtimeDbSerializerID];
            if (runtimeDbSerializer == null)
                throw new ArgumentException();

            return Egemin.EPIA.BaseContext.LoadDbWithContext(runtimeDbSerializer.OleDbConnectionString, "Session", null, baseContext) as T;
        }

        /// <summary>
        /// Deserializes the default objects from a database.
        /// </summary>
        public static void LoadDbWithContextDefault(this Egemin.EPIA.WCS.Core.Project project)
        {
            project.LoadDbWithContextDefault(null);
        }

        /// <summary>
        /// Deserializes the default objects from a database.
        /// </summary>
        /// <param name="runtimeDbSerializerID">Runtime database serializer ID.</param>
        public static void LoadDbWithContextDefault(this Egemin.EPIA.WCS.Core.Project project, string runtimeDbSerializerID)
        {
            if (runtimeDbSerializerID == null)
                runtimeDbSerializerID = project.RuntimeDbSerializers.GetAllKeyIDs().FirstAsString;

            project.Agvs = project.Agvs.LoadDbWithContext(runtimeDbSerializerID);
            foreach (Egemin.EPIA.WCS.Resources.Agv agv in project.Agvs)
            {
                agv.LeaveTrack.Clear();
                agv.LockedTrack.Clear();
                agv.LockedTrail.Clear();
                agv.LockRequestTrack.Clear();
            }

            project.AgvTypes = project.AgvTypes.LoadDbWithContext(runtimeDbSerializerID);
            project.Alarms = project.Alarms.LoadDbWithContext(runtimeDbSerializerID);
            project.Facilities = project.Facilities.LoadDbWithContext(runtimeDbSerializerID);
            project.Groups = project.Groups.LoadDbWithContext(runtimeDbSerializerID);
            project.HostPorts = project.HostPorts.LoadDbWithContext(runtimeDbSerializerID);
            project.Loads = project.Loads.LoadDbWithContext(runtimeDbSerializerID);
            project.Locations = project.Locations.LoadDbWithContext(runtimeDbSerializerID);
            project.Processes = project.Processes.LoadDbWithContext(runtimeDbSerializerID);
            project.Stations = project.Stations.LoadDbWithContext(runtimeDbSerializerID);
            project.Transports = project.Transports.LoadDbWithContext(runtimeDbSerializerID);
            project.UserGroups = project.UserGroups.LoadDbWithContext(runtimeDbSerializerID);
            project.Users = project.Users.LoadDbWithContext(runtimeDbSerializerID);

            project.Reset();
        }
    } 
}