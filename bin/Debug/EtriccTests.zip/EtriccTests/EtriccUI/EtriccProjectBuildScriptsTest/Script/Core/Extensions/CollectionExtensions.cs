﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace Egemin.Etricc.Scripts.Core
{
    /// <summary>
    /// Extension methods for Egemin.EPIA.Collections.TypedSortedCollection
    /// </summary>
    public static class CollectionExtensions
    {
        /// <summary>
        /// Converts a typed sorted collection to a type safe enumerable.
        /// </summary>
        /// <typeparam name="T">Strong type of the resulting IEnumerable.</typeparam>
        /// <param name="source">Source collection.</param>
        /// <returns>A type safe enumerable collection.</returns>
        public static IEnumerable<T> ToEnumerable<T>(this Egemin.EPIA.Collections.ITypedCollection<T> source)
        {
            if (source == null)
                throw new ArgumentNullException("source");

            return source.GetArray().OfType<T>();
        }

        /// <summary>
        /// Converts a typed sorted collection to a type safe array.
        /// </summary>
        /// <typeparam name="T">Strong type of the resulting List.</typeparam>
        /// <param name="source">Source collection.</param>
        /// <returns>A type safe list.</returns>
        public static T[] ToArray<T>( this Egemin.EPIA.Collections.ITypedCollection<T> source )
        {
            return source.ToEnumerable<T>().ToArray();
        }

        /// <summary>
        /// Converts a typed sorted collection to a type safe dictionary.
        /// </summary>
        /// <typeparam name="T">Strong type of the resulting dictionary.</typeparam>
        /// <param name="source">Source collection.</param>
        /// <returns>A type safe dictionary.</returns>
        public static Dictionary<object, T> ToDictionary<T>( this Egemin.EPIA.Collections.ITypedCollection<T> source ) where T : Egemin.EPIA.BaseObjectLight
        {
            return source.ToEnumerable<T>().ToDictionary<T, object>(element => element.ID);
        }

        /// <summary>
        /// Converts a typed sorted collection to a type safe list.
        /// </summary>
        /// <typeparam name="T">Strong type of the resulting List.</typeparam>
        /// <param name="source">Source collection.</param>
        /// <returns>A type safe list.</returns>
        public static List<T> ToList<T>( this Egemin.EPIA.Collections.ITypedCollection<T> source )
        {
            return source.ToEnumerable<T>().ToList();
        }

        

    } 
}