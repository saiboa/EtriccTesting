﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Egemin.Etricc.Scripts.Core
{
    public static class IOFieldExtensions
    {
        private const int BK9000_WATCHDOG = 5000;
        private const int BK9000_LOCAL_READ_PORT = 5001;
        private const int BK9000_LOCAL_WRITE_PORT = 5002;
        private const int BK9000_LOCAL_CONFIG_PORT = 5003;
        private const int BK9000_REMOTE_PORT = 502;
        private const int S7_CONFIG_PORT = 0;

        /// <summary>
        /// Adds a Beckhoff BK9000 to the field port collection.
        /// </summary>
        /// <param name="fieldPorts">Field port collection.</param>
        /// <param name="id">Field port ID.</param>
        /// <param name="address">IP address of the Beckhoff BK9000</param>
        /// <returns>The created field port.</returns>
        public static Egemin.EPIA.IO.Field.FieldPort InsertFieldPortBK9000(this Egemin.EPIA.IO.Field.FieldPorts fieldPorts, string id, string address)
        {
            string driverConfig = string.Format("WATCHDOG={0}", BK9000_WATCHDOG);
            string localReadPort = BK9000_LOCAL_READ_PORT.ToString();
            string localWritePort = BK9000_LOCAL_WRITE_PORT.ToString();
            string localConfigPort = BK9000_LOCAL_CONFIG_PORT.ToString();
            string remotePort = BK9000_REMOTE_PORT.ToString();

            return InsertFieldPort(fieldPorts, id, Egemin.EPIA.IO.Field.FieldPort.TYPE.MODBUS_BK9000, driverConfig, address, localReadPort, localWritePort, localConfigPort, remotePort, remotePort, remotePort);
        }

        /// <summary>
        /// Adds a Siemens S7 field port  to the field port collection.
        /// </summary>
        /// <param name="fieldPorts">Field port collection.</param>
        /// <param name="id">Field port ID.</param>
        /// <param name="address">IP address of the Siemes S7 PLC.</param>
        /// <param name="readPort">Read port.</param>
        /// <param name="writePort">Write port.</param>
        /// <param name="readDb">Data block to read.</param>
        /// <param name="readOffset">Offset within the data block to read.</param>
        /// <param name="readLenght">Length of data ot read (in words).</param>
        /// <param name="writeDb">Data block to write to.</param>
        /// <param name="writeOffset">Offset whitin the data block to write to.</param>
        /// <param name="writeLenght">Lenght of the data to write.</param>
        /// <returns>The created field port.</returns>
        public static Egemin.EPIA.IO.Field.FieldPort InsertFieldPortS7(this Egemin.EPIA.IO.Field.FieldPorts fieldPorts, string id, string address, int readPort, int writePort, int readDb, int readOffset, int readLenght, int writeDb, int writeOffset, int writeLenght)
        {
            // DB's should not exceed 255
            readDb = readDb > 255 ? -1 : readDb;
            writeDb = writeDb > 255 ? -1 : writeDb;

            string driverConfig = string.Format("READDB={0} READOFFSET={1} READLENGTH={2} WRITEDB={3} WRITEOFFSET={4} WRITELENGTH={5}", readDb, readOffset, readLenght, writeDb, writeOffset, writeLenght);
            string localReadPort = readPort.ToString();
            string localWritePort = writePort.ToString();
            string localConfigPort = S7_CONFIG_PORT.ToString();

            return InsertFieldPort(fieldPorts, id, Egemin.EPIA.IO.Field.FieldPort.TYPE.S7_NATIVE, driverConfig, address, localReadPort, localWritePort, localConfigPort, localReadPort, localWritePort, localConfigPort);
        }

        /// <summary>
        /// Adds a field port to the field port collection.
        /// </summary>
        /// <param name="fieldPorts">Field port collection.</param>
        /// <param name="id">Field port ID.</param>
        /// <param name="type">Field port type.</param>
        /// <param name="driverconfig">Driver config string.</param>
        /// <param name="driverAddress">IP address of the field port.</param>
        /// <param name="driverLocalReadPort">Local read port.</param>
        /// <param name="driverLocalWritePort">Local write port.</param>
        /// <param name="driverLocalConfigPort">Local config port.</param>
        /// <param name="driverRemotePort">Remote read/write/config port.</param>
        /// <returns>the created field port.</returns>
        public static Egemin.EPIA.IO.Field.FieldPort InsertFieldPort(this Egemin.EPIA.IO.Field.FieldPorts fieldPorts, string id, Egemin.EPIA.IO.Field.FieldPort.TYPE type, string driverconfig, string driverAddress, string driverLocalReadPort, string driverLocalWritePort, string driverLocalConfigPort, string driverRemoteReadPort, string driverRemoteWritePort, string driverRemoteConfigPort)
        {
            Dialog.SetProgress("FieldPorts", string.Format("Inserting FieldPort : {0}", id));

            Egemin.EPIA.IO.Field.FieldPort fieldPort = new Egemin.EPIA.IO.Field.FieldPort(id, type);

            // parameters
            fieldPort.Parameters[Egemin.EPIA.IO.Field.FieldPort.DRIVER_CONFIG].ValueAsString = driverconfig;
            fieldPort.Parameters[Egemin.EPIA.IO.Field.FieldPort.DRIVER_ADDRESS].ValueAsString = driverAddress;
            fieldPort.Parameters[Egemin.EPIA.IO.Field.FieldPort.DRIVER_LOCAL_READ_PORT].ValueAsString = driverLocalReadPort;
            fieldPort.Parameters[Egemin.EPIA.IO.Field.FieldPort.DRIVER_LOCAL_WRITE_PORT].ValueAsString = driverLocalWritePort;
            fieldPort.Parameters[Egemin.EPIA.IO.Field.FieldPort.DRIVER_LOCAL_CONFIG_PORT].ValueAsString = driverLocalConfigPort;
            fieldPort.Parameters[Egemin.EPIA.IO.Field.FieldPort.DRIVER_REMOTE_READ_PORT].ValueAsString = driverRemoteReadPort;
            fieldPort.Parameters[Egemin.EPIA.IO.Field.FieldPort.DRIVER_REMOTE_WRITE_PORT].ValueAsString = driverRemoteWritePort;
            fieldPort.Parameters[Egemin.EPIA.IO.Field.FieldPort.DRIVER_REMOTE_CONFIG_PORT].ValueAsString = driverRemoteConfigPort;
            fieldPort.Parameters[Egemin.EPIA.IO.Field.FieldPort.TIMEBASE].ValueAsInt = 200;

            // module types
            switch (type)
            {
                // Beckhoff BK9000 native
                case Egemin.EPIA.IO.Field.FieldPort.TYPE.MODBUS_BK9000:
                    InsertFieldModuleType(fieldPort.FieldModuleTypes, FIELDMODULETYPE.KL1002, "1002 1 0", 2, Egemin.EPIA.IO.Field.FieldPoint.TYPE.BIT, 0, Egemin.EPIA.IO.Field.FieldPoint.TYPE.BIT);
                    InsertFieldModuleType(fieldPort.FieldModuleTypes, FIELDMODULETYPE.KM1002, "10021 2 0", 16, Egemin.EPIA.IO.Field.FieldPoint.TYPE.BIT, 0, Egemin.EPIA.IO.Field.FieldPoint.TYPE.BIT);
                    InsertFieldModuleType(fieldPort.FieldModuleTypes, FIELDMODULETYPE.KL1408, "1408 1 0", 8, Egemin.EPIA.IO.Field.FieldPoint.TYPE.BIT, 0, Egemin.EPIA.IO.Field.FieldPoint.TYPE.BIT);
                    InsertFieldModuleType(fieldPort.FieldModuleTypes, FIELDMODULETYPE.KL1184, "1184 1 0", 8, Egemin.EPIA.IO.Field.FieldPoint.TYPE.BIT, 0, Egemin.EPIA.IO.Field.FieldPoint.TYPE.BIT);
                    InsertFieldModuleType(fieldPort.FieldModuleTypes, FIELDMODULETYPE.KM2002, "20021 0 2", 0, Egemin.EPIA.IO.Field.FieldPoint.TYPE.BIT, 16, Egemin.EPIA.IO.Field.FieldPoint.TYPE.BIT);
                    InsertFieldModuleType(fieldPort.FieldModuleTypes, FIELDMODULETYPE.KL2032, "2032 0 1", 0, Egemin.EPIA.IO.Field.FieldPoint.TYPE.BIT, 2, Egemin.EPIA.IO.Field.FieldPoint.TYPE.BIT);
                    InsertFieldModuleType(fieldPort.FieldModuleTypes, FIELDMODULETYPE.KL2408, "2408 0 1", 0, Egemin.EPIA.IO.Field.FieldPoint.TYPE.BIT, 8, Egemin.EPIA.IO.Field.FieldPoint.TYPE.BIT);
                    InsertFieldModuleType(fieldPort.FieldModuleTypes, FIELDMODULETYPE.KL2612, "2612 0 1", 0, Egemin.EPIA.IO.Field.FieldPoint.TYPE.BIT, 2, Egemin.EPIA.IO.Field.FieldPoint.TYPE.BIT);
                    break;

                // Siemens S7 RFC1006
                case Egemin.EPIA.IO.Field.FieldPort.TYPE.S7_RFC1006:
                    fieldPort.Parameters[Egemin.EPIA.IO.Field.FieldPort.BITORDER].ValueAsString = BITORDER.BIG_ENDIAN;

                    InsertFieldModuleType(fieldPort.FieldModuleTypes, FIELDMODULETYPE.BI16, "0 1 0", 16, Egemin.EPIA.IO.Field.FieldPoint.TYPE.BIT, 0, Egemin.EPIA.IO.Field.FieldPoint.TYPE.BIT);
                    InsertFieldModuleType(fieldPort.FieldModuleTypes, FIELDMODULETYPE.BO16, "0 0 1", 0, Egemin.EPIA.IO.Field.FieldPoint.TYPE.BIT, 16, Egemin.EPIA.IO.Field.FieldPoint.TYPE.BIT);
                    InsertFieldModuleType(fieldPort.FieldModuleTypes, FIELDMODULETYPE.BI32, "0 2 0", 32, Egemin.EPIA.IO.Field.FieldPoint.TYPE.BIT, 0, Egemin.EPIA.IO.Field.FieldPoint.TYPE.BIT);
                    InsertFieldModuleType(fieldPort.FieldModuleTypes, FIELDMODULETYPE.BO32, "0 0 2", 0, Egemin.EPIA.IO.Field.FieldPoint.TYPE.BIT, 32, Egemin.EPIA.IO.Field.FieldPoint.TYPE.BIT);
                    InsertFieldModuleType(fieldPort.FieldModuleTypes, FIELDMODULETYPE.WORD_IN, "0 1 0", 1, Egemin.EPIA.IO.Field.FieldPoint.TYPE.WORD, 0, Egemin.EPIA.IO.Field.FieldPoint.TYPE.WORD);
                    InsertFieldModuleType(fieldPort.FieldModuleTypes, FIELDMODULETYPE.WORD_OUT, "0 0 1", 0, Egemin.EPIA.IO.Field.FieldPoint.TYPE.WORD, 1, Egemin.EPIA.IO.Field.FieldPoint.TYPE.WORD);
                    InsertFieldModuleType(fieldPort.FieldModuleTypes, FIELDMODULETYPE.DWORD_IN, "0 2 0", 1, Egemin.EPIA.IO.Field.FieldPoint.TYPE.DWORD, 0, Egemin.EPIA.IO.Field.FieldPoint.TYPE.DWORD);
                    InsertFieldModuleType(fieldPort.FieldModuleTypes, FIELDMODULETYPE.DWORD_OUT, "0 0 2", 0, Egemin.EPIA.IO.Field.FieldPoint.TYPE.DWORD, 1, Egemin.EPIA.IO.Field.FieldPoint.TYPE.DWORD);
                    InsertFieldModuleType(fieldPort.FieldModuleTypes, FIELDMODULETYPE.BYTE_IN, "0 1 0", 1, Egemin.EPIA.IO.Field.FieldPoint.TYPE.BYTE, 0, Egemin.EPIA.IO.Field.FieldPoint.TYPE.BYTE);
                    InsertFieldModuleType(fieldPort.FieldModuleTypes, FIELDMODULETYPE.BYTE_OUT, "0 0 1", 0, Egemin.EPIA.IO.Field.FieldPoint.TYPE.BYTE, 2, Egemin.EPIA.IO.Field.FieldPoint.TYPE.BYTE);
                    break;

                // Siemens S7 native
                case Egemin.EPIA.IO.Field.FieldPort.TYPE.S7_NATIVE:
                    fieldPort.Parameters[Egemin.EPIA.IO.Field.FieldPort.BITORDER].ValueAsString = BITORDER.BIG_ENDIAN;

                    InsertFieldModuleType(fieldPort.FieldModuleTypes, FIELDMODULETYPE.BI16, "0 1 0", 16, Egemin.EPIA.IO.Field.FieldPoint.TYPE.BIT, 0, Egemin.EPIA.IO.Field.FieldPoint.TYPE.BIT);
                    InsertFieldModuleType(fieldPort.FieldModuleTypes, FIELDMODULETYPE.BO16, "0 0 1", 0, Egemin.EPIA.IO.Field.FieldPoint.TYPE.BIT, 16, Egemin.EPIA.IO.Field.FieldPoint.TYPE.BIT);
                    InsertFieldModuleType(fieldPort.FieldModuleTypes, FIELDMODULETYPE.BI32, "0 2 0", 32, Egemin.EPIA.IO.Field.FieldPoint.TYPE.BIT, 0, Egemin.EPIA.IO.Field.FieldPoint.TYPE.BIT);
                    InsertFieldModuleType(fieldPort.FieldModuleTypes, FIELDMODULETYPE.BO32, "0 0 2", 0, Egemin.EPIA.IO.Field.FieldPoint.TYPE.BIT, 32, Egemin.EPIA.IO.Field.FieldPoint.TYPE.BIT);
                    InsertFieldModuleType(fieldPort.FieldModuleTypes, FIELDMODULETYPE.WORD_IN, "0 1 0", 1, Egemin.EPIA.IO.Field.FieldPoint.TYPE.WORD, 0, Egemin.EPIA.IO.Field.FieldPoint.TYPE.WORD);
                    InsertFieldModuleType(fieldPort.FieldModuleTypes, FIELDMODULETYPE.WORD_OUT, "0 0 1", 0, Egemin.EPIA.IO.Field.FieldPoint.TYPE.WORD, 1, Egemin.EPIA.IO.Field.FieldPoint.TYPE.WORD);
                    InsertFieldModuleType(fieldPort.FieldModuleTypes, FIELDMODULETYPE.DWORD_IN, "0 2 0", 1, Egemin.EPIA.IO.Field.FieldPoint.TYPE.DWORD, 0, Egemin.EPIA.IO.Field.FieldPoint.TYPE.DWORD);
                    InsertFieldModuleType(fieldPort.FieldModuleTypes, FIELDMODULETYPE.DWORD_OUT, "0 0 2", 0, Egemin.EPIA.IO.Field.FieldPoint.TYPE.DWORD, 1, Egemin.EPIA.IO.Field.FieldPoint.TYPE.DWORD);
                    InsertFieldModuleType(fieldPort.FieldModuleTypes, FIELDMODULETYPE.BYTE_IN, "0 1 0", 1, Egemin.EPIA.IO.Field.FieldPoint.TYPE.BYTE, 0, Egemin.EPIA.IO.Field.FieldPoint.TYPE.BYTE);
                    InsertFieldModuleType(fieldPort.FieldModuleTypes, FIELDMODULETYPE.BYTE_OUT, "0 0 1", 0, Egemin.EPIA.IO.Field.FieldPoint.TYPE.BYTE, 2, Egemin.EPIA.IO.Field.FieldPoint.TYPE.BYTE);
                    break;

                // Beckhoff BK9000 comdriver
                case Egemin.EPIA.IO.Field.FieldPort.TYPE.ETHERNETIO_COMDRV:
                    InsertFieldModuleType(fieldPort.FieldModuleTypes, FIELDMODULETYPE.KL1408, "0 1 0", 8, Egemin.EPIA.IO.Field.FieldPoint.TYPE.BIT, 0, Egemin.EPIA.IO.Field.FieldPoint.TYPE.BIT);
                    InsertFieldModuleType(fieldPort.FieldModuleTypes, FIELDMODULETYPE.KL2408, "0 0 1", 0, Egemin.EPIA.IO.Field.FieldPoint.TYPE.BIT, 8, Egemin.EPIA.IO.Field.FieldPoint.TYPE.BIT);
                    break;

                // Siemens S7 comdriver
                case Egemin.EPIA.IO.Field.FieldPort.TYPE.ET_COMDRV:
                    InsertFieldModuleType(fieldPort.FieldModuleTypes, FIELDMODULETYPE.BI16, "0 1 0", 16, Egemin.EPIA.IO.Field.FieldPoint.TYPE.BIT, 0, Egemin.EPIA.IO.Field.FieldPoint.TYPE.BIT);
                    InsertFieldModuleType(fieldPort.FieldModuleTypes, FIELDMODULETYPE.BO16, "0 0 1", 0, Egemin.EPIA.IO.Field.FieldPoint.TYPE.BIT, 16, Egemin.EPIA.IO.Field.FieldPoint.TYPE.BIT);
                    InsertFieldModuleType(fieldPort.FieldModuleTypes, FIELDMODULETYPE.BI32, "0 2 0", 32, Egemin.EPIA.IO.Field.FieldPoint.TYPE.BIT, 0, Egemin.EPIA.IO.Field.FieldPoint.TYPE.BIT);
                    InsertFieldModuleType(fieldPort.FieldModuleTypes, FIELDMODULETYPE.BO32, "0 0 2", 0, Egemin.EPIA.IO.Field.FieldPoint.TYPE.BIT, 32, Egemin.EPIA.IO.Field.FieldPoint.TYPE.BIT);
                    InsertFieldModuleType(fieldPort.FieldModuleTypes, FIELDMODULETYPE.WORD_IN, "0 1 0", 1, Egemin.EPIA.IO.Field.FieldPoint.TYPE.WORD, 0, Egemin.EPIA.IO.Field.FieldPoint.TYPE.WORD);
                    InsertFieldModuleType(fieldPort.FieldModuleTypes, FIELDMODULETYPE.WORD_OUT, "0 0 1", 0, Egemin.EPIA.IO.Field.FieldPoint.TYPE.WORD, 1, Egemin.EPIA.IO.Field.FieldPoint.TYPE.WORD);
                    InsertFieldModuleType(fieldPort.FieldModuleTypes, FIELDMODULETYPE.DWORD_IN, "0 2 0", 1, Egemin.EPIA.IO.Field.FieldPoint.TYPE.DWORD, 0, Egemin.EPIA.IO.Field.FieldPoint.TYPE.DWORD);
                    InsertFieldModuleType(fieldPort.FieldModuleTypes, FIELDMODULETYPE.DWORD_OUT, "0 0 2", 0, Egemin.EPIA.IO.Field.FieldPoint.TYPE.DWORD, 1, Egemin.EPIA.IO.Field.FieldPoint.TYPE.DWORD);
                    InsertFieldModuleType(fieldPort.FieldModuleTypes, FIELDMODULETYPE.BYTE_IN, "0 1 0", 1, Egemin.EPIA.IO.Field.FieldPoint.TYPE.BYTE, 0, Egemin.EPIA.IO.Field.FieldPoint.TYPE.BYTE);
                    InsertFieldModuleType(fieldPort.FieldModuleTypes, FIELDMODULETYPE.BYTE_OUT, "0 0 1", 0, Egemin.EPIA.IO.Field.FieldPoint.TYPE.BYTE, 2, Egemin.EPIA.IO.Field.FieldPoint.TYPE.BYTE);
                    break;
            }

            return fieldPorts.Insert(fieldPort, true) as Egemin.EPIA.IO.Field.FieldPort;
        }

        /// <summary>
        /// Adds a field module type to a field module type collection.
        /// </summary>
        /// <param name="fieldModuleTypes">Collection of field modules.</param>
        /// <param name="id">Field module type ID.</param>
        /// <param name="driverData">Field module type driver data.</param>
        /// <param name="nrOfInputs">Field module type number of inputs.</param>
        /// <param name="inputType">Field module type input type.</param>
        /// <param name="nrOfOutputs">Field module type number of outputs.</param>
        /// <param name="outputType">Field module type output type.</param>
        /// <returns>The created field module type.</returns>
        public static Egemin.EPIA.IO.Field.FieldModuleType InsertFieldModuleType(this Egemin.EPIA.IO.Field.FieldModuleTypes fieldModuleTypes, object id, string driverData, int nrOfInputs, Egemin.EPIA.IO.Field.FieldPoint.TYPE inputType, int nrOfOutputs, Egemin.EPIA.IO.Field.FieldPoint.TYPE outputType)
        {
            Dialog.SetProgress("FieldModuleTypes", string.Format("Inserting FieldModuleType : {0}", id));

            Egemin.EPIA.IO.Field.FieldModuleType fieldModuleType = new Egemin.EPIA.IO.Field.FieldModuleType(id, driverData, nrOfInputs, inputType, nrOfOutputs, outputType);

            return fieldModuleTypes.Insert(fieldModuleType, true) as Egemin.EPIA.IO.Field.FieldModuleType;
        }

        /// <summary>
        /// Adds a field module to the field port's field module collection.
        /// </summary>
        /// <param name="fieldModules">Field Module collection.</param>
        /// <param name="name">Field module ID.</param>
        /// <param name="description">Field module description.</param>
        /// <param name="fieldModuleTypeID">Field module type ID.</param>
        /// <returns>The created field module.</returns>
        public static Egemin.EPIA.IO.Field.FieldModule InsertFieldModule(this Egemin.EPIA.IO.Field.FieldPort fieldPort, string name, string description, object fieldModuleTypeID, bool fieldPointsZeroBased)
        {
            return InsertFieldModule(fieldPort, name, description, fieldModuleTypeID, false);
        }

        /// <summary>
        /// Adds a field module to the field port's field module collection.
        /// </summary>
        /// <param name="fieldModules">Field Module collection.</param>
        /// <param name="name">Field module ID.</param>
        /// <param name="description">Field module description.</param>
        /// <param name="fieldModuleTypeID">Field module type ID.</param>
        /// <returns>The created field module.</returns>
        public static Egemin.EPIA.IO.Field.FieldModule InsertFieldModule(this Egemin.EPIA.IO.Field.FieldPort fieldPort, string name, string description, object fieldModuleTypeID)
        {
            Dialog.SetProgress("FieldModules", string.Format("Inserting FieldModule {0} in {1}", name, fieldPort.ID));

            bool zeroBased = false;
            switch (fieldPort.Type)
            {
                case Egemin.EPIA.IO.Field.FieldPort.TYPE.S7_COMDRV:
                case Egemin.EPIA.IO.Field.FieldPort.TYPE.S7_NATIVE:
                case Egemin.EPIA.IO.Field.FieldPort.TYPE.S7_RFC1006:
                    zeroBased = true;
                    break;
            }

            Egemin.EPIA.IO.Field.FieldModuleType fieldModuleType = fieldPort.FieldModuleTypes[fieldModuleTypeID];
            Egemin.EPIA.IO.Field.FieldModule fieldModule = new Egemin.EPIA.IO.Field.FieldModule(name, description, fieldModuleType, zeroBased);


            return fieldPort.FieldModules.Insert(fieldModule, true) as Egemin.EPIA.IO.Field.FieldModule;
        }

        /// <summary>
        /// Adds a field function to the field function collection.
        /// </summary>
        /// <param name="fieldFunctions">Field function collection.</param>
        /// <param name="id">Field function ID.</param>
        /// <param name="fieldFunctionType">Field function type.</param>
        /// <param name="description">Field function description.</param>
        /// <param name="lsgids">Field function reference location/station/group ID.</param>
        /// <returns>The created field function.</returns>
        public static Egemin.EPIA.WCS.IO.Field.FieldFunction InsertFieldFunction(this Egemin.EPIA.WCS.IO.Field.FieldFunctions fieldFunctions, string id, Egemin.EPIA.WCS.IO.Field.FieldFunction.TYPE fieldFunctionType, string description, string lsgids)
        {
            return InsertFieldFunction(fieldFunctions, id, fieldFunctionType, description, lsgids, null);
        }

        /// <summary>
        /// Adds a field function to the field function collection.
        /// </summary>
        /// <param name="fieldFunctions">Field function collection.</param>
        /// <param name="id">Field function ID.</param>
        /// <param name="fieldFunctionType">Field function type.</param>
        /// <param name="description">Field function description.</param>
        /// <param name="lsgids">Field function reference location/station/group ID.</param>
        /// <param name="arguments">Field function arguments.</param>
        /// <returns>The created field function.</returns>
        public static Egemin.EPIA.WCS.IO.Field.FieldFunction InsertFieldFunction(this Egemin.EPIA.WCS.IO.Field.FieldFunctions fieldFunctions, string id, Egemin.EPIA.WCS.IO.Field.FieldFunction.TYPE fieldFunctionType, string description, string lsgids, string arguments)
        {
            Dialog.SetProgress("FieldFunctions", string.Format("Inserting FieldFunction : {0}", id));

            Egemin.EPIA.WCS.IO.Field.FieldFunction fieldFunction = new Egemin.EPIA.WCS.IO.Field.FieldFunction(id, fieldFunctionType);

            // properties
            fieldFunction.Description = description;
            fieldFunction.LSGIDs = lsgids;
            fieldFunction.Arguments = arguments;

            // copy position
            if (fieldFunctions.Contains(id))
                fieldFunction.Position.Clone(fieldFunctions[id].Position);

            return fieldFunctions.Insert(fieldFunction, true) as Egemin.EPIA.WCS.IO.Field.FieldFunction;
        }

        /// <summary>
        /// Adds a field rule (port) to the field function's fieldrule collection.
        /// </summary>
        /// <param name="fieldFunction">Field rule collection.</param>
        /// <param name="type">Rule type.</param>
        /// <param name="fieldData">Rule field data.</param>
        /// <returns>The created field rule.</returns>
        public static Egemin.EPIA.WCS.IO.Field.FieldRule InsertFieldRulePort(this Egemin.EPIA.WCS.IO.Field.FieldRules fieldRules, Egemin.EPIA.WCS.IO.Field.FieldRule.TYPE type, string fieldData)
        {
            Dialog.SetProgress("FieldRules", string.Format("Inserting FieldRulePort : {0}", fieldData));

            Egemin.EPIA.WCS.IO.Field.FieldRule fieldRule = new Egemin.EPIA.WCS.IO.Field.FieldRulePort(type, fieldData);

            return fieldRules.Insert(fieldRule, true) as Egemin.EPIA.WCS.IO.Field.FieldRule;
        }

        /// <summary>
        /// Adds a field rule (port) to the field function's fieldrule collection.
        /// </summary>
        /// <param name="fieldFunction">Field rule collection.</param>
        /// <param name="type">Rule type.</param>
        /// <param name="fieldPortID">Rule fieldPort ID.</param>
        /// <param name="fieldModuleID">Rule fieldModule ID.</param>
        /// <param name="fieldPointID">Rule fieldPoint ID<./param>
        /// <returns>The created field rule.</returns>
        public static Egemin.EPIA.WCS.IO.Field.FieldRule InsertFieldRulePort(this Egemin.EPIA.WCS.IO.Field.FieldRules fieldRules, Egemin.EPIA.WCS.IO.Field.FieldRule.TYPE type, object fieldPortID, object fieldModuleID, object fieldPointID)
        {
            Dialog.SetProgress("FieldRules", string.Format("Inserting FieldRulePort :  {0}.{1}.{2}", fieldPortID, fieldModuleID, fieldPointID));

            Egemin.EPIA.WCS.IO.Field.FieldRule fieldRule = new Egemin.EPIA.WCS.IO.Field.FieldRulePort(type, fieldPortID, fieldModuleID, fieldPointID);

            return fieldRules.Insert(fieldRule, true) as Egemin.EPIA.WCS.IO.Field.FieldRule;
        }

        /// <summary>
        /// Adds a new FieldFunctionType to the FieldFunctionTypes collection.
        /// </summary>
        /// <param name="fieldFunctionType">Field function type collection.</param>
        /// <param name="id">FieldFunctionType type ID.</param>
        /// <returns>The created FieldFunctionType</returns>
        public static Egemin.EPIA.WCS.IO.Field.FieldFunctionType InsertFieldFunctionType(this Egemin.EPIA.WCS.IO.Field.FieldFunctionTypes fieldFunctionTypes, string id)
        {
            Dialog.SetProgress("FieldFunctionTypes", string.Format("Inserting FieldFunctionType : {0}", id));

            Egemin.EPIA.WCS.IO.Field.FieldFunctionType fieldFunctionType = new Egemin.EPIA.WCS.IO.Field.FieldFunctionType(id);

            return fieldFunctionTypes.Insert(fieldFunctionType, true) as Egemin.EPIA.WCS.IO.Field.FieldFunctionType;
        }

        /// <summary>
        /// Adds a new FieldFunction Type to the FieldFunctionTypes collection.
        /// </summary>
        /// <param name="fieldFunctionType">Field function type collection.</param>
        /// <param name="id">FieldFunctionType ID.</param>
        /// <param name="filePath">FieldFunctionType drawing file path.</param>
        /// <returns>The created FieldFunctionType</returns>
        public static Egemin.EPIA.WCS.IO.Field.FieldFunctionType InsertFieldFunctionType(this Egemin.EPIA.WCS.IO.Field.FieldFunctionTypes fieldFunctionTypes, string id, string filePath)
        {
            Dialog.SetProgress("FieldFunctionTypes", string.Format("Inserting FieldFunctionType : {0}", id));

            Egemin.EPIA.WCS.IO.Field.FieldFunctionType fieldFunctionType = new Egemin.EPIA.WCS.IO.Field.FieldFunctionType(id);

            // drawing
            fieldFunctionType.Reset();
            fieldFunctionType.Drawings.InsertDrawing(id, filePath);

            return fieldFunctionTypes.Insert(fieldFunctionType, true) as Egemin.EPIA.WCS.IO.Field.FieldFunctionType;
        }

    } 
}