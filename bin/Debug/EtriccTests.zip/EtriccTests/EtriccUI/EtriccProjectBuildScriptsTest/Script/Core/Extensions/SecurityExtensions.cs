﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Egemin.Etricc.Scripts.Core
{
    public static class SecurityExtensions
    {
        /// <summary>
        /// Retrieve UserGroups SID tokens
        /// </summary>
        /// <param name="group">User group.</param>
        public static void RetrieveSID(this Egemin.EPIA.Security.UserGroup group)
        {
            if (group == null)
                return;

            if (group.ID as string == null)
                return;

            string[] split = (group.ID as string).Split(new char[] { '\\' });

            string authority = String.Empty;
            string userGroup = split[0];

            if (split.Length > 1)
            {
                authority = split[0];
                userGroup = split[1];
            }

            group.SID = Egemin.EPIA.Security.WinSecurity.GetTextualSIDOfAccount(authority, userGroup);
        }

    } 
}