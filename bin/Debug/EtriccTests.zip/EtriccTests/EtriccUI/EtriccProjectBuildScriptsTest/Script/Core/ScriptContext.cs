﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Egemin.Etricc.Scripts.Core
{
    public static class ScriptContext
    {
        #region Constants

        public const string DefaultVersion = "0.0.0.*";

        private static class SubDir
        {
            public const string Bin = @"Bin";
            public const string Data = @"Data";
            public const string Cad = @"Data\Cad";
            public const string Agve = @"Data\Agve";
            public const string Bld = @"Data\Bld";
            public const string Ensor = @"Data\Ensor";
            public const string StatusDef = @"Data\Ensor\AgvStatusDef";
            public const string Layout = @"Data\Ensor\Layout";
            public const string Xml = @"Data\Xml";
        }

        #endregion

        # region Members

        private static string rootDirectory;
        private static List<string> targetFiles = new List<string>();

        private static string version;

        #endregion

        #region Main Properties

        /// <summary>
        /// The project root directory
        /// </summary>
        /// <remarks>Can only be set once.</remarks>
        public static string RootDirectory 
        {
            get { return rootDirectory; }
            set
            {
                rootDirectory = rootDirectory ?? value;
                BinDirectory = Path.Combine(rootDirectory, SubDir.Bin);
                DataDirectory = Path.Combine(rootDirectory, SubDir.Data);
                CadDirectory = Path.Combine(rootDirectory, SubDir.Cad);
                EnsorDirectory = Path.Combine(rootDirectory, SubDir.Ensor);
                StatusDefDirectory = Path.Combine(rootDirectory, SubDir.StatusDef);
                LayoutDirectory = Path.Combine(rootDirectory, SubDir.Layout);
                XmlDirectory = Path.Combine(rootDirectory, SubDir.Xml);
            }
        }

        /// <summary>
        /// Target Files.
        /// </summary>
        public static IEnumerable<string> TargetFiles
        {
            get { return targetFiles; }
        }

        #endregion

        #region Sub Directories

        /// <summary>
        /// Directory that contains all assembly files in the default structure.
        /// </summary>
        public static string BinDirectory { get; private set; }

        /// <summary>
        /// Directory that contains all data files in the default structure.
        /// </summary>
        public static string DataDirectory { get; private set; }

        /// <summary>
        /// Directory that contains all cad files in the default structure.
        /// </summary>
        public static string CadDirectory { get; private set; }

        /// <summary>
        /// Directory that contains all E'nsor files in the default structure.
        /// </summary>
        public static string EnsorDirectory { get; private set; }

        /// <summary>
        /// Directory that contains all status definition files in the default structure.
        /// </summary>
        public static string StatusDefDirectory { get; private set; }

        /// <summary>
        /// Directory that contains all E'nsor layout files in the default structure.
        /// </summary>
        public static string LayoutDirectory { get; private set; }

        /// <summary>
        /// Directory that contains all xml files in the default structure.
        /// </summary>
        public static string XmlDirectory { get; private set; }

        #endregion

        /// <summary>
        /// The project version.
        /// </summary>
        /// <remarks>can only be set once.</remarks>
        public static string Version
        {
            get { return version ?? DefaultVersion; }
            set { version = version ?? value; }
        }

        /// <summary>
        /// Adds a file to the target files list.
        /// </summary>
        /// <param name="target">Path of file to add.</param>
        public static void AddTargetFile(string target)
        {
            if (targetFiles == null)
                return;
            if (targetFiles.Contains(target))
                return;
            targetFiles.Add(target);
        }
    }
}