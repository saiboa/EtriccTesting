﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Egemin.Etricc.Scripts.Core
{
    /// <summary>
    /// Defines extension methods to the Egemin.EPIA.Logging namespace.
    /// </summary>
    public static class LoggingExtensions
    {
        /// <summary>
        /// Gets a textual representation of all errors and warnings.
        /// </summary>
        /// <param name="logMessages">Log message collection.</param>
        /// <returns>A textual representation of all warnings and errors in a log message collection.</returns>
        public static string GetWarningsAsText(this Egemin.EPIA.Logging.LogMessages logMessages)
        {
            var errors = from logMessage in logMessages.GetArray().OfType<Egemin.EPIA.Logging.LogMessage>()
                         where logMessage.Severity == Egemin.EPIA.Core.Definitions.Message.SEVERITY.WARNING
                            || logMessage.Severity == Egemin.EPIA.Core.Definitions.Message.SEVERITY.ERROR
                         select logMessage;

            StringBuilder text = new StringBuilder();

            foreach (var logMessage in errors)
            {
                text.AppendFormat("\n{0} {1}\n", logMessage.TimeStamp, logMessage.Symbol);
                text.Append(string.Join("\n", logMessage.Arguments));
            }

            return text.ToString().Trim();
        }

        /// <summary>
        /// Get a UI representation of all of all errors and warnings.
        /// </summary>
        /// <param name="logMessages">Log message collection.</param>
        /// <returns>A UI representation of all warnings and errors in a log message collection.</returns>
        public static string GetMessageText(this Egemin.EPIA.Logging.LogMessages logMessages)
        {
            // count errors and warnings
            Dictionary<string, int> errors = new Dictionary<string, int>();
            Dictionary<string, int> warnings = new Dictionary<string, int>();

            System.Text.StringBuilder errorBuilder = new System.Text.StringBuilder();
            System.Text.StringBuilder warningBuilder = new System.Text.StringBuilder();

            foreach (Egemin.EPIA.Core.Definitions.Message message in logMessages)
            {
                if (message.Severity == Egemin.EPIA.Core.Definitions.Message.SEVERITY.WARNING)
                {
                    if (!warnings.ContainsKey(message.Symbol))
                        warnings.Add(message.Symbol, 1);
                    else
                        warnings[message.Symbol]++;
                }

                if (message.Severity == Egemin.EPIA.Core.Definitions.Message.SEVERITY.ERROR)
                {
                    if (!errors.ContainsKey(message.Symbol))
                        errors.Add(message.Symbol, 1);
                    else
                        errors[message.Symbol]++;
                }
            }

            // create a visualisation for these counts
            foreach (KeyValuePair<string, int> pair in warnings)
                warningBuilder.Append(string.Format("\n    - {1} {0}", pair.Key, pair.Value));

            foreach (KeyValuePair<string, int> pair in errors)
                errorBuilder.Append(string.Format("\n    - {1} {0}", pair.Key, pair.Value));

            string errorText = "error" + (logMessages.NrOfErrors == 1 ? string.Empty : "s");
            string warningText = "warning" + (logMessages.NrOfWarnings == 1 ? string.Empty : "s");

            string formatText = "{0} did not succeed, {1} {2}:{3}\nand {4} {5}:{6}.";
            if (logMessages.NrOfErrors > 0 && logMessages.NrOfWarnings > 0)
                formatText = "{0} did not succeed, {1} {2}:{3}\nand {4} {5}:{6}.";
            else if (logMessages.NrOfErrors > 0)
                formatText = "{0} did not succeed, {1} {2}:{3}.";
            else if (logMessages.NrOfWarnings > 0)
                formatText = "{0} succeeded, but has {4} {5}:\n{6}.";

            return string.Format(formatText, "{0}", logMessages.NrOfErrors, errorText, errorBuilder, logMessages.NrOfWarnings, warningText, warningBuilder);
        }
    } 
}