﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Egemin.Etricc.Scripts.Core
{
    /// <summary>
    /// Defines extension methods to the Egemin.EPIA.WCS.Storage namespace.
    /// </summary>
    public static class StorageExtensions
    {
        /// <summary>
        /// Adds a new load type to the load types collection.
        /// </summary>
        /// <param name="loadTypes">Load type collection.</param>
        /// <param name="id">Load type ID.</param>
        /// <returns>The created load type</returns>
        public static Egemin.EPIA.WCS.Storage.LoadType InsertLoadType(this Egemin.EPIA.WCS.Storage.LoadTypes loadTypes, string id)
        {
            return loadTypes.InsertLoadType(id, null);
        }

        /// <summary>
        /// Adds a new load type to the load types collection.
        /// </summary>
        /// <param name="loadTypes">Load type collection.</param>
        /// <param name="id">Load type ID.</param>
        /// <param name="filePath">Load type drawing file path.</param>
        /// <param name="arguments">Load type arguments.</param>
        /// <returns>The created load type</returns>
        public static Egemin.EPIA.WCS.Storage.LoadType InsertLoadType(this Egemin.EPIA.WCS.Storage.LoadTypes loadTypes, string id, string filePath)
        {
            return loadTypes.InsertLoadType(id, filePath, string.Empty);
        }

        /// <summary>
        /// Adds a new load type to the load types collection.
        /// </summary>
        /// <param name="loadTypes">Load type collection.</param>
        /// <param name="id">Load type ID.</param>
        /// <param name="filePath">Load type drawing file path.</param>
        /// <param name="arguments">Load type arguments.</param>
        /// <returns>The created load type</returns>
        public static Egemin.EPIA.WCS.Storage.LoadType InsertLoadType(this Egemin.EPIA.WCS.Storage.LoadTypes loadTypes, string id, string filePath, string arguments)
        {
            Dialog.SetProgress("LoadTypes", string.Format("Inserting LoadType : {0}", id));

            var loadType = new Egemin.EPIA.WCS.Storage.LoadType(id);

            // drawing
            loadType.Reset();
            loadType.Drawings.InsertDrawing(id, filePath);

            // paramaters
            loadType.Parameters[Egemin.EPIA.WCS.Storage.LoadType.IMAGE_LAYER].ValueAsString = "ENSOR_VISUAL_LOAD";

            // properties
            loadType.Arguments = arguments;

            return loadTypes.Insert(loadType, true) as Egemin.EPIA.WCS.Storage.LoadType;
        }

        /// <summary>
        /// Adds a new load type to the load pattern types collection.
        /// </summary>
        /// <param name="loadPatternTypes">Load pattern type collection.</param>
        /// <param name="id">LoadPattern type ID.</param>
        /// <param name="filePath">LoadPattern type drawing file path.</param>
        /// <param name="arguments">LoadPattern type arguments.</param>
        /// <returns>The created load pattern type</returns>
        public static Egemin.EPIA.WCS.Storage.LoadPatternType InsertLoadPatternType(this Egemin.EPIA.WCS.Storage.LoadPatternTypes loadPatternTypes, string id, string filePath)
        {
            return loadPatternTypes.InsertLoadPatternType(id, filePath, null, null, new Egemin.EPIA.Layouting.Position());
        }

        /// <summary>
        /// Adds a new load type to the load pattern types collection.
        /// </summary>
        /// <param name="loadPatternTypes">Load pattern type collection.</param>
        /// <param name="id">Load pattern type ID.</param>
        /// <param name="filePath">Load pattern type drawing file path.</param>
        /// <param name="arguments">Load pattern type arguments.</param>
        /// <param name="description">Load pattern description.</param>
        /// <param name="positionOffset">Load pattern position offset.</param>
        /// <returns>The created loadPatternType</returns>
        public static Egemin.EPIA.WCS.Storage.LoadPatternType InsertLoadPatternType(this Egemin.EPIA.WCS.Storage.LoadPatternTypes loadPatternTypes, string id, string filePath, string arguments, string description, Egemin.EPIA.Layouting.Position positionOffset)
        {
            Dialog.SetProgress("LoadPatternTypes", string.Format("Inserting LoadPatternType : {0}", id));

            var loadPatternType = new Egemin.EPIA.WCS.Storage.LoadPatternType(id);

            // drawing
            loadPatternType.Reset();
            loadPatternType.Drawings.InsertDrawing(id, filePath);

            // paramaters
            loadPatternType.Parameters[Egemin.EPIA.WCS.Storage.LoadPatternType.IMAGE_LAYER].ValueAsString = "EGEMIN_IMAGE";

            // properties
            loadPatternType.Arguments = arguments;
            loadPatternType.Description = description;
            loadPatternType.PositionOffset = positionOffset;

            return loadPatternTypes.Insert(loadPatternType, true) as Egemin.EPIA.WCS.Storage.LoadPatternType;
        }

        /// <summary>
        /// Adds a location type to the location types collection.
        /// </summary>
        /// <param name="locationTypes">Location type collection.</param>
        /// <param name="id">Location type ID.</param>
        /// <param name="typeClass">Location type Class.</param>
        /// <param name="manageType">Loaction type management type.</param>
        /// <returns>The created location type.</returns>
        public static Egemin.EPIA.WCS.Storage.LocationType InsertLocationType(this Egemin.EPIA.WCS.Storage.LocationTypes locationTypes, string id, Egemin.EPIA.WCS.Storage.LocationType.CLASS typeClass, Egemin.EPIA.WCS.Storage.LocationType.MANAGE_TYPE manageType)
        {
            Dialog.SetProgress("LocationTypes", string.Format("Inserting LocationType : {0}", id));

            var locationType = new Egemin.EPIA.WCS.Storage.LocationType(id);

            // properties
            locationType.Class = typeClass;
            locationType.ManagementType = manageType;

            return locationTypes.Insert(locationType, true) as Egemin.EPIA.WCS.Storage.LocationType;
        }

        /// <summary>
        /// Adds a location type to the location types collection.
        /// </summary>
        /// <param name="locationTypes">Location type collection.</param>
        /// <param name="id">Location type ID.</param>
        /// <param name="typeClass">Location type Class.</param>
        /// <param name="manageType">Location type management type.</param>
        /// <param name="bumpEnable">Location type bump enable.</param>
        /// <returns>The created location type.</returns>
        public static Egemin.EPIA.WCS.Storage.LocationType InsertLocationType(this Egemin.EPIA.WCS.Storage.LocationTypes locationTypes, string id, Egemin.EPIA.WCS.Storage.LocationType.CLASS typeClass)
        {
            Dialog.SetProgress("LocationTypes", string.Format("Inserting LocationType : {0}", id));

            var locationType = new Egemin.EPIA.WCS.Storage.LocationType(id);

            // properties
            locationType.Class = typeClass;

            return locationTypes.Insert(locationType, true) as Egemin.EPIA.WCS.Storage.LocationType;
        }

        /// <summary>
        /// Adds a location type to the location types collection.
        /// </summary>
        /// <param name="locationTypes">Location type collection.</param>
        /// <param name="id">Location type ID.</param>
        /// <param name="Class">Location type Class.</param>
        /// <param name="filePath">Location type drawing file path.</param>
        /// <returns>The created location type.</returns>
        public static Egemin.EPIA.WCS.Storage.LocationType InsertLocationType(this Egemin.EPIA.WCS.Storage.LocationTypes locationTypes, string id, Egemin.EPIA.WCS.Storage.LocationType.CLASS Class, string filePath)
        {
            Dialog.SetProgress("LocationTypes", string.Format("Inserting LocationType : {0}", id));

            var locationType = new Egemin.EPIA.WCS.Storage.LocationType(id);

            // drawing
            if (filePath != null)
            {
                locationType.Reset();
                locationType.Drawings.InsertDrawing(id, filePath);
            }

            // properties
            locationType.Class = Class;

            return locationTypes.Insert(locationType, true) as Egemin.EPIA.WCS.Storage.LocationType;
        }

        /// <summary>
        /// Adds a location type to the location types collection.
        /// </summary>
        /// <param name="locationTypes">Location type collection.</param>
        /// <param name="id">Location type ID.</param>
        /// <param name="typeClass">Location type Class.</param>
        /// <param name="manageType">Location type management type.</param>
        /// <param name="bumpEnable">Location type bump enable.</param>
        /// <returns>The created location type.</returns>
        public static Egemin.EPIA.WCS.Storage.LocationType InsertLocationType(this Egemin.EPIA.WCS.Storage.LocationTypes locationTypes, string id, Egemin.EPIA.WCS.Storage.LocationType.CLASS typeClass, Egemin.EPIA.WCS.Storage.LocationType.MANAGE_TYPE manageType, bool bumpEnable)
        {
            Dialog.SetProgress("LocationTypes", string.Format("Inserting LocationType : {0}", id));

            var locationType = new Egemin.EPIA.WCS.Storage.LocationType(id);

            // properties
            locationType.Class = typeClass;
            locationType.ManagementType = manageType;

            // parameters
            locationType.Parameters[Egemin.EPIA.WCS.Storage.LocationType.BUMP_ENABLE].ValueAsBool = bumpEnable;

            return locationTypes.Insert(locationType, true) as Egemin.EPIA.WCS.Storage.LocationType;
        }
    } 
}