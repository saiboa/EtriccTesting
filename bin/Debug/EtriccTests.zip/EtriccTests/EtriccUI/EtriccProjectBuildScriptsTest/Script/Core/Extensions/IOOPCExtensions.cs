﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Egemin.Etricc.Scripts.Core
{
    public static class IOOPCExtensions
    {

        ///// <summary>
        ///// Adds a computer def to the computerdefs collection.
        ///// </summary>
        ///// <param name="computerDefs">Computer definition collection.</param>
        ///// <param name="computerName">Computer id.</param>
        ///// <returns>The created computer def.</returns>
        //public static Egemin.EPIA.Core.Definitions.ComputerDef InsertComputerDef(this Egemin.EPIA.Core.Definitions.ComputerDefs computerDefs, string id)
        //{
        //    Dialog.SetProgress("ComputerDefs", string.Format("Inserting ComputerDef : {0}", id));

        //    Egemin.EPIA.Core.Definitions.ComputerDef computerDef = new Egemin.EPIA.Core.Definitions.ComputerDef(id);

        //    //properties
        //    computerDef.ComputerName = id;

        //    return computerDefs.Insert(computerDef, true) as Egemin.EPIA.Core.Definitions.ComputerDef;
        //}


        ///// <summary>
        ///// Adds an opc server name def to the servernamedefs collection.
        ///// </summary>
        ///// <param name="opcServerNameDefs">OPC server name definition collection.</param>
        ///// <param name="serverName">Server name.</param>
        ///// <returns>The created opc server name def.</returns>
        //public static Egemin.EPIA.IO.Opc.Client.OpcServerNameDef InsertServerNameDef(this Egemin.EPIA.IO.Opc.Client.OpcServerNameDefs opcServerNameDefs, string serverName)
        //{
        //    Dialog.SetProgress("OpcServerNameDefs", string.Format("Inserting OpcServerNameDef : {0}", serverName));

        //    Egemin.EPIA.IO.Opc.Client.OpcServerNameDef opcServerNameDef = new Egemin.EPIA.IO.Opc.Client.OpcServerNameDef(serverName);

        //    //properties
        //    opcServerNameDef.ProgId = serverName;

        //    return opcServerNameDefs.Insert(opcServerNameDef, true) as Egemin.EPIA.IO.Opc.Client.OpcServerNameDef;
        //}


        ///// <summary>
        ///// Adds an opc client to the opc client collection.
        ///// </summary>
        ///// <param name="opcClients">Opc client collection.</param>
        ///// <param name="id">Opc client id.</param>
        ///// <param name="computerDef">Computer def name.</param>
        ///// <param name="serverName">Server name.</param>
        ///// <returns>The created opc client.</returns>
        //public static Egemin.EPIA.IO.Opc.Client.OpcClient InsertOPCClient(this Egemin.EPIA.IO.Opc.Client.OpcClients opcClients, string id, string computerDef, string serverName)
        //{
        //    Dialog.SetProgress("OpcClients", string.Format("Inserting OpcClient : {0}", id));

        //    Egemin.EPIA.IO.Opc.Client.OpcClient opcClient = new Egemin.EPIA.IO.Opc.Client.OpcClient(id);

        //    //properties
        //    opcClient.ComputerDefID = computerDef;
        //    opcClient.OpcServerNameDefID = serverName;

        //    return opcClients.Insert(opcClient, true) as Egemin.EPIA.IO.Opc.Client.OpcClient;
        //}


        ///// <summary>
        ///// Adds an opc group to a opc group collection.
        ///// </summary>
        ///// <param name="opcGroups">Opc group collection.</param>
        ///// <param name="id">Opc groep id</param>
        ///// <returns></returns>
        //public static Egemin.EPIA.IO.Opc.Client.OpcGroup InsertOPCGroup(this Egemin.EPIA.IO.Opc.Client.OpcGroups opcGroups, string id)
        //{
        //    Dialog.SetProgress("OpcGroups", string.Format("Inserting OpcGroup : {0}", id));

        //    Egemin.EPIA.IO.Opc.Client.OpcGroup opcGroup = new Egemin.EPIA.IO.Opc.Client.OpcGroup(id);

        //    //properties
        //    opcGroup.RefreshPeriod = 30000;
        //    opcGroup.WritePeriod = 1000;

        //    return opcGroups.Insert(opcGroup, true) as Egemin.EPIA.IO.Opc.Client.OpcGroup;
        //}


        ///// <summary>
        ///// Adds an opc item def to the opc item def collection.
        ///// </summary>
        ///// <param name="opcItemDefs">Opc item definition collection.</param>
        ///// <param name="opcItemDefName">Opc item def name.</param>
        ///// <param name="serverItemId">Server item id.</param>
        ///// <returns>The created opc item def.</returns>
        //public static Egemin.EPIA.IO.Opc.Client.OpcItemDef InsertOPCItemDef(this Egemin.EPIA.IO.Opc.Client.OpcItemDefs opcItemDefs, string opcItemDefName, string serverItemId)
        //{
        //    Dialog.SetProgress("OpcItemDefs", string.Format("Inserting OpcItemDef : {0}", opcItemDefName));

        //    Egemin.EPIA.IO.Opc.Client.OpcItemDef opcItemDef = new Egemin.EPIA.IO.Opc.Client.OpcItemDef(opcItemDefName);

        //    //properties
        //    opcItemDef.ServerItemId = serverItemId;

        //    return opcItemDefs.Insert(opcItemDef, true) as Egemin.EPIA.IO.Opc.Client.OpcItemDef;
        //}


        ///// <summary>
        ///// Adds an opc item to the an opc item collection
        ///// </summary>
        ///// <param name="opcItems">The opc item collection</param>
        ///// <param name="opcItemDefName">Opc item def name</param>
        ///// <param name="groupName">Opc groep id.</param>
        ///// <returns>The created opc item/</returns>
        //public static Egemin.EPIA.IO.Opc.Client.OpcItem InsertOPCItem(this Egemin.EPIA.IO.Opc.Client.OpcItems opcItems, string opcItemDefName, string groupName)
        //{
        //    Dialog.SetProgress("OpcItems", string.Format("Inserting OpcItem : {0}", opcItemDefName));

        //    Egemin.EPIA.IO.Opc.Client.OpcItem opcItem = new Egemin.EPIA.IO.Opc.Client.OpcItem(opcItemDefName, groupName);

        //    return opcItems.Insert(opcItem, true) as Egemin.EPIA.IO.Opc.Client.OpcItem;
        //}

        /// <summary>
        /// Adds a field rule (opc) to the field function's fieldrule collection.
        /// </summary>
        /// <param name="fieldFunction">Field rule collection.</param>
        /// <param name="type">Rule type.</param>
        /// <param name="opcClientId">Rule opc client id.</param>
        /// <param name="opcItemId">Rule opc item id.</param>
        /// <returns></returns>
        public static Egemin.EPIA.WCS.IO.Field.FieldRuleOpc InsertFieldRuleOpc(this Egemin.EPIA.WCS.IO.Field.FieldRules fieldRules, Egemin.EPIA.WCS.IO.Field.FieldRule.TYPE type, string opcClientId, string opcItemId)
        {
            Dialog.SetProgress("FieldRules", string.Format("Inserting FieldRuleOpc : {0}.{1}", opcClientId, opcItemId));

            Egemin.EPIA.WCS.IO.Field.FieldRuleOpc fieldRule = new Egemin.EPIA.WCS.IO.Field.FieldRuleOpc(type, opcClientId, opcItemId);

            return fieldRules.Insert(fieldRule, true) as Egemin.EPIA.WCS.IO.Field.FieldRuleOpc;
        }

    } 
}