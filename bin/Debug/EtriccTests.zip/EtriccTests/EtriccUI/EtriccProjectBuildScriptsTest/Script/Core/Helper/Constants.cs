﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Egemin.Etricc.Scripts.Core
{
    public class Constants
    {
        /// <summary>
        /// Any.
        /// </summary>
        public const string ANY = Egemin.EPIA.Constants.ANY;

        /// <summary>
        /// Default.
        /// </summary>
        public const string DEFAULT = Egemin.EPIA.Constants.DEFAULT;

        /// <summary>
        /// Null (as text).
        /// </summary>
        public const string NULL = Egemin.EPIA.Constants.NULL;

        /// <summary>
        /// Not specified (-1)
        /// </summary>
        public const int NOT_SPECIFIED = Egemin.EPIA.Constants.NOT_SPECIFIED;
    }

    /// <summary>
    /// Predefined file name extensions.
    /// </summary>
    public class EXTENSION
    {
        /// <summary>
        /// .bin
        /// </summary>
        public const string BIN = Egemin.EPIA.Constants.BIN_EXTENSION;

        /// <summary>
        /// .cvs
        /// </summary>
        public const string CSV = Egemin.EPIA.Constants.CSV_EXTENSION;

        /// <summary>
        /// .key
        /// </summary>
        public const string KEY = Egemin.EPIA.Constants.KEY_EXTENSION;

        /// <summary>
        /// .lic
        /// </summary>
        public const string LIC = Egemin.EPIA.Constants.LIC_EXTENSION;

        /// <summary>
        /// .xml
        /// </summary>
        public const string XML = Egemin.EPIA.Constants.XML_EXTENSION;

        /// <summary>
        /// .zip
        /// </summary>
        public const string ZIP = Egemin.EPIA.Constants.ZIP_EXTENSION;

        /// <summary>
        /// .dxf
        /// </summary>
        public const string DXF = ".dxf";
    }

    /// <summary>
    /// Predefined durations in milliseconds.
    /// </summary>
    public class DURATION
    {
        /// <summary>
        /// 1000ms
        /// </summary>
        public const int SECOND = Egemin.EPIA.Constants.SECOND;

        /// <summary>
        /// 60000ms
        /// </summary>
        public const int MINUTE = Egemin.EPIA.Constants.MINUTE;

        /// <summary>
        /// 3600000ms
        /// </summary>
        public const int HOUR = Egemin.EPIA.Constants.HOUR;

        /// <summary>
        /// 86400000ms
        /// </summary>
        public const int DAY = Egemin.EPIA.Constants.DAY;

        /// <summary>
        /// -1
        /// </summary>
        public const int INFINITE = Egemin.EPIA.Constants.INFINITE;

        /// <summary>
        /// -1
        /// </summary>
        public const int NOT_SPECIFIED = Egemin.EPIA.Constants.NOT_SPECIFIED;

        /// <summary>
        /// -1
        /// </summary>
        public const int UNLIMITED = Egemin.EPIA.Constants.UNLIMITED;
    }

    /// <summary>
    /// ASCII chars
    /// </summary>
    public enum ASCII
    {
        NUL = Egemin.EPIA.Constants.ASCII.NUL,
        SOH = Egemin.EPIA.Constants.ASCII.SOH,
        STX = Egemin.EPIA.Constants.ASCII.STX,
        ETX = Egemin.EPIA.Constants.ASCII.ETX,
        EOT = Egemin.EPIA.Constants.ASCII.EOT,
        ENQ = Egemin.EPIA.Constants.ASCII.ENQ,
        ACK = Egemin.EPIA.Constants.ASCII.ACK,
        BEL = Egemin.EPIA.Constants.ASCII.BEL,
        BS = Egemin.EPIA.Constants.ASCII.BS,
        HT = Egemin.EPIA.Constants.ASCII.HT,
        LF = Egemin.EPIA.Constants.ASCII.LF,
        VT = Egemin.EPIA.Constants.ASCII.VT,
        FF = Egemin.EPIA.Constants.ASCII.FF,
        CR = Egemin.EPIA.Constants.ASCII.CR,
        DLE = Egemin.EPIA.Constants.ASCII.DLE,
        XON = Egemin.EPIA.Constants.ASCII.XON,
        XOFF = Egemin.EPIA.Constants.ASCII.XOFF,
        NAK = Egemin.EPIA.Constants.ASCII.NAK,
        SYN = Egemin.EPIA.Constants.ASCII.SYN,
        EM = Egemin.EPIA.Constants.ASCII.EM,
        ESC = Egemin.EPIA.Constants.ASCII.ESC,
    }

    /// <summary>
    /// Predefined vehicle code constants.
    /// </summary>
    public class VEHICLETYPE
    {
        /// <summary>
        /// Any vehicle type.
        /// </summary>
        public const string ANY = Egemin.EPIA.Constants.ANY;

        /// <summary>
        /// Fork Lift Vehicle.
        /// </summary>
        public const string FLV = "FLV";

        /// <summary>
        /// Roll Lifting Vehicle.
        /// </summary>
        public const string RLV = "RLV";

        /// <summary>
        /// Side Lifting Vehicle.
        /// </summary>
        public const string SLV = "SLV";

        /// <summary>
        /// Load Transfer Vehicle.
        /// </summary>
        public const string LTV = "LTV";

        /// <summary>
        /// Load Platform Vehicle.
        /// </summary>
        public const string LPV = "LPV";

        /// <summary>
        /// Trailer Loading Vehicle.
        /// </summary>
        public const string TLV = "TLV";

        /// <summary>
        /// Tugger Vehicle.
        /// </summary>
        public const string TUV = "TUV";

        /// <summary>
        /// Automatic Truck Loader.
        /// </summary>
        public const string ATL = "ATL";

        /// <summary>
        /// Counter Balance Vehicle.
        /// </summary>
        public const string CBV = "CBV";

        /// <summary>
        /// General Vehicle.
        /// </summary>
        public const string AGV = "AGV";
    }

    /// <summary>
    /// Predefined language code constants.
    /// </summary>
    public class OPERATORLANGUAGE
    {
        /// <summary>
        /// Deutsch.
        /// </summary>
        public const string DE = "de";

        /// <summary>
        /// English.
        /// </summary>
        public const string EN = "en";

        /// <summary>
        /// Español.
        /// </summary>
        public const string ES = "es";

        /// <summary>
        /// Français.
        /// </summary>
        public const string FR = "fr";

        /// <summary>
        /// Nederlands.
        /// </summary>
        public const string NL = "nl";
    }

    /// <summary>
    /// Predefined fieldmodule type constants.
    /// </summary>
    public class FIELDMODULETYPE
    {
        /// <summary>
        /// 16 bit input module.
        /// </summary>
        public const string BI16 = "BI16";

        /// <summary>
        /// 16 bit output module.
        /// </summary>
        public const string BO16 = "BO16";

        /// <summary>
        /// 32 bit input module.
        /// </summary>
        public const string BI32 = "BI32";

        /// <summary>
        /// 32 bit output module.
        /// </summary>
        public const string BO32 = "BO32";

        /// <summary>
        /// Word in module.
        /// </summary>
        public const string WORD_IN = "WORD_IN";

        /// <summary>
        /// Word out module.
        /// </summary>
        public const string WORD_OUT = "WORD_OUT";

        /// <summary>
        /// DWord in module.
        /// </summary>
        public const string DWORD_IN = "DWORD_IN";

        /// <summary>
        /// DWord out module.
        /// </summary>
        public const string DWORD_OUT = "DWORD_OUT";

        /// <summary>
        /// Byte in module.
        /// </summary>
        public const string BYTE_IN = "BYTE_IN";

        /// <summary>
        /// Byte out module.
        /// </summary>
        public const string BYTE_OUT = "BYTE_OUT";

        /// <summary>
        /// KL1408 module.
        /// </summary>
        public const string KL1408 = "KL1408";

        /// <summary>
        /// KL1184 module.
        /// </summary>
        public const string KL1184 = "KL1184";

        /// <summary>
        /// KL2408 module.
        /// </summary>
        public const string KL2408 = "KL2408";

        /// <summary>
        /// KL1002 module.
        /// </summary>
        public const string KL1002 = "KL1002";

        /// <summary>
        /// KM1002 module.
        /// </summary>
        public const string KM1002 = "KM1002";

        /// <summary>
        /// KM2002 module.
        /// </summary>
        public const string KM2002 = "KM2002";

        /// <summary>
        /// KL2612 module.
        /// </summary>
        public const string KL2612 = "KL2612";

        /// <summary>
        /// KL2032 module.
        /// </summary>
        public const string KL2032 = "KL2032";
    }

    /// <summary>
    /// Predefined bitorders
    /// </summary>
    public class BITORDER
    {
        /// <summary>
        /// Big endian.
        /// </summary>
        public const string BIG_ENDIAN = "BIG_ENDIAN";

        /// <summary>
        /// Little endian.
        /// </summary>
        public const string LITTLE_ENDIAN = "LITTLE_ENDIAN";

        /// <summary>
        /// middle endian.
        /// </summary>
        public const string MIDDLE_ENDIAN = "MIDDLE_ENDIAN";
    }

    /// <summary>
    /// Predefined hostdrivermode
    /// </summary>
    public class HOSTDRIVERMODE
    {
        /// <summary>
        /// Undefined.
        /// </summary>
        public const string UNDEFINED = "UNDEFINED";
        /// <summary>
        /// Server.
        /// </summary>
        public const string SERVER = "SERVER";
        /// <summary>
        /// Client.
        /// </summary>
        public const string CLIENT = "CLIENT";
        /// <summary>
        /// Dual.
        /// </summary>
        public const string DUAL = "DUAL";
    }
}