﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Egemin.Etricc.Scripts.Core
{
    public static class IOHostExtensions
    {

        /// <summary>
        /// Adds a host port to the hostports collection.
        /// </summary>
        /// <param name="hostPorts">Host port collection.</param>
        /// <param name="id">Host port ID.</param>
        /// <param name="type">Host port type.</param>
        /// <param name="driverconfig">Host port driver config.</param>
        /// <returns>The created host port.</returns>
        public static Egemin.EPIA.WCS.IO.Host.HostPort InsertHostPort(this Egemin.EPIA.WCS.IO.Host.HostPorts hostPorts, string id, Egemin.EPIA.WCS.IO.Host.HostPort.TYPE type, string driverconfig)
        {
            return hostPorts.InsertHostPort(id, type, driverconfig, true, 15, 90, true);
        }

        /// <summary>
        /// Adds a host port to the hostports collection.
        /// </summary>
        /// <param name="hostPorts">Host port collection.</param>
        /// <param name="id">Host port ID.</param>
        /// <param name="type">Host port type.</param>
        /// <param name="driverconfig">Host port driver config.</param>
        /// <param name="driverconfirm">Host port driver confirm.</param>
        /// <param name="keepAlivePeriod">Host port keep-alive period.</param>
        /// <param name="keepAliveTimeout">Host port keep-alive timeout.</param>
        /// <param name="replyRecquired">Host port reply recquired.</param>
        /// <returns>The created host port.</returns>
        public static Egemin.EPIA.WCS.IO.Host.HostPort InsertHostPort(this Egemin.EPIA.WCS.IO.Host.HostPorts hostPorts, string id, Egemin.EPIA.WCS.IO.Host.HostPort.TYPE type, string driverconfig, bool driverconfirm, int keepAlivePeriod, int keepAliveTimeout, bool replyRecquired)
        {
            Dialog.SetProgress("HostPorts", string.Format("Inserting HostPort : {0}", id));

            Egemin.EPIA.WCS.IO.Host.HostPort hostport = new Egemin.EPIA.WCS.IO.Host.HostPort(id);

            // properties
            hostport.Type = type;

            //parameters
            hostport.Parameters[Egemin.EPIA.WCS.IO.Host.HostPort.DRIVER_CONFIG].ValueAsString = driverconfig;
            hostport.Parameters[Egemin.EPIA.WCS.IO.Host.HostPort.DRIVER_CONFIRM].ValueAsBool = driverconfirm;
            hostport.Parameters[Egemin.EPIA.WCS.IO.Host.HostPort.KEEPALIVE_PERIOD].ValueAsInt = keepAlivePeriod;
            hostport.Parameters[Egemin.EPIA.WCS.IO.Host.HostPort.KEEPALIVE_TIMEOUT].ValueAsInt = keepAliveTimeout;
            hostport.Parameters[Egemin.EPIA.WCS.IO.Host.HostPort.REPLY_REQUIRED].ValueAsBool = replyRecquired;

            // type specific parameters.
            switch (type)
            {
                case Egemin.EPIA.IO.Host.HostPort.TYPE.FILE_LINK:
                case Egemin.EPIA.IO.Host.HostPort.TYPE.S7_COMDRV:
                case Egemin.EPIA.IO.Host.HostPort.TYPE.TCPIP:
                    break;
                case Egemin.EPIA.IO.Host.HostPort.TYPE.S7_NATIVE:
                    Egemin.EPIA.Tokeniser config = new Egemin.EPIA.Tokeniser(driverconfig);
                    int readDb = int.Parse(config.GetNamedTokenValue("READDB"));
                    int writeDb = int.Parse(config.GetNamedTokenValue("WRITEDB"));

                    if (readDb > 255 || writeDb > 255)
                    {
                        System.Windows.Forms.DialogResult result = Dialog.MessageBox.Show("This configuration may result in communication errors.\nRead DB and write db should not exceed 256.", "Warning", System.Windows.Forms.MessageBoxButtons.OKCancel, System.Windows.Forms.MessageBoxIcon.Warning, System.Windows.Forms.MessageBoxDefaultButton.Button2);

                        if (result == System.Windows.Forms.DialogResult.Cancel)
                            Script.Abort();
                    }
                    break;
            }


            return hostPorts.Insert(hostport, true) as Egemin.EPIA.WCS.IO.Host.HostPort;
        }

    } 
}