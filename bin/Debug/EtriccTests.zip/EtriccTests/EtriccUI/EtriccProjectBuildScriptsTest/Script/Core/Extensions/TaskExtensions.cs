﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace Egemin.Etricc.Scripts.Core
{
    public static class TaskExtensions
    {

        /// <summary>
        /// Start the importer.
        /// </summary>
        /// <param name="importer">Importer.</param>
        public static Egemin.EPIA.BaseObjectLight.RESULT Import(this Egemin.EPIA.WCS.Engineering.Importer importer)
        {
            do
                Script.Project.Import();
            while (importer.GetResult() == System.Windows.Forms.DialogResult.Retry);

            Dialog.SetProgress(null, null);

            return Script.Project.Importer.Result;
        }

        /// <summary>
        /// Start the importer.
        /// </summary>
        /// <param name="importer">Importer.</param>
        /// <param name="command">Importer command.</param>
        /// <param name="arguments">Importer arguments.</param>
        /// <param name="filePath">Importer file path.</param>
        public static Egemin.EPIA.BaseObjectLight.RESULT Import(this Egemin.EPIA.WCS.Engineering.Importer importer, Egemin.EPIA.WCS.Engineering.Importer.COMMAND command, string arguments, string filePath)
        {
            importer.FilePath = File.GetFullFileName(filePath);
            importer.Command = command;
            importer.Arguments = arguments;

            Dialog.SetProgress(importer.ID.ToString(), string.Format("Importing : {0}", filePath));

            return importer.Import();
        }

        /// <summary>
        /// Start the exporter.
        /// </summary>
        /// <param name="exporter">Exporter.</param>
        public static Egemin.EPIA.BaseObjectLight.RESULT Export(this Egemin.EPIA.WCS.Engineering.Exporter exporter)
        {
            do
                Script.Project.Export();
            while (exporter.GetResult() == System.Windows.Forms.DialogResult.Retry);

            Dialog.SetProgress(null, null);

            return exporter.Result;
        }

        /// <summary>
        /// Start the exporter.
        /// </summary>
        /// <param name="exporter">Exporter.</param>
        /// <param name="command">Exporter command.</param>
        /// <param name="arguments">Exporter arguments.</param>
        /// <param name="filePath">Exporter file path.</param>
        public static Egemin.EPIA.BaseObjectLight.RESULT Export(this Egemin.EPIA.WCS.Engineering.Exporter exporter, Egemin.EPIA.WCS.Engineering.Exporter.COMMAND command, string arguments, string filePath)
        {
            exporter.FilePath = File.GetFullFileName(filePath, false);
            exporter.Command = command;
            exporter.Arguments = arguments;

            Dialog.SetProgress(exporter.ID.ToString(), string.Format("Exporting : {0}", filePath));

            return exporter.Export();
        }

        /// <summary>
        /// Start the builder.
        /// </summary>
        /// <param name="builder">Builder.</param>
        /// <returns>Builder result.</returns>
        public static Egemin.EPIA.BaseObjectLight.RESULT Build(this Egemin.EPIA.WCS.Engineering.Builder builder)
        {
            do
                Script.Project.Build();
            while (builder.GetResult() == System.Windows.Forms.DialogResult.Retry);

            Dialog.SetProgress(null, null);

            return builder.Result;
        }

        /// <summary>
        /// Start the builder.
        /// </summary>
        /// <param name="builder">Builder.</param>
        /// <param name="command">Builder command.</param>
        /// <param name="arguments">Builder arguments.</param>
        /// <returns>Builder result.</returns>
        public static Egemin.EPIA.BaseObjectLight.RESULT Build(this Egemin.EPIA.WCS.Engineering.Builder builder, Egemin.EPIA.WCS.Engineering.Builder.COMMAND command, string arguments)
        {
            builder.Command = command;
            builder.Arguments = arguments;

            Dialog.SetProgress(builder.ID.ToString(), string.Format("Building : {0}", arguments));

            return builder.Build();
        }

        /// <summary>
        /// Build all objects that need building.
        /// </summary>
        /// <param name="builder">Builder.</param>
        /// <returns>Builder result.</returns>
        public static Egemin.EPIA.BaseObjectLight.RESULT BuildAll(this Egemin.EPIA.WCS.Engineering.Builder builder)
        {
            Dialog.SetProgress(builder.ID.ToString(), "Building project");

            do
                Script.Project.BuildAll();
            while (builder.GetResult() == System.Windows.Forms.DialogResult.Retry);

            Dialog.SetProgress(null, null);

            return builder.Result;
        }

        /// <summary>
        /// Build all objects that need building.
        /// </summary>
        /// <param name="builder">Builder.</param>
        /// <param name="checkBidirectional">Make bidirectional stations stop NO.</param>
        /// <returns>Builder result.</returns>
        public static Egemin.EPIA.BaseObjectLight.RESULT BuildAll(this Egemin.EPIA.WCS.Engineering.Builder builder, bool checkBidirectional)
        {
            builder.Parameters[Egemin.EPIA.WCS.Engineering.Builder.CHECK_BIDIRECTIONAL].ValueAsBool = checkBidirectional;

            return builder.BuildAll();
        }

        /// <summary>
        /// Build all objects that need building.
        /// </summary>
        /// <param name="builder">Builder.</param>
        /// <param name="checkBidirectional">Make bidirectional stations stop NO.</param>
        /// <returns>Builder result.</returns>
        public static Egemin.EPIA.BaseObjectLight.RESULT BuildAll(this Egemin.EPIA.WCS.Engineering.Builder builder, int version)
        {
            builder.Parameters[Egemin.EPIA.WCS.Engineering.Builder.VERSION].ValueAsInt = version;

            return builder.BuildAll();
        }

        /// <summary>
        /// Route all objects that need routing.
        /// </summary>
        /// <param name="router">Router.</param>
        /// <returns>Router result.</returns>
        public static Egemin.EPIA.BaseObjectLight.RESULT RouteAll(this Egemin.EPIA.WCS.Routing.Router router)
        {
            Dialog.SetProgress(router.ID.ToString(), "Calculating routes");

            do
                Script.Project.RouteAll();
            while (router.GetResult() == System.Windows.Forms.DialogResult.Retry);

            Dialog.SetProgress(null, null);

            return router.Result;
        }

        /// <summary>
        /// Finish all objects that need finishing.
        /// </summary>
        /// <param name="finisher">Finisher.</param>
        /// <returns>Finisher result.</returns>
        public static Egemin.EPIA.BaseObjectLight.RESULT FinishAll(this Egemin.EPIA.WCS.Engineering.Finisher finisher)
        {
            Dialog.SetProgress(finisher.ID.ToString(), "Finishing project");

            do
                Script.Project.FinishAll();
            while (finisher.GetResult() == System.Windows.Forms.DialogResult.Retry);

            Dialog.SetProgress(null, null);

            return finisher.Result;
        }

        /// <summary>
        /// Validate all objects that need validation.
        /// </summary>
        /// <param name="validator">Validator.</param>
        /// <returns>Validator result.</returns>
        public static Egemin.EPIA.BaseObjectLight.RESULT ValidateAll(this Egemin.EPIA.WCS.Engineering.Validator validator)
        {
            Dialog.SetProgress(validator.ID.ToString(), "Validating project");

            do
                Script.Project.ValidateAll();
            while (validator.GetResult() == System.Windows.Forms.DialogResult.Retry);

            Dialog.SetProgress(null, null);

            return validator.Result;
        }

        /// <summary>
        /// Show the duration of the tasks last run.
        /// </summary>
        /// <param name="task">The task to display.</param>
        public static void ShowDuration(this Egemin.EPIA.Task task)
        {
            if (task == null)
                return;

            string messageText = string.Format("Last {0} run duration: {1}.", task.ID, new TimeSpan(0, 0, task.LastRunDuration));
            Dialog.MessageBox.Show(messageText, task.ID.ToString(), System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Information);
        }

        /// <summary>
        /// Pack the layout for E'nsor.
        /// </summary>
        /// <param name="batchFilePath">Full path of the PackLayout.Bat file</param>
        public static void PackLayout(this Egemin.EPIA.WCS.Core.Project project, string batchFilePath)
        {
            if (System.Windows.Forms.DialogResult.Yes != Dialog.MessageBox.Show("Do you want to pack the layout?", project.ID.ToString(), System.Windows.Forms.MessageBoxButtons.YesNo, System.Windows.Forms.MessageBoxIcon.Question))
                return;

            string fullFileName = File.GetFullFileName(batchFilePath);

            System.Diagnostics.Process procPack = new System.Diagnostics.Process();
            procPack.StartInfo.FileName = fullFileName;
            procPack.StartInfo.WorkingDirectory = new System.IO.FileInfo(fullFileName).DirectoryName;
            procPack.StartInfo.CreateNoWindow = true;
            procPack.Start();

            while (!procPack.HasExited)
                System.Threading.Thread.Sleep(1000);

            if (procPack.ExitCode != 0)
                Dialog.MessageBox.Show("Batch file has exited with errorcode " + procPack.ExitCode.ToString());
        }

        /// <summary>
        /// Pack the layout for E'nsor using arj.
        /// </summary>
        /// <param name="sourceFiles">Source file path relative to Data directory.</param>
        /// <param name="destinationPath">Destination Folder relative to Data directory.</param>
        public static void PackLayout(this Egemin.EPIA.WCS.Core.Project project, string sourceFiles, string destinationPath)
        {
            if (System.Windows.Forms.DialogResult.Yes != Dialog.MessageBox.Show("Do you want to pack the layout?", project.ID.ToString(), System.Windows.Forms.MessageBoxButtons.YesNo, System.Windows.Forms.MessageBoxIcon.Question))
                return;

            System.IO.FileInfo arjProcess = new System.IO.FileInfo(@"C:\Etricc 5.0.0\Tools\Arj\ARJ.exe");
            while (!arjProcess.Exists)
            {
                var dialogResult = Dialog.MessageBox.Show(arjProcess.FullName + " not found.", "Error", System.Windows.Forms.MessageBoxButtons.RetryCancel, System.Windows.Forms.MessageBoxIcon.Error);
                if (dialogResult == System.Windows.Forms.DialogResult.Cancel)
                    return;
                if (dialogResult == System.Windows.Forms.DialogResult.None)
                    return;
            }

            System.Diagnostics.Process procPack = new System.Diagnostics.Process();
            procPack.StartInfo.FileName = arjProcess.FullName;
            procPack.StartInfo.WorkingDirectory = project.WorkingDirName + @"\Data\";
            procPack.StartInfo.Arguments = @" a " + destinationPath + " " + sourceFiles;
            procPack.StartInfo.CreateNoWindow = true;
            procPack.Start();

            while (!procPack.HasExited)
                System.Threading.Thread.Sleep(1000);

            if (procPack.ExitCode != 0)
                Dialog.MessageBox.Show("arj.exe has exited with errorcode " + procPack.ExitCode.ToString());
        }

        /// <summary>
        /// Transfer the layout to the vehicles.
        /// </summary>
        public static void UploadLayout(this Egemin.EPIA.WCS.Core.Project project)
        {
            if (System.Windows.Forms.DialogResult.Yes != Dialog.MessageBox.Show("Do you want to upload the layout?", project.ID.ToString(), System.Windows.Forms.MessageBoxButtons.YesNo, System.Windows.Forms.MessageBoxIcon.Question))
                return;

            string fullFileName = @"C:\Program Files\Egemin\E'gv Logging Tool\Egemin.EgvTool.UI.exe";
            if (System.IO.Directory.Exists(@"C:\Program Files (x86)"))
                fullFileName = @"C:\Program Files (x86)\Egemin\E'gv Logging Tool\Egemin.EgvTool.UI.exe";

            while (!System.IO.File.Exists(fullFileName))
            {
                var dialogResult = Dialog.MessageBox.Show(fullFileName + " not found.", "Error", System.Windows.Forms.MessageBoxButtons.RetryCancel, System.Windows.Forms.MessageBoxIcon.Error);
                if (dialogResult == System.Windows.Forms.DialogResult.Cancel)
                    return;
                if (dialogResult == System.Windows.Forms.DialogResult.None)
                    return;
            }

            System.Diagnostics.Process procUpload = new System.Diagnostics.Process();
            procUpload.StartInfo.FileName = fullFileName;
            procUpload.StartInfo.WorkingDirectory = new System.IO.FileInfo(fullFileName).DirectoryName;
            procUpload.StartInfo.CreateNoWindow = false;
            procUpload.StartInfo.Arguments = string.Format("{0}{1}{2}", '"', File.GetFullFileName(@"\Data\Ensor\EgvToolFile.Xml"), '"');
            procUpload.Start();

            while (!procUpload.HasExited)
                System.Threading.Thread.Sleep(1000);

            if (procUpload.ExitCode != 0)
                Dialog.MessageBox.Show("Egv tool has exited with errorcode " + procUpload.ExitCode.ToString());
        }

        /// <summary>
        /// Combines the task result with user interaction (Abort/Retry/Ignore).
        /// </summary>
        /// <param name="task">e.g. Builder, Router, Finisher ...</param>
        /// <returns>The user's action choice</returns>
        public static System.Windows.Forms.DialogResult GetResult(this Egemin.EPIA.Task task)
        {
            // input validation
            System.Windows.Forms.DialogResult dialogResult = System.Windows.Forms.DialogResult.None;
            if (task == null)
                return dialogResult;

            // wait until the task is done
            while (task.Activated)
            {
                Dialog.SetProgress(task.ID.ToString(), task.ProgressInfo);
                System.Windows.Forms.Application.DoEvents();
                System.Threading.Thread.Sleep(100);
            }

            // filter out messages
            var attributes = typeof(Script).Assembly.GetCustomAttributes(typeof(SuppressWarning), true).OfType<SuppressWarning>();
            Egemin.EPIA.Logging.LogMessage[] array = task.LogMessages.ToArray<Egemin.EPIA.Logging.LogMessage>();
            Egemin.EPIA.Logging.LogMessages logMessages = (Egemin.EPIA.BaseContext.XmlCopy(task.LogMessages) as Egemin.EPIA.Logging.LogMessages);

            foreach (var attribute in attributes)
            {
                var suppressedLogMessages = array.Where(l => attribute.Suppresses(l));

                foreach (var suppresedLogMessage in suppressedLogMessages)
                {
                    logMessages.Extract(suppresedLogMessage);
                    logMessages.NrOfWarnings--;
                }
            }

            // look for warnings or errors
            if (logMessages.NrOfWarnings == 0 && logMessages.NrOfErrors == 0)
            {
                dialogResult = System.Windows.Forms.DialogResult.OK;
            }
            else
            {
                // show a messagebox
                System.Windows.Forms.MessageBoxIcon icon = task.Result == Egemin.EPIA.BaseObjectLight.RESULT.SUCCESS ? System.Windows.Forms.MessageBoxIcon.Warning : System.Windows.Forms.MessageBoxIcon.Error;
                string displayText = string.Format(logMessages.GetMessageText(), task.ID);
                dialogResult = Dialog.MessageBox.Show(displayText, task.ID.ToString(), System.Windows.Forms.MessageBoxButtons.AbortRetryIgnore, icon);

                // give the UI the chance to remove the messagebox
                System.Threading.Thread.Sleep(0);
            }

            // abort if needed
            if (dialogResult == System.Windows.Forms.DialogResult.Abort)
                Script.Abort();
            // stop if needed
            if (dialogResult == System.Windows.Forms.DialogResult.None)
                Script.Abort(logMessages.GetWarningsAsText());

            return dialogResult;
        }

    } 
}