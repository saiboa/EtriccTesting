﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Egemin.Etricc.Scripts.Core
{
    /// <summary>
    /// Defines extension methods to the Egemin.EPIA.WCS.Layouting namespace.
    /// </summary>
    public static class LayoutingExtensions
    {
        /// <summary>
        /// Adds a new layout to the layout collection.
        /// </summary>
        /// <param name="layouts">Layouts collection.</param>
        /// <param name="id">Layout ID.</param>
        /// <param name="filePath">Layout drawing file path.</param>
        /// <returns>The created layout.</returns>
        public static Egemin.EPIA.WCS.Layouting.Layout InsertLayout(this Egemin.EPIA.WCS.Layouting.Layouts layouts, string id, string filePath)
        {
            return layouts.InsertLayout(id, filePath, Egemin.EPIA.Constants.ANY);
        }

        /// <summary>
        /// Adds a new layout to the layout collection.
        /// </summary>
        /// <param name="layouts">Layouts collection.</param>
        /// <param name="id">Layout ID.</param>
        /// <param name="filePath">Layout drawing file path.</param>
        /// <param name="moverTypeID">Target mover type ID.</param>
        /// <param name="carrierID">Target carrier ID.</param>
        /// <returns>The created layout.</returns>
        public static Egemin.EPIA.WCS.Layouting.Layout InsertLayout(this Egemin.EPIA.WCS.Layouting.Layouts layouts, string id, string filePath, string moverTypeID)
        {
            Dialog.SetProgress("Layouts", string.Format("Inserting Layout : {0}", id));

            var layout = new Egemin.EPIA.WCS.Layouting.Layout(id);

            // properties
            layout.MoverClass = Egemin.EPIA.WCS.Resources.MoverType.CLASS.AGV;
            layout.MoverTypeID = moverTypeID;

            // drawing
            layout.Reset();
            layout.Drawings.InsertDrawing(id, filePath);

            // parameters
            layout.Parameters[Egemin.EPIA.WCS.Layouting.Layout.MESH].ValueAsInt = 5;
            layout.Parameters[Egemin.EPIA.WCS.Layouting.Layout.LEAVE_TRACK_ENABLE].ValueAsBool = true;
            layout.SetEnsorLayers();

            return layouts.Insert(layout, true) as Egemin.EPIA.WCS.Layouting.Layout;
        }

        /// <summary>
        /// Set the default Ensor layer parameters for a layout.
        /// </summary>
        /// <param name="layout">The layout that will receive the ensor layer parameters.</param>
        public static void SetEnsorLayers(this Egemin.EPIA.WCS.Layouting.Layout layout)
        {
            foreach (Egemin.EPIA.Core.Definitions.Parameter parameter in layout.Parameters)
            {
                if (parameter.Type != Egemin.EPIA.Core.Definitions.Parameter.TYPE.STRING)
                    continue;
                if (!parameter.ID.ToString().EndsWith("Layer"))
                    continue;
                parameter.ValueAsString = parameter.DefaultAsString.Replace("EGEMIN", "ENSOR");
            }

            layout.Parameters[Egemin.EPIA.WCS.Layouting.Layout.SIGN_LAYER].ValueAsString = "ENSOR_TRAFFIC";

            //layout.Parameters[Egemin.EPIA.WCS.Layouting.Layout.PATH_FORWARD_LAYER].ValueAsString = "ENSOR_PATH_F1";
            //layout.Parameters[Egemin.EPIA.WCS.Layouting.Layout.PATH_BACKWARD_LAYER].ValueAsString = "ENSOR_PATH_B1";
            //layout.Parameters[Egemin.EPIA.WCS.Layouting.Layout.PATH_FORWARD_ROTATION_LAYER].ValueAsString = "ENSOR_PATH_ROT_F1";
            //layout.Parameters[Egemin.EPIA.WCS.Layouting.Layout.PATH_BACKWARD_ROTATION_LAYER].ValueAsString = "ENSOR_PATH_ROT_B1";
            //layout.Parameters[Egemin.EPIA.WCS.Layouting.Layout.PATH_FORWARD_CRABWISE_LAYER].ValueAsString = "ENSOR_PATH_CRAB_F1";
            //layout.Parameters[Egemin.EPIA.WCS.Layouting.Layout.PATH_BACKWARD_CRABWISE_LAYER].ValueAsString = "ENSOR_PATH_CRAB_B1";
            //layout.Parameters[Egemin.EPIA.WCS.Layouting.Layout.NODE_LAYER].ValueAsString = "ENSOR_NODE";
            //layout.Parameters[Egemin.EPIA.WCS.Layouting.Layout.BEACON_LAYER].ValueAsString = "ENSOR_BEACON";
            //layout.Parameters[Egemin.EPIA.WCS.Layouting.Layout.IMAGE_LAYER].ValueAsString = "ENSOR_IMAGE";
        }

        /// <summary>
        /// Adds a new drawing to the drawing collection.
        /// </summary>
        /// <param name="drawings">Drawing collection.</param>
        /// <param name="id">Drawing ID.</param>
        /// <param name="filePath">Drawing file path.</param>
        /// <returns>The created drawing.</returns>
        public static Egemin.EPIA.WCS.Layouting.Drawing InsertDrawing(this Egemin.EPIA.WCS.Layouting.Drawings drawings, object id, string filePath)
        {
            Dialog.SetProgress("Drawings", string.Format("Inserting Drawing : {1} {0}", id, filePath));

            // input validation
            if (filePath == null)
            {
                var parent = drawings.Parent as Egemin.EPIA.BaseObjectLight;
                string text = string.Format("Please select a drawing file for {0}.", parent.ID);
                filePath = Dialog.SelectFileOpen(text, @"\Data\Cad\", EXTENSION.DXF);
            }

            var drawing = new Egemin.EPIA.WCS.Layouting.Drawing(id);

            // parameters
            drawing.FilePath = File.GetFullFileName(filePath, true, ScriptContext.CadDirectory);
            drawing.Type = Egemin.EPIA.WCS.Layouting.Drawing.TYPE.DXF;

            return drawings.Insert(drawing, true) as Egemin.EPIA.WCS.Layouting.Drawing;
        }

        /// <summary>
        /// Adds a group to the group collection.
        /// </summary>
        /// <param name="id">Group ID></param>
        /// <param name="locationIDs">Group location IDs.</param>
        /// <param name="decisionIDs">Group decision IDs.</param>
        /// <returns>The created group.</returns>
        public static Egemin.EPIA.WCS.Layouting.Group InsertGroup(this Egemin.EPIA.WCS.Layouting.Groups groups, string id, string locationIDs, string decisionIDs)
        {
            return groups.InsertGroup(id, locationIDs, decisionIDs, false, 0, Egemin.EPIA.WCS.Layouting.Group.CHECKTYPE.MAX_MOVERS_SOURCE_DEST);
        }

        /// <summary>
        /// Adds a group to the group collection.
        /// </summary>
        /// <param name="groups">Groups collection.</param>
        /// <param name="id">Group ID</param>
        /// <param name="locationIDs">Group location IDs.</param>
        /// <param name="decisionIDs">Group decision IDs.</param>
        /// <param name="preAssing">Preassign.</param>
        /// <param name="maxMovers">Maximum movers.</param>
        /// <param name="checkType">Preassign check type.</param>
        /// <returns>The created group.</returns>
        public static Egemin.EPIA.WCS.Layouting.Group InsertGroup(this Egemin.EPIA.WCS.Layouting.Groups groups, string id, string locationIDs, string decisionIDs, bool preAssing, int maxMovers, Egemin.EPIA.WCS.Layouting.Group.CHECKTYPE checkType)
        {
            Dialog.SetProgress("Groups", string.Format("Inserting Group : {0}", id));

            var group = new Egemin.EPIA.WCS.Layouting.Group(id);

            // properties
            group.LocationIDs = locationIDs;
            group.DecisionIDs = decisionIDs;
            group.PreAssign = preAssing;
            group.MaxMovers = maxMovers;
            group.CheckType = checkType;

            return groups.Insert(group, true) as Egemin.EPIA.WCS.Layouting.Group;
        }
    } 
}