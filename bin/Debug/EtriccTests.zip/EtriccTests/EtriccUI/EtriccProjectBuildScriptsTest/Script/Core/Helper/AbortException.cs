﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Egemin.Etricc.Scripts.Core
{
    /// <summary>
    /// Custom exception used to abort script execution.
    /// </summary>
    public class AbortException : Exception
    {
        /// <summary>
        /// Initializes a new instance of the AbortException class.
        /// </summary>
        public AbortException() { }

        /// <summary>
        /// Initializes a new instance of the AbortException class.
        /// </summary>
        /// <param name="message">A message that explains the reason for the abortion.</param>
        public AbortException(string message) : base(message) { }

        /// <summary>
        /// Initializes a new instance of the AbortException class.
        /// </summary>
        /// <param name="innerException">The exception that is the cause of the abortion.</param>
        public AbortException(Exception innerException) : base(null, innerException) { }

        /// <summary>
        /// Initializes a new instance of the AbortException class.
        /// </summary>
        /// <param name="message">A messag that explains the reason for the abortion.</param>
        /// <param name="innerException">The exception that is the cause of the abortion.</param>
        public AbortException(string message, Exception inner) : base(message, inner) { }
    } 
}