﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Egemin.Etricc.Scripts.Core
{
    /// <summary>
    /// Defines extension methods to the Egemin.EPIA.Core namespace.
    /// </summary>
    public static class CoreExtensions
    {
        /// <summary>
        /// Assigns a new instance to the root Project.
        /// </summary>
        /// <param name="id">Project ID.</param>
        /// <param name="name">Project name.</param>
        /// <param name="description">Project description.</param>
        /// <param name="version">Project version.</param>
        public static void Create(this Egemin.EPIA.WCS.Core.Project project, string id, string name, string description)
        {
            Create(project, id, name, description, ScriptContext.RootDirectory);
        }

        /// <summary>
        /// Assigns a new instance to the root Project.
        /// </summary>
        /// <param name="id">Project ID.</param>
        /// <param name="name">Project name.</param>
        /// <param name="description">Project description.</param>
        /// <param name="directoryName">Fully qualified project base directory name.</param>
        /// <param name="version">Project version.</param>
        public static void Create( this Egemin.EPIA.WCS.Core.Project project, string id, string name, string description, string directoryName )
        {
            Dialog.SetProgress( "Project", "Creating new project" );

            if ( project != null )
                project.Deactivate();

            Script.Project = project = new Egemin.EPIA.WCS.Core.Project( id );

            //properties
            project.Description = description;
            project.Name = name;

            if ( directoryName == null )
                directoryName = Dialog.SelectDirectory( @"Please select the main project directory. This will usually be a subfolder of C:\Etricc 5.0.0\." );

            if ( ScriptContext.RootDirectory == null )
                ScriptContext.RootDirectory = directoryName;

            project.WorkingDirName = directoryName;
        }

        /// <summary>
        /// Sets the dynamic behaviour of the root project.
        /// </summary>
        /// <param name="project">The Project.</param>
        /// <param name="dynamicRouting">Dynamic Routing.</param>
        /// <param name="dynamicScheduling">Dynamic Scheduling.</param>
        /// <param name="autoDeadlocksolving">Automatic deadlock solving.</param>
        /// <param name="transportReassignment">Automatic transport reassignment.</param>
        public static void SetDynamicBehaviour(this Egemin.EPIA.WCS.Core.Project project, bool dynamicRouting, bool dynamicScheduling, bool autoDeadlocksolving, bool transportReassignment)
        {
            Dialog.SetProgress("Project", "Setting dynamic project behaviour");

            project.Router.Parameters[Egemin.EPIA.WCS.Routing.Router.DYNAMIC].ValueAsBool = dynamicRouting;
            project.Scheduler.Parameters[Egemin.EPIA.WCS.Scheduling.Scheduler.DYNAMIC].ValueAsBool = dynamicScheduling;
            project.TrafficController.Parameters[Egemin.EPIA.WCS.TrafficControl.TrafficController.AUTO_DEADLOCK_SOLVING].ValueAsBool = autoDeadlocksolving;
            project.TransportManager.Parameters[Egemin.EPIA.WCS.Transportation.TransportManager.REASSIGN_ENABLED].ValueAsBool = transportReassignment;
        }

        /// <summary>
        /// Sets the maximun client software connections.
        /// </summary>
        /// <param name="maxDesktopClients">Maximum number of desktop client connections.</param>
        public static void SetMaxClients(this Egemin.EPIA.WCS.Core.Project project, int maxDesktopClients)
        {
            Dialog.SetProgress("Project", "Setting maximum clients");

            project.Parameters[Egemin.EPIA.WCS.Core.Project.MAX_DESKTOPCLIENTS].ValueAsInt = maxDesktopClients;
        }

        /// <summary>
        /// Adds a facility to the facility collection.
        /// </summary>
        /// <param name="facilities">Facility collection.</param>
        /// <param name="id">Facility ID.</param>
        /// <returns>The created facility.</returns>
        public static Egemin.EPIA.Core.Definitions.Facility InsertFacility(this Egemin.EPIA.Core.Definitions.Facilities facilities, string id)
        {
            Dialog.SetProgress("Statuses", string.Format("Inserting Status : {0}", id));

            var facility = new Egemin.EPIA.Core.Definitions.Facility(id);

            return facilities.Insert(facility, true) as Egemin.EPIA.Core.Definitions.Facility;
        }

        /// <summary>
        /// Adds a facility for the system overview.
        /// </summary>
        /// <param name="facilities">Facility collection.</param>
        /// <param name="showLoadsEnabled">Enables load display on the overview.</param>
        /// <param name="showLocationEnabled">Enables location display on the overview.</param>
        /// <param name="showStationsEnabled">Enables station display on the overview.</param>
        /// <param name="showFieldFunctionsEnabled">Enables field function display on the overview.</param>
        /// <param name="showLoadPatternsEnabled">Enables load pattern display on the overview.</param>
        /// <returns>The created facility.</returns>
        public static Egemin.EPIA.Core.Definitions.Facility InsertOverviewStatus(this Egemin.EPIA.Core.Definitions.Facilities facilities, bool showLoadsEnabled, bool showLocationEnabled, bool showStationsEnabled, bool showFieldFunctionsEnabled, bool showLoadPatternsEnabled)
        {
            var status = facilities.InsertFacility("System Overview");

            status.Parameters.InsertParameter("ShowLoadsEnabled", Egemin.EPIA.Core.Definitions.Parameter.TYPE.BOOL, showLoadsEnabled.ToString(), "Loads are visualized in the system overview.");
            status.Parameters.InsertParameter("ShowLocationsEnabled", Egemin.EPIA.Core.Definitions.Parameter.TYPE.BOOL, showLocationEnabled.ToString(), "Locations are visualized in the system overview.");
            status.Parameters.InsertParameter("ShowStationsEnabled", Egemin.EPIA.Core.Definitions.Parameter.TYPE.BOOL, showStationsEnabled.ToString(), "Stations are visualized in the system overview.");
            status.Parameters.InsertParameter("ShowFieldFunctionsEnabled", Egemin.EPIA.Core.Definitions.Parameter.TYPE.BOOL, showFieldFunctionsEnabled.ToString(), "FieldFunctions are visualized in the system overview.");
            status.Parameters.InsertParameter("ShowLoadPatternsEnabled", Egemin.EPIA.Core.Definitions.Parameter.TYPE.BOOL, showLoadPatternsEnabled.ToString(), "LoadPatterns are visualized in the system overview.");

            return status;
        }

        /// <summary>
        /// Adds a status to the facilities collection.
        /// </summary>
        /// <param name="facilities">Facility collection.</param>
        /// <param name="id">Status ID.</param>
        /// <param name="propertyNames">Property names displayed in the status screen.</param>
        /// <returns>The created facility.</returns>
        public static Egemin.EPIA.Core.Definitions.Facility InsertStatus(this Egemin.EPIA.Core.Definitions.Facilities facilities, string id, string propertyNames)
        {
            return facilities.InsertStatus(id, 1, true, propertyNames);
        }

        /// <summary>
        /// Adds a status to the facilities collection.
        /// </summary>
        /// <param name="facilities">Facility collection.</param>
        /// <param name="id">Status ID.</param>
        /// <param name="refreshCount">Number of seconds between each screen update.</param>
        /// <param name="useGridView">Use a gridvies in stead of a standard listview.</param>
        /// <param name="propertyNames">Property names displayed in the status screen.</param>
        /// <returns>The created facility.</returns>
        public static Egemin.EPIA.Core.Definitions.Facility InsertStatus(this Egemin.EPIA.Core.Definitions.Facilities facilities, string id, int refreshCount, bool useGridView, string propertyNames)
        {
            var status = facilities.InsertFacility(id);

            status.Parameters.InsertParameter("Properties", Egemin.EPIA.Core.Definitions.Parameter.TYPE.TOKENISER, propertyNames, "Properties shown in columns of screen.");
            if (refreshCount > 0)
                status.Parameters.InsertParameter("RefreshCount", Egemin.EPIA.Core.Definitions.Parameter.TYPE.INT, refreshCount.ToString(), "Screen will be refreshed every RefreshCount seconds.");
            if (useGridView)
                status.Parameters.InsertParameter("UseGridView", Egemin.EPIA.Core.Definitions.Parameter.TYPE.BOOL, useGridView.ToString(), "Screen will use the GridView.");

            return status;
        }

        /// <summary>
        /// Adds an application to the application collection.
        /// </summary>
        /// <param name="applications">Applications collection.</param>.
        /// <param name="id">Application ID.</param>
        /// <param name="filePath">Dynamic link librairy filepath.</param>
        /// <param name="workerType">Worker class type in the dynamic link librairy.</param>
        /// <returns>The created application.</returns>
        public static Egemin.EPIA.Core.Application InsertApplication(this Egemin.EPIA.Core.Applications applications, object id, string filePath, string workerType)
        {
            Dialog.SetProgress("Applications", string.Format("Inserting Application : {0}", id));

            var application = new Egemin.EPIA.Core.Application(id);

            // parameters
            filePath = File.GetFullFileName(filePath, true, ScriptContext.BinDirectory);
            application.Parameters[Egemin.EPIA.Core.Application.WORKER_FILEPATH].Value = filePath;
            application.Parameters[Egemin.EPIA.Core.Application.WORKER_ASSEMBLY].Value = filePath.TrimEnd(".dll".ToCharArray());
            application.Parameters[Egemin.EPIA.Core.Application.WORKER_TYPE].Value = workerType;

            // properties
            application.Mode = Egemin.EPIA.Core.Application.MODE.LOCAL;

            return applications.Insert(application, true) as Egemin.EPIA.Core.Application;
        }


        /// <summary>
        /// Adds a parameter to the parameter collection.
        /// </summary>
        /// <param name="parameters">Parameter collection.</param>
        /// <param name="id">Parameter ID.</param>
        /// <param name="type">Parameter type.</param>
        /// <param name="value">Parameter value.</param>
        /// <param name="description">Parameter descriptiom.</param>
        /// <returns>The created parameter</returns>
        public static Egemin.EPIA.Core.Definitions.Parameter InsertParameter(this Egemin.EPIA.Core.Definitions.Parameters parameters, string id, Egemin.EPIA.Core.Definitions.Parameter.TYPE type, string value, string description)
        {
            return parameters.InsertParameter(id, type, value, null, null, null, null, description);
        }

        /// <summary>
        /// Adds a parameter to the parameter collection.
        /// </summary>
        /// <param name="parameters">Parameter collection.</param>
        /// <param name="id">Parameter ID.</param>
        /// <param name="type">Parameter type.</param>
        /// <param name="value">Parameter value.</param>
        /// <param name="minValue">Parameter minimum value.</param>
        /// <param name="maxValue">Parameter maximum value.</param>
        /// <param name="defaultValue">Parameter default value.</param>
        /// <param name="validation">Parameter validation.</param>
        /// <param name="description">Parameter descriptiom.</param>
        /// <returns>The created parameter</returns>
        public static Egemin.EPIA.Core.Definitions.Parameter InsertParameter(this Egemin.EPIA.Core.Definitions.Parameters parameters, string id, Egemin.EPIA.Core.Definitions.Parameter.TYPE type, string value, string minValue, string maxValue, string defaultValue, string validation, string description)
        {
            Dialog.SetProgress("Parameters", string.Format("Inserting Parameter : {0} {1}", id, value));

            Egemin.EPIA.Core.Definitions.Parameter.ENTRY entry = new Egemin.EPIA.Core.Definitions.Parameter.ENTRY(id, type, value, minValue, maxValue, defaultValue, validation, description);

            return parameters.Insert(new Egemin.EPIA.Core.Definitions.Parameter(entry), true) as Egemin.EPIA.Core.Definitions.Parameter;
        }

        /// <summary>
        /// Sets a parameter in a parameter collection.
        /// </summary>
        /// <param name="parameter">Parameter collection.</param>
        /// <param name="ID">Parameter ID.</param>
        /// <param name="value">Parameter value</param>
        /// <returns>The changed parameter.</returns>
        public static Egemin.EPIA.Core.Definitions.Parameter SetParameter(this Egemin.EPIA.Core.Definitions.Parameters parameters, string id, object value)
        {
            if (!parameters.Contains(id))
                throw new ArgumentOutOfRangeException("id");

            var parameter = parameters[id];
            parameter.Value = value != null ? value.ToString() : null;

            return parameter;
        }

        /// <summary>
        /// Adds a week plan to the weekplan collection.
        /// </summary>
        /// <param name="weekPlans">Weekplan collection.</param>
        /// <param name="Arguments">Weekplan arguments.</param>
        /// <param name="Duration">Weekplan duration.</param>
        /// <param name="Enabled">Weekplan enabled flag.</param>
        /// <param name="Day">Weekplan day of week.</param>
        /// <param name="Hour">Weekplan start hour.</param>
        /// <param name="Minute">Weekplan start minute.</param>
        /// <returns>The created weekplan.</returns>
        public static Egemin.EPIA.Core.Definitions.WeekPlan InsertWeekPlan(this Egemin.EPIA.Core.Definitions.WeekPlans weekPlans, Egemin.EPIA.Tokeniser arguments, int duration, bool enabled, System.DayOfWeek day, int hour, int minute)
        {
            Dialog.SetProgress("Weekplans", string.Format("Inserting Weekplan"));

            var weekPlan = new Egemin.EPIA.Core.Definitions.WeekPlan();

            // properties
            weekPlan.Arguments = arguments;
            weekPlan.Duration = duration;
            weekPlan.Enabled = enabled;
            weekPlan.Day = day;
            weekPlan.StartHour = hour;
            weekPlan.StartMinute = minute;

            return weekPlans.Insert(weekPlan, true) as Egemin.EPIA.Core.Definitions.WeekPlan;
        }
    } 
}