﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Egemin.EPIA.ComponentModel;
using Egemin.Etricc.Scripts.Core;

namespace Egemin.Etricc.Scripts.Detail
{
    [Entry("Schedules", "Main")]
    [Include(@"..\Core\Script.cs")]
    public class Schedules : Script
    {
        public override void Run()
        {

        }
    } 
}