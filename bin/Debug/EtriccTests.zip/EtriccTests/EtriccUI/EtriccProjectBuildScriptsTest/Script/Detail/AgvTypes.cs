﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Egemin.EPIA.ComponentModel;
using Egemin.EPIA.WCS.Resources;
using Egemin.EPIA.Communication;
using Egemin.Etricc.Scripts.Core;

namespace Egemin.Etricc.Scripts.Detail
{
    [Entry("AgvTypes", "Main")]
    [Include(@"..\Core\Script.cs")]
    public class AgvTypes : Script
    {
        public override void Run()
        {
            Project.AgvTypes.InsertAgvType(VEHICLETYPE.AGV, @"C:\EtriccTests\EtriccUI\EtriccProjectBuildScriptsTest\Data\Cad\HB0000_CBV.dxf", Controller.TYPE.ENSOR_IPC2, Connection.TYPE.TCP);
        }
    }
}