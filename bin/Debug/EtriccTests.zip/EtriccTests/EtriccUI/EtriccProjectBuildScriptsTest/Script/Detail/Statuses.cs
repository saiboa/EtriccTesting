using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Egemin.EPIA.ComponentModel;
using Egemin.Etricc.Scripts.Core;

namespace Egemin.Etricc.Scripts.Detail
{
    [Entry("Statuses", "Main")]
    [Include(@"..\Core\Script.cs")]
    public class Statuses : Script
    {
        public override void Run()
        {
            Project.Facilities.InsertOverviewStatus(true, true, true, true, true);

            Project.Facilities.InsertStatus("Alarm Detail", "BaseID Category Severity Description Help");
            Project.Facilities.InsertStatus("Alarm Status", "BaseID Category Severity State Description");
            Project.Facilities.InsertStatus("AlarmViewer", "BaseID Created Category State Acknowledged IsAcknowledged User Severity OriginatorID Description Description.Arguments Comments");
            Project.Facilities.InsertStatus("All Job Status", "BaseID ContextID Type LocationID LoadID ViaLSIDs State Reason Created");
            Project.Facilities.InsertStatus("Application Status", "BaseID Worker.Result");
            Project.Facilities.InsertStatus("Application Detail", "BaseID DependencyIDs.Tokens LastExceptionMessage LastExceptionSource LastExceptionTrace");
            Project.Facilities.InsertStatus("Calibration Plan", "BaseID Day StartHour StartMinute Duration Enabled");
            Project.Facilities.InsertStatus("Current Alarm Status", "BaseID Created Category State Acknowledged User Comments Severity Description OriginatorID");
            Project.Facilities.InsertStatus("Current Alarm Detail", "BaseID Created Category State Acknowledged User Comments Severity Description OriginatorID");
            Project.Facilities.InsertStatus("FieldControlBlock Status", "BaseID Type");
            Project.Facilities.InsertStatus("FieldControlBlock Detail", "BaseID Type BusyIDs.Tokens Empty Enable Full Requested RequestedIDs TransferBusy");
            Project.Facilities.InsertStatus("FieldFunction Status", "BaseID State");
            Project.Facilities.InsertStatus("FieldFunction Detail", "BaseID State Mode BlinkMode RiseTime FallTime Type LSGIDs.Tokens Arguments Description");
            Project.Facilities.InsertStatus("FieldModule Status", "BaseID FieldModuleTypeID InputPoints.Count OutputPoints.Count");
            Project.Facilities.InsertStatus("FieldModule Detail", "BaseID FieldModuleTypeID InputPoints.Count OutputPoints.Count Name");
            Project.Facilities.InsertStatus("FieldPoint Status", "BaseID Direction Type Value");
            Project.Facilities.InsertStatus("FieldPoint Detail", "BaseID Type Name Direction Value Description");
            Project.Facilities.InsertStatus("FieldPort Status", "BaseID Type FieldPortDriver.State");
            Project.Facilities.InsertStatus("FieldPort Detail", "BaseID Type State FieldPortDriver.State Mode FieldModules.Count FieldPortDriver.BitOrder");
            Project.Facilities.InsertStatus("FieldRuleOpc Status", "ID Type Value");
            Project.Facilities.InsertStatus("FieldRuleOpc Detail", "BaseID Value Type OpcClientID OpcItemID");
            Project.Facilities.InsertStatus("FieldRulePort Status", "BaseID Value Type FieldPortID FieldModuleID FieldPointID FieldFunctionID");
            Project.Facilities.InsertStatus("FieldRulePort Detail", "BaseID Value Type FieldPortID FieldModuleID FieldPointID FieldFunctionID");
            Project.Facilities.InsertStatus("Group Status", "BaseID LocationIDs.Tokens Disabled CurrentMoverIDs");
            Project.Facilities.InsertStatus("Group Detail", "BaseID LocationIDs MaxMovers MinMovers PreAssign DecisionIDs.Tokens CurrentMoverIDs EnrouteMoverIDs.Tokens WorkloadExempted WorkloadGradient WorkloadRequired");
            Project.Facilities.InsertStatus("Job Status", "BaseID Type LocationID Reason");
            Project.Facilities.InsertStatus("Job Detail", "BaseID Type LocationID Reason State CarrierID Comments Created Started Finished Cancelled OriginatorID Result Outcome");
            Project.Facilities.InsertStatus("Load Status", "BaseID State CurrentLocationID");
            Project.Facilities.InsertStatus("Load Detail", "BaseID TypeID State OriginLocationID CurrentLocationID DestinationLocationID AssignedMoverID RetrievedMoverID StoredMoverID Created Retrieved Stored");
            Project.Facilities.InsertStatus("Location Status", "BaseID Mode LoadIDs.Tokens");
            Project.Facilities.InsertStatus("Location Detail", "BaseID State Mode LoadIDs.Tokens Presence EnrouteMoverCarrierIDs.Tokens TransportIDs.Tokens");
            Project.Facilities.InsertStatus("Opc Detail", "BaseID State ComputerDefID OpcServerNameDefID");
            Project.Facilities.InsertStatus("Opc Groups Status", "BaseID State");
            Project.Facilities.InsertStatus("Opc Group Detail", "BaseID State DeadBand RefreshPeriod WritePeriod");
            Project.Facilities.InsertStatus("Opc Items Status", "BaseID State OpcGroupID");
            Project.Facilities.InsertStatus("Opc Item Detail", "BaseID State OpcGroupID OpcItemDataState ServerItemId");
            Project.Facilities.InsertStatus("Opc Status", "BaseID State");
            Project.Facilities.InsertStatus("Project File Summary", "BaseID Version FilePath");
            Project.Facilities.InsertStatus("Project File Detail", "BaseID Version Type FilePath FileModified Exists Description");
            Project.Facilities.InsertStatus("Single FieldPoint Status", "BaseID Direction Type Value");
            Project.Facilities.InsertStatus("Station Status", "BaseID Mode");
            Project.Facilities.InsertStatus("Station Detail", "BaseID State Mode Cost");
            Project.Facilities.InsertStatus("BatteryCharge Plan", "BaseID Day StartHour StartMinute Duration Enabled");
            Project.Facilities.InsertStatus("System Status", "BaseID Name Activated PersistencyEnabled RuntimeDbSerializing LogMessages.NrOfWarnings LogMessages.NrOfErrors Scheduler.Dynamic Router.Dynamic TrafficController.Parameters[\"AutoDeadlockSolving\"].ValueAsBool");
            Project.Facilities.InsertStatus("Transport Status", "BaseID Command SourceID DestinationID LoadID PriorityCurrent AssignedMoverID Created");
            Project.Facilities.InsertStatus("Transport Detail", "BaseID Command SourceID FinalSourceID DestinationID FinalDestinationID Priority PriorityCurrent AssignedMoverID State Created Pended Assigned Retrieved Stored Finished OriginatorID LoadID WaitTransitionReason.Symbol Comments");
            Project.Facilities.InsertStatus("Vehicle Status", "BaseID State StateTimer Mode CurrentLSID ActiveStatusListUICulture Jobs[JobID].Type Jobs[JobID].LocationID");
            Project.Facilities.InsertStatus("Vehicle Detail", "BaseID TypeID State StateTimer Mode CurrentLSID NextLSID TransportIDs.Tokens JobID Jobs[JobID].Type Jobs[JobID].LocationID Loaded BumperStop EmergencyStop Manual BatteryLow Protocol.CommDown ActiveStatusListUICulture.Tokens DisplayMessage WaitReason WaitArguments.Tokens BumpRequestIDs.Tokens DeadLockingIDs.Tokens BatteryVoltage Protocol.Connection.Address");
            Project.Facilities.InsertStatus("Vehicle Pool Status", "BaseID State StateTimer Mode");
            Project.Facilities.InsertStatus("WeekPlan Detail", "BaseID Day StartHour StartMinute Duration Enabled");
        }
    } 
}