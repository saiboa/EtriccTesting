﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Egemin.EPIA.ComponentModel;
using Egemin.EPIA.WCS.Resources;
using Egemin.Etricc.Scripts.Core;

namespace Egemin.Etricc.Scripts.Detail
{
    [Entry("Agvs", "Main")]
    [Include(@"..\Core\Script.cs")]
    public class Agvs : Script
    {
        public override void Run()
        {
            Project.Agvs.InsertAgv("AGV01", VEHICLETYPE.AGV, 1, "192.168.1.1");
        }
    } 
}