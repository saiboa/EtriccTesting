using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Egemin.EPIA.ComponentModel;
using Egemin.Etricc.Scripts.Core;
using Egemin.EPIA.Core.Definitions;

namespace Egemin.Etricc.Scripts.Detail
{
    [Entry( "Applications", "Main" )]
    [Include( @"..\Core\Script.cs" )]
    public class Applications : Script
    {
        public const string AlarmManager = "AlarmManager";
        public const string CacheManager = "CacheManager";
        public const string DependantWorker = "DependantWorker";
        public const string PalletManager = "PalletManager";       

        public const string AlarmLight = "AlarmLight";
        public const string AcknowledgeButton = "AckButton";

        private const string DefaultNamespace = "Egemin.Etricc.Sample.Workers";
        private readonly string AssemblyFilePath = string.Format(@"\Bin\{0}.dll", DefaultNamespace);


        public override void Run()
        {
            /*var application = Project.Applications.InsertApplication( AlarmManager, AssemblyFilePath, DefaultNamespace + "." + AlarmManager );
            application.Parameters.InsertParameter( AlarmLight, Parameter.TYPE.UNDEFINED, FieldFunctions.AlarmLight, null );
            application.Parameters.InsertParameter( AcknowledgeButton, Parameter.TYPE.UNDEFINED, FieldFunctions.AcknowledgeButton, null );

            application = Project.Applications.InsertApplication( CacheManager, AssemblyFilePath, DefaultNamespace + "." + CacheManager );

            application = Project.Applications.InsertApplication( DependantWorker, AssemblyFilePath, DefaultNamespace + "." + DependantWorker );
            application.DependencyIDs = CacheManager;

            application = Project.Applications.InsertApplication( PalletManager, AssemblyFilePath, DefaultNamespace + "." + PalletManager );
             */
        }
    }
}