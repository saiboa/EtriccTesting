﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Egemin.EPIA.ComponentModel;
using Egemin.EPIA.WCS.Engineering;
using Egemin.Etricc.Scripts.Core;

namespace Egemin.Etricc.Scripts.Detail
{
    [Entry("ImportStatusDefs", "Main")]
    [Include(@"..\Core\Script.cs")]
    public class ImportStatusDefs : Script
    {
        public override void Run()
        {
            Project.Importer.Import(Importer.COMMAND.ENSOR_STS_LIST, VEHICLETYPE.AGV, @"\Data\Ensor\AgvStatusDef\Project_EtriccV500_StatusDef.CSV");
            Project.Exporter.Export(Exporter.COMMAND.VEHICLE_STATUS_LIST, VEHICLETYPE.AGV, @"\Data\Ensor\AgvStatusDef\Project_ExportedStatusDefs.CSV");
        }
    } 
}