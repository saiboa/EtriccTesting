﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Egemin.EPIA.ComponentModel;
using Egemin.Etricc.Scripts.Core;
using Egemin.EPIA.WCS.IO.Field;

namespace Egemin.Etricc.Scripts.Detail
{
    [Entry("FieldFunctions", "Main")]
    [Include(@"..\Core\Script.cs")]
    public class FieldFunctions : Script
    {
        public const string AlarmLight = "ALARM_LIGHT";
        public const string AcknowledgeButton = "ACK_BUTTON";

        public override void Run()
        {
            Project.FieldFunctions.InsertFieldFunction(AlarmLight, FieldFunction.TYPE.FLAG_OUT, null, null);
            Project.FieldFunctions.InsertFieldFunction(AcknowledgeButton, FieldFunction.TYPE.FLAG_IN_EDGE, null, null);
        }
    } 
}