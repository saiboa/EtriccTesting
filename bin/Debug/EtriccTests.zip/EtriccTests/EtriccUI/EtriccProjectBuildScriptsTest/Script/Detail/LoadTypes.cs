﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Egemin.EPIA.ComponentModel;
using Egemin.Etricc.Scripts.Core;

namespace Egemin.Etricc.Scripts.Detail
{
    [Entry("LoadTypes", "Main")]
    [Include(@"..\Core\Script.cs")]
    public class LoadTypes : Script
    {
        public override void Run()
        {
            Project.LoadTypes.InsertLoadType(Constants.DEFAULT, @"C:\EtriccTests\EtriccUI\EtriccProjectBuildScriptsTest\Data\Cad\HB0000_Load.dxf");
        }
    }
}