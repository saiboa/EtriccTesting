﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Egemin.EPIA.ComponentModel;
using Egemin.Etricc.Scripts.Core;

namespace Egemin.Etricc.Scripts.Detail
{
    [Entry("Layouts", "Main")]
    [Include(@"..\Core\Script.cs")]
    public class Layouts : Script
    {
        public override void Run()
        {
            Project.Layouts.InsertLayout("LAYOUT", @"C:\EtriccTests\EtriccUI\EtriccProjectBuildScriptsTest\Data\Cad\HB0000_Bluestar.dxf", VEHICLETYPE.AGV);
        }
    }
}