﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Egemin.EPIA.ComponentModel;
using System.Diagnostics;

namespace Egemin.Etricc.Script.Core
{
    /// <summary>
    /// Base class for all E'tricc scripts.
    /// </summary>
    [Reference( "Egemin.EPIA.Common" )]
    [Reference( "Egemin.EPIA.Common.Interfaces" )]
    [Reference( "Egemin.EPIA.Common.Security" )]
    [Reference( "Egemin.EPIA.Common.UI" )]
    [Reference( "Egemin.EPIA.Definitions" )]
    [Reference( "Egemin.EPIA.ExplorerLib" )]
    [Reference( "Egemin.EPIA.WCS" )]
    [Reference( "Egemin.Etricc.Components" )]
    [Reference( "Egemin.Etricc.Components.Interfaces" )]
    [Reference( "Egemin.Epia.Foundation.ComponentManagement.Development" )]
    [Reference( "System" )]
    [Reference( "System.Core" )]
    [Reference( "System.Data" )]
    [Reference( "System.Data.Linq" )]
    [Reference( "System.Data.DataSetExtensions" )]
    [Reference( "System.Drawing" )]
    [Reference( "System.Windows.Forms" )]
    [Reference( "System.Xml" )]
    [Reference( "System.Xml.Linq" )]

    [Entry( "TestAfterDeactivateScript", "Main" )]
    public class TestAfterDeactivateScript
    {
        public object Main( object root )
        {
            var query = from frame in new StackTrace().GetFrames()
                        let method = frame.GetMethod()
                        where method.DeclaringType == typeof( Egemin.Etricc.Components.EtriccCore )
                        select string.Format( "Executing: {0}()", method.Name );

            Console.WriteLine( query.FirstOrDefault() );
			Egemin.EPIA.WCS.Core.Project TestProject = root as Egemin.EPIA.WCS.Core.Project;
			TestProject.Locations["PRK_FLV"].Automatic();

            return null;
        }
    }
}